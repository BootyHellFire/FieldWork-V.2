# Fieldwork
**High-end residential electrical walkthrough app**

A foreman walks the house once, speaks naturally, and every task is captured,
AI-extracted, reviewed, and dispatched to workers — with measurements, diagrams,
and photos — in minutes instead of hours.

---

## Tech stack

| Layer | Technology |
|---|---|
| Mobile | React Native + Expo SDK 51 |
| Navigation | Expo Router 3 (file-based) |
| Language | TypeScript (strict) |
| Auth | Supabase magic link |
| Database | Supabase Postgres + RLS |
| Realtime | Supabase Realtime |
| Storage | Supabase Storage (4 buckets) |
| Camera | expo-camera |
| Audio | expo-av (.m4a) |
| Transcription | OpenAI whisper-1 |
| Task extraction | OpenAI gpt-4o (via Edge Function) |
| Diagrams | react-native-svg |
| Push notifications | Expo Notifications + pg_net trigger |
| Offline queue | AsyncStorage + NetInfo |
| Distribution | EAS Build → TestFlight |

---

## Quick start (demo mode — no accounts needed)

```bash
git clone <repo>
cd fieldwork-app
npm install
node scripts/generate-assets.js   # creates placeholder icon/splash
npx expo start
```

Scan the QR code with **Expo Go** on your iPhone.
The app runs fully in demo mode when env vars are missing.

---

## Full production setup

### Step 1 — Supabase project

1. Create project at https://supabase.com → choose US West region
2. Save your database password

**Run SQL migrations in order** (Supabase → SQL Editor):

```
supabase/migrations/001_schema.sql       Core tables + triggers
supabase/migrations/002_rls.sql          Row Level Security policies
supabase/migrations/003_storage.sql      Storage buckets + policies
supabase/migrations/004_push_tokens.sql  Push token column
supabase/migrations/005_notification_triggers.sql  DB-level push triggers
supabase/seed/demo_house.sql             Optional: Meridian Ridge demo data
```

After running 005, store your secrets in Supabase Vault:
```sql
select vault.create_secret('supabase_url',     'https://YOUR_PROJECT.supabase.co');
select vault.create_secret('service_role_key', 'YOUR_SERVICE_ROLE_KEY');
```

**Configure auth** (Supabase → Authentication → URL Configuration):
- Site URL: `fieldwork://`
- Redirect URLs: add `fieldwork://auth/callback`

### Step 2 — Deploy Edge Functions

```bash
npm install -g supabase

supabase login
supabase link --project-ref YOUR_PROJECT_REF

# Deploy both functions
supabase functions deploy extract-tasks
supabase functions deploy send-notification

# Set the OpenAI key as a secret (never in the app binary)
supabase secrets set OPENAI_API_KEY=sk-your-key-here
```

### Step 3 — Environment variables

```bash
cp .env.example .env.local
```

Edit `.env.local`:
```
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIs...
EXPO_PUBLIC_OPENAI_API_KEY=sk-...   # only needed for local dev whisper calls
```

`EXPO_PUBLIC_OPENAI_API_KEY` is only used for direct whisper-1 transcription from
the device. gpt-4o extraction always goes through the Edge Function.
In production you can add a second Edge Function for transcription and remove
this key from the app entirely.

### Step 4 — Run locally

```bash
npx expo start
```

Use a **real iPhone** for camera and audio — the simulator can't test those.

---

## TestFlight distribution

```bash
# 1. Install EAS CLI and log in
npm install -g eas-cli
eas login

# 2. Configure your Apple credentials in eas.json
#    - appleId: your Apple Developer email
#    - ascAppId: App Store Connect app ID (create the app first)
#    - appleTeamId: from developer.apple.com/account

# 3. Store env vars in EAS (not in eas.json — those are committed)
eas env:create --scope project --name EXPO_PUBLIC_SUPABASE_URL      --value "https://..."
eas env:create --scope project --name EXPO_PUBLIC_SUPABASE_ANON_KEY  --value "eyJ..."
eas env:create --scope project --name EXPO_PUBLIC_OPENAI_API_KEY     --value "sk-..."

# 4. Build (runs in EAS cloud, ~10 min)
eas build --platform ios --profile preview

# 5. Submit to TestFlight
eas submit --platform ios

# 6. Invite testers
# App Store Connect → Your App → TestFlight → Internal Testing → Add testers
```

---

## Complete file structure

```
fieldwork-app/
│
├── app/                                  Expo Router screens
│   ├── _layout.tsx                       Root: AuthProvider + ErrorBoundary + route guard
│   ├── index.tsx                         Redirect to sign-in
│   ├── settings.tsx                      Shared settings (boss + worker)
│   │
│   ├── (auth)/
│   │   ├── sign-in.tsx                   Magic link form + demo fallback
│   │   └── callback.tsx                  Deep link handler for magic link return
│   │
│   ├── (boss)/
│   │   ├── jobs/
│   │   │   ├── index.tsx                 Job list (live Supabase)
│   │   │   ├── [id].tsx                  Job detail + rooms + actions
│   │   │   ├── create/index.tsx          Create new job form
│   │   │   ├── plans/index.tsx           Floor plan upload
│   │   │   └── rooms/index.tsx           Room management
│   │   ├── walkthrough/[jobId].tsx       Capture: camera + audio + controls
│   │   ├── review/[jobId].tsx            Review AI-extracted tasks
│   │   └── tasks/
│   │       ├── index.tsx                 All tasks (live Realtime)
│   │       └── [id].tsx                  Task detail (boss view)
│   │
│   └── (worker)/
│       └── tasks/
│           ├── index.tsx                 My tasks (live Realtime)
│           └── [id].tsx                  Task detail (worker view)
│
├── src/
│   ├── constants/
│   │   └── tokens.ts                     All colors, spacing, radii, font sizes
│   │
│   ├── types/
│   │   └── index.ts                      All TypeScript types + AppRoutes
│   │
│   ├── data/                             Demo data (fallback when offline/no Supabase)
│   │   ├── jobs.ts
│   │   ├── rooms.ts
│   │   ├── tasks.ts
│   │   └── extracted.ts                  AI-extracted demo tasks + transcript chunks
│   │
│   ├── context/
│   │   └── AuthContext.tsx               Supabase auth + demo signInDemo()
│   │
│   ├── lib/
│   │   └── supabase.ts                   Supabase client (AsyncStorage sessions)
│   │
│   ├── services/
│   │   ├── openai.ts                     whisper-1 + gpt-4o (routes via Edge Function)
│   │   ├── database.ts                   Core Supabase DB operations
│   │   ├── databaseExtras.ts             M4 additions: boss lookup, task updates
│   │   ├── storage.ts                    Supabase Storage uploads (4 buckets)
│   │   ├── offlineQueue.ts               AsyncStorage queue + NetInfo flush
│   │   ├── queueHandlers.ts              Registers flush handlers at app startup
│   │   └── notifications.ts             Client-side notification dispatch helpers
│   │
│   ├── hooks/
│   │   ├── useJobs.ts                    Live job list with demo fallback
│   │   ├── useJob.ts                     Single job + rooms with demo fallback
│   │   ├── useRealtimeTasks.ts           Supabase Realtime task subscription
│   │   ├── useAudioRecorder.ts           expo-av recording lifecycle
│   │   ├── useCamera.ts                  expo-camera permission + snapshots
│   │   └── useNotifications.ts          Push token registration + unread count
│   │
│   └── components/
│       ├── ui/
│       │   ├── Avatar.tsx               Initials circle (amber=boss, blue=worker)
│       │   ├── Badge.tsx                Colored pill badge (5 variants)
│       │   ├── Btn.tsx                  Button (default/primary/danger/success)
│       │   ├── BottomNav.tsx            2–3 tab bottom navigation bar
│       │   ├── ErrorBoundary.tsx        React class error boundary
│       │   ├── Header.tsx               Screen header with back button
│       │   ├── feedback.tsx             EmptyState, LoadingState, ErrorBanner, OfflineBanner
│       │   └── shared.tsx               ProgressBar, StatRow, TabFilter, SectionLabel, Separator
│       │
│       ├── task/
│       │   ├── TaskItem.tsx             List row with status dot + badges
│       │   ├── TaskDetailScreen.tsx     Shared detail (boss + worker, live updates)
│       │   └── MeasurementDiagram.tsx   SVG install diagram (height + offset)
│       │
│       └── walkthrough/
│           ├── ControlBtn.tsx           Big tap targets (Snap/Room/Assign/Pri/Stage)
│           ├── SnapshotStrip.tsx        Horizontal thumbnail strip
│           └── TranscriptBox.tsx        Live transcript display
│
├── supabase/
│   ├── functions/
│   │   ├── import_map.json              Deno import map for Edge Functions
│   │   ├── extract-tasks/index.ts       OpenAI proxy: whisper + gpt-4o extraction
│   │   └── send-notification/index.ts   Expo push notification dispatcher
│   │
│   ├── migrations/
│   │   ├── 001_schema.sql               Full DB schema (10 tables + triggers)
│   │   ├── 002_rls.sql                  Row Level Security policies
│   │   ├── 003_storage.sql              Storage buckets + policies
│   │   ├── 004_push_tokens.sql          push_token column
│   │   └── 005_notification_triggers.sql  pg_net DB triggers for auto-push
│   │
│   └── seed/
│       └── demo_house.sql               Meridian Ridge Estate demo data
│
├── assets/
│   ├── README.md                        Asset requirements + generation guide
│   ├── icon.png                         (placeholder — replace before App Store)
│   ├── adaptive-icon.png                (placeholder)
│   ├── splash.png                       (placeholder)
│   └── favicon.png                      (placeholder)
│
├── scripts/
│   └── generate-assets.js               Generates placeholder PNG assets
│
├── .env.example                         Environment variable template
├── .gitignore
├── app.json                             Expo config + permissions
├── babel.config.js
├── eas.json                             EAS Build profiles
├── package.json
└── tsconfig.json
```

---

## Demo mode

The app detects missing `EXPO_PUBLIC_SUPABASE_URL` and switches to demo mode:

| Feature | Demo behaviour |
|---|---|
| Sign-in | Shows demo user cards instead of email form |
| Jobs | Reads from `src/data/jobs.ts` |
| Rooms | Reads from `src/data/rooms.ts` |
| Tasks | Reads from `src/data/tasks.ts` |
| Walkthrough | Simulates transcript streaming |
| AI extraction | Uses `src/data/extracted.ts` |
| Review/publish | Local state only (no DB write) |
| Status updates | Local state only |
| Photo uploads | Shows success UI, no actual upload |
| Push notifications | Skipped silently |
| Offline queue | Still tracks items in AsyncStorage |

Demo mode is intentional — you can send TestFlight builds to clients before
Supabase is fully configured and they can tap through the complete workflow.

---

## User roles

| Action | Boss | Worker |
|---|---|---|
| Create jobs | ✓ | — |
| Start walkthrough | ✓ | — |
| Review + publish tasks | ✓ | — |
| View all tasks on job | ✓ | — |
| Upload floor plans | ✓ | — |
| Manage rooms | ✓ | — |
| View assigned tasks | ✓ | ✓ |
| Mark in progress / done | ✓ | ✓ |
| Upload completion photos | ✓ | ✓ |
| Post comments | ✓ | ✓ |
| Delete jobs or plans | ✓ | — |

---

## Offline behaviour

When the network drops during a walkthrough:
- Transcript text is kept in component state (never lost)
- Snapshot URIs are stored locally
- Audio upload is queued in AsyncStorage (`@fieldwork/offline_queue`)
- Snapshot uploads are queued in AsyncStorage
- The OfflineBanner shows pending item count

When the network reconnects:
- `NetInfo` detects the change
- `flushQueue()` runs automatically
- All queued items upload in order
- Failed items retry up to 5 times before being dropped

---

## Troubleshooting

**"Metro bundler crash on start"**
```bash
npx expo start --clear
```

**"Camera not ready" during walkthrough**
Go to iOS Settings → Fieldwork → Camera → enable. Must use a real device.

**"Whisper transcription returns empty"**
Recording must be > 0.5 seconds. Check microphone permission is granted.

**"Extraction failed — gpt-4o"**
- In demo mode: this falls back to pre-baked data automatically
- In production: check the `extract-tasks` Edge Function is deployed and `OPENAI_API_KEY` is set as a secret (`supabase secrets list`)

**"RLS permission denied for table tasks"**
The user must exist in `job_members` for the job. Check the `handle_new_user` trigger
created a `users` row after sign-up (`select * from public.users`).

**"Magic link not opening app"**
Verify `fieldwork://auth/callback` is in Supabase → Authentication → URL Configuration → Redirect URLs. The app scheme in `app.json` must be `"fieldwork"`.

**"EAS build fails: No Apple credentials"**
```bash
eas credentials
```
Follow the prompts to generate a distribution certificate and provisioning profile.

**"Push notifications not arriving"**
- Notifications require a real device (not simulator)
- Check permission is granted: iOS Settings → Fieldwork → Notifications
- Verify `push_token` was saved: `select id, push_token from public.users`
- Check the `send-notification` Edge Function logs in Supabase → Edge Functions

**"Notification triggers not firing"**
- Confirm `pg_net` extension is enabled: `select * from pg_extension where extname = 'pg_net'`
- Check Vault secrets are set: `select name from vault.secrets`
- Test manually: `select net.http_post(url := 'https://httpbin.org/post', body := '{"test":1}'::jsonb)`

---

## What's next (V2 ideas)

- Multi-page PDF floor plan rendering (react-native-pdf)
- Room polygon drawing on floor plan
- Task editing screen (edit title/description/measurements post-publish)
- Worker-to-boss question flow with threading
- Cross-job task templates for common electrical items
- Time tracking per task
- Homeowner portal (read-only progress view)
- Supabase Edge Function for whisper-1 (removes last direct API key from app)
- Photo annotation (markup over snapshots)
- Export to PDF work order
