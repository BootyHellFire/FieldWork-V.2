/**
 * AuthContext — Milestone 2
 *
 * Replaces the demo role-picker with real Supabase magic-link auth.
 * After sign-in, we fetch the user's role from the `users` table.
 *
 * Flow:
 *   1. User enters email → sendMagicLink()
 *   2. They tap the link in their email → deep link opens the app
 *   3. Supabase session is set automatically
 *   4. We fetch role from `users` table → route to boss or worker view
 */

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { UserRole, DemoUser } from '@/types';

interface AuthContextValue {
  session: Session | null;
  user: DemoUser | null;
  loading: boolean;
  sendMagicLink: (email: string) => Promise<void>;
  signInDemo: (role: UserRole) => void;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const DEMO_USERS: Record<UserRole, DemoUser> = {
  boss:   { id: 'demo-boss',   name: 'Mike Torres', initials: 'MT', role: 'boss'   },
  worker: { id: 'demo-worker', name: 'Jake Ruiz',   initials: 'JR', role: 'worker' },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user,    setUser]    = useState<DemoUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        loadUserProfile(data.session.user);
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, newSession) => {
        setSession(newSession);
        if (newSession?.user) {
          await loadUserProfile(newSession.user);
        } else {
          setUser(null);
          setLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  async function loadUserProfile(authUser: User) {
    try {
      const { data } = await supabase
        .from('users')
        .select('id, full_name, role')
        .eq('id', authUser.id)
        .single();

      if (data) {
        const parts    = (data.full_name as string).split(' ');
        const initials = parts.map((p: string) => p[0]).join('').slice(0, 2).toUpperCase();
        setUser({ id: data.id, name: data.full_name, initials, role: data.role as UserRole });
      }
    } catch (err) {
      console.error('[Auth] Failed to load user profile:', err);
    } finally {
      setLoading(false);
    }
  }

  const sendMagicLink = useCallback(async (email: string) => {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: 'fieldwork://auth/callback' },
    });
    if (error) throw error;
  }, []);

  const signInDemo = useCallback((role: UserRole) => {
    setUser(DEMO_USERS[role]);
    setLoading(false);
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ session, user, loading, sendMagicLink, signInDemo, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
