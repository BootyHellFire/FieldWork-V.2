// ControlBtn — the 5 big tap targets on the walkthrough capture screen
// (Snap, Room, Assign, Priority, Stage)

import React from 'react';
import { TouchableOpacity, Text, View, StyleSheet } from 'react-native';
import { colors, radii, fontSizes } from '@/constants/tokens';

interface ControlBtnProps {
  icon: string;
  label: string;
  active?: boolean;
  onPress: () => void;
}

export function ControlBtn({ icon, label, active = false, onPress }: ControlBtnProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={[styles.btn, active && styles.btnActive]}
    >
      <Text style={[styles.icon, active && styles.iconActive]}>{icon}</Text>
      <Text style={[styles.label, active && styles.labelActive]} numberOfLines={1}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  btn: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 4,
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.bg2,
    gap: 4,
    minHeight: 60,
    justifyContent: 'center',
  },
  btnActive: {
    borderColor: colors.amberD,
    backgroundColor: colors.amberBg,
  },
  icon: {
    fontSize: 18,
    color: colors.text3,
  },
  iconActive: {
    color: colors.amber,
  },
  label: {
    fontSize: fontSizes.xs,
    color: colors.text3,
    textAlign: 'center',
  },
  labelActive: {
    color: colors.amberT,
  },
});
