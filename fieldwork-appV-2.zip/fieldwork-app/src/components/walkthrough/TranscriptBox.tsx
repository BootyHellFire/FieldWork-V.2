// Live transcript area shown below the camera preview during a walkthrough.

import React, { useEffect, useRef } from 'react';
import { ScrollView, Text, StyleSheet } from 'react-native';
import { colors, fontSizes, radii } from '@/constants/tokens';

interface TranscriptBoxProps {
  text: string;
  wordCount: number;
}

export function TranscriptBox({ text, wordCount }: TranscriptBoxProps) {
  const scrollRef = useRef<ScrollView>(null);

  // Auto-scroll to bottom as new words arrive
  useEffect(() => {
    scrollRef.current?.scrollToEnd({ animated: true });
  }, [text]);

  return (
    <>
      <Text style={styles.meta}>
        Live transcript · <Text style={styles.wc}>{wordCount} words</Text>
      </Text>
      <ScrollView
        ref={scrollRef}
        style={styles.box}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.text}>
          {text || 'Waiting to start recording...'}
        </Text>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  meta: {
    fontSize: fontSizes.sm,
    color: colors.text3,
    marginBottom: 5,
  },
  wc: {
    color: colors.text3,
    fontSize: fontSizes.xs,
  },
  box: {
    backgroundColor: colors.bg0,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    paddingHorizontal: 13,
    paddingVertical: 11,
    minHeight: 90,
    maxHeight: 115,
  },
  text: {
    fontSize: fontSizes.sm,
    color: colors.text2,
    lineHeight: 20,
  },
});
