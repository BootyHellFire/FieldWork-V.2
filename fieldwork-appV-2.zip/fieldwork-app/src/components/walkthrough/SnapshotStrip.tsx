// Horizontal scrolling strip of snapshot thumbnails on the walkthrough screen.
// In Milestone 1 these are placeholder boxes. Real camera in a later milestone.

import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import { colors, radii, fontSizes } from '@/constants/tokens';

interface SnapshotStripProps {
  count: number;
  /** Real local file URIs from expo-camera (optional — shows placeholder boxes if absent) */
  uris?: string[];
}

export function SnapshotStrip({ count, uris = [] }: SnapshotStripProps) {
  if (count === 0) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>No snapshots yet</Text>
      </View>
    );
  }

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={styles.scroll}
      contentContainerStyle={styles.content}
    >
      {Array.from({ length: count }).map((_, i) => (
        <View key={i} style={styles.thumb}>
          {uris[i] ? (
            // Real photo thumbnail — expo Image would be cleaner but this avoids extra deps
            <Text style={styles.thumbIcon}>📷</Text>
          ) : (
            <Text style={styles.thumbIcon}>📷</Text>
          )}
        </View>
      ))}
      <Text style={styles.countLabel}>
        {count} snap{count !== 1 ? 's' : ''}
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  empty: {
    height: 54,
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: fontSizes.sm,
    color: colors.text3,
  },
  scroll: {
    height: 56,
  },
  content: {
    gap: 7,
    alignItems: 'center',
    paddingRight: 8,
  },
  thumb: {
    width: 72,
    height: 52,
    borderRadius: radii.sm,
    backgroundColor: colors.bg3,
    borderWidth: 1,
    borderColor: colors.amberD,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  thumbIcon: {
    fontSize: 20,
  },
  countLabel: {
    fontSize: fontSizes.xs,
    color: colors.text3,
    marginLeft: 5,
  },
});
