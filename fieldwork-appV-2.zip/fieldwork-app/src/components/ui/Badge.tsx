import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import { colors, radii, fontSizes, fontWeights } from '@/constants/tokens';

export type BadgeVariant =
  | 'amber'   // stage / active / foreman
  | 'green'   // done / success
  | 'red'     // high priority
  | 'blue'    // room / info
  | 'gray';   // neutral

interface BadgeProps {
  label: string;
  variant?: BadgeVariant;
  style?: ViewStyle;
}

const variantStyles: Record<BadgeVariant, { bg: string; text: string; border: string }> = {
  amber: { bg: colors.amberBg,  text: colors.amberT,  border: colors.amberBdr },
  green: { bg: colors.greenBg,  text: colors.greenT,  border: colors.greenBdr },
  red:   { bg: colors.redBg,    text: colors.redT,    border: colors.redBdr   },
  blue:  { bg: colors.blueBg,   text: colors.blueT,   border: colors.blueBdr  },
  gray:  { bg: colors.bg3,      text: colors.text2,   border: colors.border2  },
};

export function Badge({ label, variant = 'gray', style }: BadgeProps) {
  const v = variantStyles[variant];
  return (
    <View
      style={[
        styles.container,
        { backgroundColor: v.bg, borderColor: v.border },
        style,
      ]}
    >
      <Text style={[styles.text, { color: v.text }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: radii.full,
    borderWidth: 1,
    paddingHorizontal: 9,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: fontSizes.xs,
    fontWeight: fontWeights.medium,
  },
});
