/**
 * ErrorBoundary — catches unhandled React render errors.
 * Shows a friendly recovery screen instead of a blank crash.
 *
 * Usage: wrap the root navigator in app/_layout.tsx
 */

import React, { Component, ReactNode } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
} from 'react-native';
import { colors, fontSizes, fontWeights, spacing } from '@/constants/tokens';

interface Props { children: ReactNode; }
interface State { hasError: boolean; error: Error | null; }

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: { componentStack: string }) {
    console.error('[ErrorBoundary]', error.message);
    console.error(info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <View style={styles.root}>
        <Text style={styles.icon}>⚡</Text>
        <Text style={styles.title}>Something went wrong</Text>
        <Text style={styles.message}>
          {this.state.error?.message ?? 'An unexpected error occurred.'}
        </Text>
        <TouchableOpacity
          style={styles.btn}
          onPress={() => this.setState({ hasError: false, error: null })}
          activeOpacity={0.7}
        >
          <Text style={styles.btnText}>Try again</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  root:    { flex: 1, backgroundColor: colors.bg0, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
  icon:    { fontSize: 44, marginBottom: 16 },
  title:   { fontSize: fontSizes.xl, fontWeight: fontWeights.semibold, color: colors.text1, marginBottom: 10, textAlign: 'center' },
  message: { fontSize: fontSizes.sm, color: colors.text3, textAlign: 'center', lineHeight: 20, marginBottom: 32 },
  btn:     { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 8, borderWidth: 1, borderColor: colors.border2 },
  btnText: { fontSize: fontSizes.base, color: colors.text2 },
});
