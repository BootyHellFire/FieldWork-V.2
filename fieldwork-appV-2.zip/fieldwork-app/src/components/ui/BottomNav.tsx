import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fontSizes } from '@/constants/tokens';

export interface NavItem {
  key: string;
  label: string;
  icon: string; // emoji or simple string stand-in for Milestone 1
}

interface BottomNavProps {
  items: NavItem[];
  activeKey: string;
  onPress: (key: string) => void;
}

export function BottomNav({ items, activeKey, onPress }: BottomNavProps) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.container, { paddingBottom: insets.bottom + 4 }]}>
      {items.map(item => {
        const active = item.key === activeKey;
        return (
          <TouchableOpacity
            key={item.key}
            style={styles.item}
            onPress={() => onPress(item.key)}
            activeOpacity={0.7}
          >
            <Text style={[styles.icon, active && styles.activeIcon]}>
              {item.icon}
            </Text>
            <Text style={[styles.label, active && styles.activeLabel]}>
              {item.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// Nav item sets for boss and worker
export const BOSS_NAV: NavItem[] = [
  { key: 'jobs',     label: 'Jobs',     icon: '⌂' },
  { key: 'tasks',    label: 'Tasks',    icon: '≡' },
  { key: 'settings', label: 'Settings', icon: '⚙' },
];

export const WORKER_NAV: NavItem[] = [
  { key: 'tasks',    label: 'My Tasks', icon: '≡' },
  { key: 'settings', label: 'Settings', icon: '⚙' },
];

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.bg1,
    paddingTop: 2,
  },
  item: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 9,
    gap: 3,
  },
  icon: {
    fontSize: 16,
    color: colors.text3,
  },
  activeIcon: {
    color: colors.amber,
  },
  label: {
    fontSize: fontSizes.xs,
    color: colors.text3,
  },
  activeLabel: {
    color: colors.amber,
  },
});
