/**
 * EmptyState — shown when a list has no items
 * LoadingState — centered spinner for full-screen loads
 * ErrorBanner — dismissable top banner for non-fatal errors
 * OfflineBanner — amber bar shown when there are queued items
 */

import React, { useEffect, useState } from 'react';
import {
  View, Text, ActivityIndicator, TouchableOpacity, StyleSheet,
} from 'react-native';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';
import { pendingCount } from '@/services/offlineQueue';

// ─── EmptyState ───────────────────────────────────────

interface EmptyStateProps {
  icon?: string;
  title: string;
  subtitle?: string;
  action?: { label: string; onPress: () => void };
}

export function EmptyState({ icon = '📋', title, subtitle, action }: EmptyStateProps) {
  return (
    <View style={esStyles.root}>
      <Text style={esStyles.icon}>{icon}</Text>
      <Text style={esStyles.title}>{title}</Text>
      {subtitle ? <Text style={esStyles.subtitle}>{subtitle}</Text> : null}
      {action ? (
        <TouchableOpacity style={esStyles.btn} onPress={action.onPress} activeOpacity={0.7}>
          <Text style={esStyles.btnText}>{action.label}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const esStyles = StyleSheet.create({
  root:     { alignItems: 'center', paddingVertical: 48, paddingHorizontal: spacing.xl },
  icon:     { fontSize: 36, marginBottom: 14 },
  title:    { fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.text1, textAlign: 'center', marginBottom: 6 },
  subtitle: { fontSize: fontSizes.sm, color: colors.text3, textAlign: 'center', lineHeight: 20, marginBottom: 20 },
  btn:      { paddingHorizontal: 18, paddingVertical: 9, borderRadius: radii.md, borderWidth: 1, borderColor: colors.border2 },
  btnText:  { fontSize: fontSizes.sm, color: colors.text2 },
});

// ─── LoadingState ─────────────────────────────────────

interface LoadingStateProps {
  message?: string;
}

export function LoadingState({ message }: LoadingStateProps) {
  return (
    <View style={lsStyles.root}>
      <ActivityIndicator size="large" color={colors.amber} />
      {message ? <Text style={lsStyles.text}>{message}</Text> : null}
    </View>
  );
}

const lsStyles = StyleSheet.create({
  root: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14 },
  text: { fontSize: fontSizes.sm, color: colors.text3 },
});

// ─── ErrorBanner ──────────────────────────────────────

interface ErrorBannerProps {
  message: string;
  onDismiss: () => void;
}

export function ErrorBanner({ message, onDismiss }: ErrorBannerProps) {
  return (
    <View style={ebStyles.banner}>
      <Text style={ebStyles.text} numberOfLines={2}>{message}</Text>
      <TouchableOpacity onPress={onDismiss} activeOpacity={0.7}>
        <Text style={ebStyles.dismiss}>✕</Text>
      </TouchableOpacity>
    </View>
  );
}

const ebStyles = StyleSheet.create({
  banner: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.redBg, borderBottomWidth: 1, borderBottomColor: colors.redBdr,
    paddingHorizontal: spacing.lg, paddingVertical: 10,
  },
  text:    { flex: 1, fontSize: fontSizes.sm, color: colors.redT },
  dismiss: { fontSize: fontSizes.md, color: colors.redT, paddingHorizontal: 4 },
});

// ─── OfflineBanner ────────────────────────────────────

export function OfflineBanner() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let mounted = true;
    const check = async () => {
      const n = await pendingCount();
      if (mounted) setCount(n);
    };
    check();
    const id = setInterval(check, 10000); // re-check every 10s
    return () => { mounted = false; clearInterval(id); };
  }, []);

  if (count === 0) return null;

  return (
    <View style={obStyles.banner}>
      <Text style={obStyles.dot}>●</Text>
      <Text style={obStyles.text}>
        {count} item{count > 1 ? 's' : ''} pending sync — will upload when back online
      </Text>
    </View>
  );
}

const obStyles = StyleSheet.create({
  banner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: colors.amberBg,
    borderBottomWidth: 1, borderBottomColor: colors.amberBdr,
    paddingHorizontal: spacing.lg, paddingVertical: 8,
  },
  dot:  { fontSize: 9, color: colors.amber },
  text: { fontSize: fontSizes.xs, color: colors.amberT, flex: 1 },
});
