import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

// ─── ProgressBar ─────────────────────────────────────
interface ProgressBarProps {
  /** 0 to 1 */
  progress: number;
}

export function ProgressBar({ progress }: ProgressBarProps) {
  const pct = Math.min(1, Math.max(0, progress)) * 100;
  return (
    <View style={pbStyles.track}>
      <View style={[pbStyles.fill, { width: `${pct}%` }]} />
    </View>
  );
}

const pbStyles = StyleSheet.create({
  track: {
    height: 3,
    backgroundColor: colors.bg3,
    borderRadius: 2,
    marginVertical: 7,
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    backgroundColor: colors.amber,
    borderRadius: 2,
  },
});

// ─── SectionLabel ─────────────────────────────────────
interface SectionLabelProps {
  text: string;
  topSpacing?: boolean;
}

export function SectionLabel({ text, topSpacing = true }: SectionLabelProps) {
  return (
    <Text style={[slStyles.text, topSpacing && { marginTop: spacing.xl }]}>
      {text.toUpperCase()}
    </Text>
  );
}

const slStyles = StyleSheet.create({
  text: {
    fontSize: fontSizes.xs,
    fontWeight: fontWeights.medium,
    color: colors.text3,
    letterSpacing: 0.6,
    marginBottom: spacing.sm,
  },
});

// ─── Separator ────────────────────────────────────────
export function Separator() {
  return <View style={sepStyles.line} />;
}

const sepStyles = StyleSheet.create({
  line: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.md,
  },
});

// ─── StatRow (3-column metric cards) ─────────────────
interface Stat {
  value: string | number;
  label: string;
}

interface StatRowProps {
  stats: [Stat, Stat, Stat];
}

export function StatRow({ stats }: StatRowProps) {
  return (
    <View style={srStyles.row}>
      {stats.map((s, i) => (
        <View key={i} style={srStyles.cell}>
          <Text style={srStyles.value}>{s.value}</Text>
          <Text style={srStyles.label}>{s.label}</Text>
        </View>
      ))}
    </View>
  );
}

const srStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 13,
  },
  cell: {
    flex: 1,
    backgroundColor: colors.bg2,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: 'center',
  },
  value: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.semibold,
    color: colors.text1,
    lineHeight: 26,
  },
  label: {
    fontSize: fontSizes.xs,
    color: colors.text3,
    marginTop: 2,
  },
});

// ─── TabFilter (horizontal scrolling pill tabs) ───────
interface TabFilterProps {
  tabs: { key: string; label: string }[];
  activeKey: string;
  onPress: (key: string) => void;
}

export function TabFilter({ tabs, activeKey, onPress }: TabFilterProps) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={tfStyles.scroll}
      contentContainerStyle={tfStyles.content}
    >
      {tabs.map(tab => {
        const active = tab.key === activeKey;
        return (
          <TouchableOpacity
            key={tab.key}
            onPress={() => onPress(tab.key)}
            activeOpacity={0.7}
            style={[tfStyles.tab, active && tfStyles.activeTab]}
          >
            <Text style={[tfStyles.label, active && tfStyles.activeLabel]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const tfStyles = StyleSheet.create({
  scroll: {
    marginBottom: 13,
  },
  content: {
    gap: 6,
    paddingRight: 16,
  },
  tab: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: radii.full,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'transparent',
  },
  activeTab: {
    backgroundColor: colors.amberBg,
    borderColor: colors.amberBdr,
  },
  label: {
    fontSize: fontSizes.sm,
    color: colors.text3,
  },
  activeLabel: {
    color: colors.amberT,
  },
});
