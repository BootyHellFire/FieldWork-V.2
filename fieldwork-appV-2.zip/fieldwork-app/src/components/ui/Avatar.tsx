import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fontWeights, radii } from '@/constants/tokens';

interface AvatarProps {
  initials: string;
  role: 'boss' | 'worker';
  size?: number;
}

export function Avatar({ initials, role, size = 30 }: AvatarProps) {
  const bg     = role === 'boss'   ? colors.amberBg  : colors.blueBg;
  const color  = role === 'boss'   ? colors.amberT   : colors.blueT;
  const border = role === 'boss'   ? colors.amberBdr : colors.blueBdr;

  return (
    <View
      style={[
        styles.base,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: bg,
          borderColor: border,
        },
      ]}
    >
      <Text
        style={[
          styles.text,
          { color, fontSize: size * 0.38 },
        ]}
      >
        {initials}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  text: {
    fontWeight: fontWeights.semibold,
  },
});
