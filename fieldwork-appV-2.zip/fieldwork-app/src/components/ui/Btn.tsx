import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
  ActivityIndicator,
} from 'react-native';
import { colors, radii, fontSizes, fontWeights } from '@/constants/tokens';

export type BtnVariant = 'default' | 'primary' | 'danger' | 'success';

interface BtnProps {
  label: string;
  onPress: () => void;
  variant?: BtnVariant;
  fullWidth?: boolean;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export function Btn({
  label,
  onPress,
  variant = 'default',
  fullWidth = false,
  disabled = false,
  loading = false,
  style,
  textStyle,
}: BtnProps) {
  const vs = variantMap[variant];
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
      style={[
        styles.base,
        { backgroundColor: vs.bg, borderColor: vs.border },
        fullWidth && styles.fullWidth,
        (disabled || loading) && styles.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={vs.text} />
      ) : (
        <Text style={[styles.text, { color: vs.text }, textStyle]}>{label}</Text>
      )}
    </TouchableOpacity>
  );
}

const variantMap: Record<BtnVariant, { bg: string; border: string; text: string }> = {
  default: {
    bg: 'transparent',
    border: colors.border2,
    text: colors.text1,
  },
  primary: {
    bg: colors.amber,
    border: colors.amberD,
    text: '#0D0800',
  },
  danger: {
    bg: colors.redBg,
    border: '#3A1414',
    text: colors.redT,
  },
  success: {
    bg: colors.greenBg,
    border: '#122B18',
    text: colors.greenT,
  },
};

const styles = StyleSheet.create({
  base: {
    borderWidth: 1,
    borderRadius: radii.md,
    paddingHorizontal: 16,
    paddingVertical: 11,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 44,
  },
  fullWidth: {
    width: '100%',
  },
  disabled: {
    opacity: 0.38,
  },
  text: {
    fontSize: fontSizes.base,
    fontWeight: fontWeights.medium,
  },
});
