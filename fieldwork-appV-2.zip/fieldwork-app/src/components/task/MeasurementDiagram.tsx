import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, {
  Line,
  Rect,
  Circle,
  Text as SvgText,
} from 'react-native-svg';
import { colors } from '@/constants/tokens';
import { Measurements } from '@/types';

interface MeasurementDiagramProps {
  measurements: Measurements;
}

/**
 * Renders a simple, not-to-scale SVG install diagram.
 * Shows floor line, left wall, device symbol, and labeled
 * dimension lines for height and optional horizontal offset.
 *
 * Returns null if there is no height measurement to draw.
 */
export function MeasurementDiagram({ measurements }: MeasurementDiagramProps) {
  const { heightFromFFL: h, offsetFromRightWall: r } = measurements;

  // No height = nothing to draw; parent shows text-only fallback
  if (!h) return null;

  // ── Layout constants ──────────────────────────────────
  const W   = 260;
  const H   = 148;
  const wx  = 40;   // left wall x
  const fy  = 118;  // floor y
  const wt  = 15;   // wall top y
  const rwx = W - 24; // right wall x

  // Scale: map 108 inches of room height to the drawable pixel height
  const roomHeightIn = 108;
  const scl = (fy - wt) / roomHeightIn;

  // Device position (clamped so it never clips outside the walls)
  const rawDy  = fy - h * scl;
  const rawDx  = r ? rwx - r * scl : (wx + rwx) / 2;
  const devY   = Math.max(wt + 14, Math.min(fy - 14, rawDy));
  const devX   = Math.max(wx + 18, Math.min(rwx - 18, rawDx));

  // Colors
  const am = colors.amber;       // device / accent
  const dm = colors.text3;       // dimension lines + labels
  const wc = colors.text2;       // wall lines

  return (
    <View style={styles.wrapper}>
      <Svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`}>

        {/* ── Walls & floor ─────────────────────────── */}
        <Line x1={wx}  y1={fy} x2={rwx} y2={fy} stroke={wc} strokeWidth={2.5} strokeLinecap="round" />
        <Line x1={wx}  y1={fy} x2={wx}  y2={wt} stroke={wc} strokeWidth={2.5} strokeLinecap="round" />
        {r && (
          <Line x1={rwx} y1={fy} x2={rwx} y2={wt} stroke={wc} strokeWidth={1.5} strokeLinecap="round" />
        )}

        {/* ── Device symbol (outlet / fixture) ─────── */}
        <Rect
          x={devX - 10} y={devY - 14}
          width={20} height={27}
          rx={2.5} ry={2.5}
          fill="none" stroke={am} strokeWidth={1.6}
        />
        <Rect x={devX - 5.5} y={devY - 9} width={3.5} height={9} rx={1} fill={am} />
        <Rect x={devX + 2}   y={devY - 9} width={3.5} height={9} rx={1} fill={am} />
        <Circle cx={devX} cy={devY + 8} r={2.8} fill="none" stroke={am} strokeWidth={1.2} />

        {/* ── Height dimension line (left of wall) ──── */}
        <Line x1={wx - 10} y1={fy}   x2={wx - 10} y2={devY} stroke={dm} strokeWidth={0.9} />
        <Line x1={wx - 7}  y1={fy}   x2={wx - 13} y2={fy}   stroke={dm} strokeWidth={0.9} />
        <Line x1={wx - 7}  y1={devY} x2={wx - 13} y2={devY} stroke={dm} strokeWidth={0.9} />
        <SvgText
          x={wx - 15}
          y={(fy + devY) / 2 + 4}
          fill={dm}
          fontSize={9.5}
          fontFamily="Courier New"
          textAnchor="end"
        >
          {h}"
        </SvgText>

        {/* ── Horizontal offset dimension (above device) */}
        {r && (
          <>
            <Line x1={devX} y1={devY - 22} x2={rwx} y2={devY - 22} stroke={dm} strokeWidth={0.9} />
            <Line x1={devX} y1={devY - 19} x2={devX} y2={devY - 25} stroke={dm} strokeWidth={0.9} />
            <Line x1={rwx}  y1={devY - 19} x2={rwx}  y2={devY - 25} stroke={dm} strokeWidth={0.9} />
            <SvgText
              x={(devX + rwx) / 2}
              y={devY - 28}
              fill={dm}
              fontSize={9.5}
              fontFamily="Courier New"
              textAnchor="middle"
            >
              {r}"
            </SvgText>
          </>
        )}

        {/* ── FFL label ─────────────────────────────── */}
        <SvgText
          x={wx + 5} y={fy + 13}
          fill={dm} fontSize={9}
          fontFamily="Courier New"
        >
          FFL
        </SvgText>
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: colors.bg0,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    overflow: 'hidden',
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
});
