// ─── TaskItem ─────────────────────────────────────────
// List row used on both boss Tasks screen and worker Tasks screen.

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Task, TaskStatus } from '@/types';
import { Badge } from '@/components/ui/Badge';
import { colors, fontSizes, fontWeights, radii } from '@/constants/tokens';

interface TaskItemProps {
  task: Task;
  showAssignee?: boolean;
  onPress: () => void;
}

export function TaskItem({ task, showAssignee = true, onPress }: TaskItemProps) {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.75}
    >
      <StatusDot status={task.status} />
      <View style={styles.body}>
        <Text style={styles.title} numberOfLines={1}>
          {task.title}
        </Text>
        <View style={styles.pills}>
          <Badge label={task.room} variant="blue" />
          <Badge label={task.stage} variant="gray" />
          {task.priority === 'high' && <Badge label="High" variant="red" />}
          {showAssignee && (
            <Text style={styles.assignee}>→ {task.assignee}</Text>
          )}
        </View>
      </View>
      <Text style={styles.chevron}>›</Text>
    </TouchableOpacity>
  );
}

function StatusDot({ status }: { status: TaskStatus }) {
  const s = dotMap[status];
  return (
    <View
      style={[
        styles.dot,
        { backgroundColor: s.bg, borderColor: s.border },
      ]}
    >
      {status === 'done' && <Text style={[styles.dotIcon, { color: s.icon }]}>✓</Text>}
      {status === 'in_progress' && <Text style={[styles.dotIcon, { color: s.icon }]}>…</Text>}
    </View>
  );
}

const dotMap: Record<TaskStatus, { bg: string; border: string; icon: string }> = {
  pending:     { bg: 'transparent',   border: colors.border2,  icon: colors.text3 },
  in_progress: { bg: colors.blueBg,   border: colors.blueBdr,  icon: colors.blueT },
  done:        { bg: colors.greenBg,  border: colors.greenBdr, icon: colors.greenT },
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    backgroundColor: colors.bg2,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.lg,
    padding: 12,
    marginBottom: 7,
  },
  dot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
    flexShrink: 0,
  },
  dotIcon: {
    fontSize: 10,
    lineHeight: 12,
  },
  body: {
    flex: 1,
    gap: 5,
    minWidth: 0,
  },
  title: {
    fontSize: fontSizes.base,
    fontWeight: fontWeights.medium,
    color: colors.text1,
  },
  pills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 5,
    alignItems: 'center',
  },
  assignee: {
    fontSize: fontSizes.xs,
    color: colors.text3,
  },
  chevron: {
    color: colors.text3,
    fontSize: 18,
    flexShrink: 0,
  },
});
