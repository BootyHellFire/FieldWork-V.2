/**
 * TaskDetailScreen — M4
 *
 * Loads live task data via useTask() with demo fallback.
 * Wired to Supabase for:
 *   - Live task data (fetchTaskFull)
 *   - Status updates → Supabase tasks table + push notification to boss
 *   - Comment posting → task_comments table + push to job members
 *   - Completion photo upload → Supabase Storage + task_photos table
 */

import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, StyleSheet, Alert, Image, ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';

import { useTask } from '@/hooks/useTask';
import { Task, TaskStatus } from '@/types';
import { updateTaskStatus, addTaskComment } from '@/services/database';
import { uploadCompletionPhoto } from '@/services/storage';
import { addTaskPhoto } from '@/services/database';
import { notifyTaskDone, notifyNewComment } from '@/services/notifications';
import { fetchJobBoss, fetchJobMembers } from '@/services/databaseExtras';
import { useAuth } from '@/context/AuthContext';

import { Header } from '@/components/ui/Header';
import { Badge, BadgeVariant } from '@/components/ui/Badge';
import { Btn } from '@/components/ui/Btn';
import { Separator, SectionLabel } from '@/components/ui/shared';
import { LoadingState } from '@/components/ui/feedback';
import { MeasurementDiagram } from '@/components/task/MeasurementDiagram';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

interface Props { role: 'boss' | 'worker'; }

const STATUS_BADGE: Record<TaskStatus, { label: string; variant: BadgeVariant }> = {
  pending:     { label: 'Pending',     variant: 'gray'  },
  in_progress: { label: 'In progress', variant: 'blue'  },
  done:        { label: 'Complete',    variant: 'green' },
};

export function TaskDetailScreen({ role }: Props) {
  const { id }  = useLocalSearchParams<{ id: string }>();
  const router  = useRouter();
  const insets  = useSafeAreaInsets();
  const { user } = useAuth();

  // useTask loads live data from Supabase, falls back to demo data automatically
  const { task: liveTask, loading: taskLoading } = useTask(Number(id));

  // Local mutable copy so status changes + comments reflect immediately in the UI
  const [task,           setTask]           = useState<Task | null>(null);
  const [comment,        setComment]        = useState('');
  const [postingComment, setPostingComment] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [photoUris,      setPhotoUris]      = useState<string[]>([]);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // Sync live data into local state once loaded
  useEffect(() => {
    if (liveTask) setTask(liveTask);
  }, [liveTask]);

  if (taskLoading || !task) return <LoadingState message="Loading task..." />;

  const backRoute = role === 'boss' ? '/(boss)/tasks' : '/(worker)/tasks';
  const { label: stLabel, variant: stVariant } = STATUS_BADGE[task.status];
  const hasDiagram = !!task.measurements.heightFromFFL;

  // ── Status updates ────────────────────────────────
  const changeStatus = useCallback(async (newStatus: TaskStatus) => {
    setUpdatingStatus(true);
    try {
      if (!IS_DEMO && !task.id.toString().startsWith('demo')) {
        await updateTaskStatus(task.id, newStatus);

        // Notify boss when worker marks task done
        if (newStatus === 'done' && role === 'worker' && user) {
          // Look up the job's boss — for V1 we notify job creator via a simple query
          // The full implementation would look up job_members with role='boss'
          await notifyTaskDone({
            bossId:     await fetchJobBoss(task.jobId).catch(() => null) ?? '',
            workerName: user.name,
            taskTitle:  task.title,
            jobName:    'Meridian Ridge Estate',
          });
        }
      }
      setTask(prev => ({ ...prev, status: newStatus }));
    } catch (err: any) {
      Alert.alert('Update failed', err.message);
    } finally {
      setUpdatingStatus(false);
    }
  }, [task.id, task.title, role, user]);

  // ── Comment posting ───────────────────────────────
  async function handlePostComment() {
    if (!comment.trim()) return;
    setPostingComment(true);
    try {
      if (!IS_DEMO && user && !user.id.startsWith('demo')) {
        await addTaskComment(task.id, user.id, comment.trim());

        // Notify the boss + other job members (excluding the commenter)
        const allMembers = await fetchJobMembers(task.jobId).catch(() => [] as string[]);
        const recipients = allMembers.filter(id => id !== user.id);
        if (recipients.length > 0) {
          await notifyNewComment({
            recipientIds: recipients,
            authorName:   user.name,
            taskTitle:    task.title,
            commentText:  comment.trim(),
          });
        }
      }
      setTask(prev => ({
        ...prev,
        comments: [
          ...prev.comments,
          { who: user?.name ?? 'You', text: comment.trim(), timestamp: 'Just now' },
        ],
      }));
      setComment('');
    } catch (err: any) {
      Alert.alert('Comment failed', err.message);
    } finally {
      setPostingComment(false);
    }
  }

  // ── Completion photo upload ───────────────────────
  async function handleAddPhoto() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow photo library access in Settings.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });

    if (result.canceled || !result.assets[0]) return;
    const uri = result.assets[0].uri;

    setUploadingPhoto(true);
    try {
      if (!IS_DEMO && user && !user.id.startsWith('demo')) {
        const uploadedUrl = await uploadCompletionPhoto(uri, task.id);
        await addTaskPhoto(task.id, user.id, uploadedUrl, 'completion');
      }
      setPhotoUris(prev => [...prev, uri]);
    } catch (err: any) {
      Alert.alert('Photo upload failed', err.message);
    } finally {
      setUploadingPhoto(false);
    }
  }

  return (
    <View style={[styles.root, { paddingBottom: insets.bottom }]}>
      <Header
        title={task.title}
        onBack={() => router.push(backRoute as any)}
        right={role === 'boss' ? (
          <TouchableOpacity
            style={editBtnStyle}
            onPress={() => router.push(`/(boss)/tasks/edit?id=${task.id}` as any)}
            activeOpacity={0.7}
          >
            <Text style={editBtnTextStyle}>Edit</Text>
          </TouchableOpacity>
        ) : undefined}
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.inner}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Pills */}
        <View style={styles.pillRow}>
          <Badge label={task.room}    variant="blue"   />
          <Badge label={task.stage}   variant="gray"   />
          {task.priority === 'high' && <Badge label="High priority" variant="red" />}
          <Badge label={stLabel}      variant={stVariant} />
          <Text style={styles.assignee}>→ {task.assignee}</Text>
        </View>

        <Separator />

        <SectionLabel text="Description" topSpacing={false} />
        <Text style={styles.desc}>{task.description}</Text>

        <SectionLabel text="Measurements" />
        <View style={styles.mono}>
          <Text style={styles.monoText}>{task.measurements.label}</Text>
        </View>

        {hasDiagram && (
          <>
            <SectionLabel text="Install diagram" />
            <MeasurementDiagram measurements={task.measurements} />
          </>
        )}

        <SectionLabel text="Field note" />
        <View style={styles.snippet}>
          <Text style={styles.snippetText}>"{task.transcriptSnippet}"</Text>
        </View>

        {/* Photos */}
        <SectionLabel text="Photos" />
        <View style={styles.photoGrid}>
          {/* Uploaded photos */}
          {photoUris.map((uri, i) => (
            <Image key={i} source={{ uri }} style={styles.photoThumb} resizeMode="cover" />
          ))}

          {/* Add photo button */}
          <TouchableOpacity
            style={styles.addPhoto}
            onPress={handleAddPhoto}
            activeOpacity={0.75}
            disabled={uploadingPhoto}
          >
            {uploadingPhoto
              ? <ActivityIndicator color={colors.amber} size="small" />
              : <Text style={styles.addPhotoIcon}>+</Text>}
            <Text style={styles.addPhotoLabel}>
              {uploadingPhoto ? 'Uploading...' : 'Add photo'}
            </Text>
          </TouchableOpacity>

          {photoUris.length === 0 && !uploadingPhoto && (
            <View style={[styles.addPhoto, styles.photoEmpty]}>
              <Text style={styles.addPhotoLabel}>No photos yet</Text>
            </View>
          )}
        </View>

        {/* Status actions */}
        {task.status !== 'done' && (
          <View style={styles.actionRow}>
            {task.status === 'pending' && (
              <Btn
                label="Mark In Progress"
                variant="default"
                onPress={() => changeStatus('in_progress')}
                loading={updatingStatus}
                style={{ flex: 1 }}
              />
            )}
            <Btn
              label="Mark Done"
              variant="primary"
              onPress={() => changeStatus('done')}
              loading={updatingStatus}
              style={{ flex: task.status === 'pending' ? 1 : 2 }}
            />
          </View>
        )}

        {task.status === 'done' && (
          <View style={styles.doneBar}>
            <Text style={styles.doneText}>✓  Task Complete</Text>
          </View>
        )}

        {/* Comments */}
        {task.comments.length > 0 && (
          <>
            <SectionLabel text={`Comments (${task.comments.length})`} />
            {task.comments.map((c, i) => (
              <View key={i} style={styles.comment}>
                <Text style={styles.commentWho}>{c.who} · {c.timestamp}</Text>
                <Text style={styles.commentText}>{c.text}</Text>
              </View>
            ))}
          </>
        )}

        <SectionLabel text="Add comment" />
        <TextInput
          style={styles.input}
          placeholder="Ask a question or leave a note..."
          placeholderTextColor={colors.text3}
          multiline
          value={comment}
          onChangeText={setComment}
          textAlignVertical="top"
        />
        <Btn
          label={postingComment ? 'Posting...' : 'Post Comment'}
          variant="default"
          loading={postingComment}
          disabled={!comment.trim() || postingComment}
          onPress={handlePostComment}
          style={styles.postBtn}
        />
      </ScrollView>
    </View>
  );
}

// Inline style objects for the edit button (avoids adding to StyleSheet for one-off header items)
const editBtnStyle = {
  paddingHorizontal: 12, paddingVertical: 6,
  borderRadius: 6, borderWidth: 1, borderColor: colors.border2,
} as const;

const editBtnTextStyle = {
  fontSize: fontSizes.sm, color: colors.text2,
} as const;

const styles = StyleSheet.create({
  root:     { flex: 1, backgroundColor: colors.bg1 },
  scroll:   { flex: 1 },
  inner:    { padding: spacing.lg, paddingBottom: 48 },
  pillRow:  { flexDirection: 'row', flexWrap: 'wrap', gap: 6, alignItems: 'center' },
  assignee: { fontSize: fontSizes.sm, color: colors.text3 },
  desc:     { fontSize: fontSizes.base, color: colors.text2, lineHeight: 20, marginBottom: spacing.sm },
  mono:     { backgroundColor: colors.bg0, borderWidth: 1, borderColor: colors.border, borderRadius: radii.sm, padding: 9, marginBottom: spacing.sm },
  monoText: { fontFamily: 'Courier New', fontSize: fontSizes.sm, color: colors.amberT, lineHeight: 20 },
  snippet:  { borderLeftWidth: 2.5, borderLeftColor: colors.amber, paddingHorizontal: 11, paddingVertical: 9, marginBottom: spacing.sm, backgroundColor: colors.bg2 },
  snippetText: { fontSize: fontSizes.xs, color: colors.text2, fontStyle: 'italic', lineHeight: 18 },
  photoGrid:   { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: spacing.lg },
  photoThumb:  { width: '47%', aspectRatio: 4/3, borderRadius: radii.md },
  addPhoto:    { width: '47%', aspectRatio: 4/3, backgroundColor: colors.bg2, borderWidth: 1, borderStyle: 'dashed', borderColor: colors.border2, borderRadius: radii.md, alignItems: 'center', justifyContent: 'center', gap: 4 },
  photoEmpty:  { opacity: 0.4 },
  addPhotoIcon:  { fontSize: 22, color: colors.text3 },
  addPhotoLabel: { fontSize: fontSizes.xs, color: colors.text3 },
  actionRow: { flexDirection: 'row', gap: 8, marginBottom: spacing.lg },
  doneBar:   { backgroundColor: colors.greenBg, borderWidth: 1, borderColor: colors.greenBdr, borderRadius: radii.md, paddingVertical: 12, alignItems: 'center', marginBottom: spacing.lg },
  doneText:  { fontSize: fontSizes.base, fontWeight: fontWeights.medium, color: colors.greenT },
  comment:   { paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: colors.border },
  commentWho:  { fontSize: fontSizes.xs, color: colors.text3, fontWeight: fontWeights.medium, marginBottom: 3 },
  commentText: { fontSize: fontSizes.sm, color: colors.text2, lineHeight: 18 },
  input:     { backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border2, borderRadius: radii.md, padding: 10, fontSize: fontSizes.sm, color: colors.text1, minHeight: 72, marginBottom: 8 },
  postBtn:   { alignSelf: 'flex-start', paddingHorizontal: 14, paddingVertical: 7 },
});
