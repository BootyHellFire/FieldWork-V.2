/**
 * OpenAI service — Milestone 4
 *
 * extractTasks() now routes through the Supabase Edge Function
 * "extract-tasks" so the OpenAI API key never lives in the app binary.
 *
 * Falls back to direct API call only when EXPO_PUBLIC_OPENAI_API_KEY
 * is explicitly set (local dev / simulator testing without Supabase).
 *
 * transcribeAudio() still calls whisper-1 directly because audio blobs
 * are easier to forward from the device. In production you can add a
 * second Edge Function "transcribe-audio" and mirror this pattern.
 */

import { ExtractedTask } from '@/types';
import { supabase }      from '@/lib/supabase';

const OPENAI_BASE = 'https://api.openai.com/v1';

// ── 1. Speech → Text (whisper-1, direct) ──────────────────────

/**
 * Transcribes a local audio URI using whisper-1.
 * Still calls OpenAI directly — audio FormData is hard to proxy cleanly.
 * Key is read from env; move to an Edge Function in V2 if needed.
 */
export async function transcribeAudio(audioUri: string): Promise<string> {
  const key = process.env.EXPO_PUBLIC_OPENAI_API_KEY ?? '';
  if (!key) {
    console.warn('[OpenAI] EXPO_PUBLIC_OPENAI_API_KEY not set — skipping transcription.');
    return '';
  }

  const formData = new FormData();
  formData.append('file', {
    uri:  audioUri,
    name: 'recording.m4a',
    type: 'audio/m4a',
  } as any);
  formData.append('model',    'whisper-1');
  formData.append('language', 'en');

  const res = await fetch(`${OPENAI_BASE}/audio/transcriptions`, {
    method:  'POST',
    headers: { Authorization: `Bearer ${key}` },
    body:    formData,
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Whisper transcription failed: ${res.status} — ${err}`);
  }

  const data = await res.json();
  return (data.text as string).trim();
}

// ── 2. Text → Structured Tasks ─────────────────────────────────

/**
 * Extracts tasks from a transcript.
 *
 * Routes through the Supabase Edge Function "extract-tasks" when Supabase
 * is configured (production). Falls back to direct gpt-4o call for local
 * dev when only EXPO_PUBLIC_OPENAI_API_KEY is set.
 */
export async function extractTasks(params: {
  transcript:       string;
  roomName:         string;
  assignee:         string | null;
  stage:            string;
  snapshotBase64?:  string;
}): Promise<ExtractedTask[]> {

  const useEdgeFunction = !!process.env.EXPO_PUBLIC_SUPABASE_URL;

  let rawTasks: object[] = [];

  if (useEdgeFunction) {
    // ── Via Edge Function (production) ──────────────
    const { data, error } = await supabase.functions.invoke('extract-tasks', {
      body: params,
    });

    if (error) throw new Error(`Edge Function error: ${error.message}`);
    rawTasks = (data as any)?.tasks ?? [];

  } else {
    // ── Direct API call (local dev fallback) ─────────
    const key = process.env.EXPO_PUBLIC_OPENAI_API_KEY ?? '';
    if (!key) throw new Error('No OpenAI key and no Supabase URL — cannot extract tasks.');

    const userContent: object[] = [
      {
        type: 'text',
        text: buildPrompt(params),
      },
    ];

    if (params.snapshotBase64) {
      userContent.push({
        type: 'image_url',
        image_url: {
          url:    `data:image/jpeg;base64,${params.snapshotBase64}`,
          detail: 'low',
        },
      });
    }

    const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
      method:  'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:           'gpt-4o',
        max_tokens:      2000,
        temperature:     0.1,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user',   content: userContent   },
        ],
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`gpt-4o failed: ${res.status} — ${err}`);
    }

    const data = await res.json();
    const raw  = data.choices?.[0]?.message?.content ?? '{}';
    rawTasks   = JSON.parse(raw).tasks ?? [];
  }

  return mapToExtractedTasks(rawTasks);
}

// ── Helpers ────────────────────────────────────────────────────

const SYSTEM_PROMPT = `
You are an AI assistant helping an electrical foreman convert spoken walkthrough notes
into structured work tasks for electricians.

Extract work tasks from the transcript. For each task return:
- title: short, action-oriented (max 8 words)
- description: 1–2 sentences with full context
- room_name: from transcript if mentioned, else use provided room context
- assignee_name: if a worker's name is spoken near this task
- device_type: outlet / switch / light / can / panel / other
- action: mount / move / install / relocate / verify / other
- wall_reference: "right wall", "left wall", "centered", etc. if spoken
- measurements: object with height_from_ffl_inches, offset_from_right_wall_inches,
  offset_from_left_wall_inches, centered_on, above_feature, notes
- stage: rough / trim / finish / punch (from transcript or provided default)
- priority: high / normal (flag "high priority" or "urgent" keywords)
- confidence_score: 0–100
- should_create_task: true/false
- ambiguity_flags: array of strings describing anything unclear

Return ONLY a JSON object: { "tasks": [ ...task objects... ] }
`.trim();

function buildPrompt(p: {
  transcript: string;
  roomName:   string;
  assignee:   string | null;
  stage:      string;
}): string {
  return [
    `Current room: ${p.roomName}`,
    `Default assignee: ${p.assignee ?? 'unassigned'}`,
    `Default stage: ${p.stage}`,
    '',
    'Transcript:',
    '"""',
    p.transcript,
    '"""',
  ].join('\n');
}

function mapToExtractedTasks(raw: any[]): ExtractedTask[] {
  return raw
    .filter(t => t.should_create_task !== false && (t.confidence_score ?? 80) >= 60)
    .map((t, i) => ({
      id:          `extracted-${Date.now()}-${i}`,
      room:        t.room_name        ?? 'Unknown',
      assignee:    t.assignee_name    ?? 'Unassigned',
      priority:    t.priority === 'high' ? 'high' : 'normal',
      stage:       (['rough','trim','finish','punch'].includes(t.stage) ? t.stage : 'rough') as any,
      title:       t.title            ?? 'Untitled task',
      description: t.description      ?? '',
      measurements: {
        heightFromFFL:       t.measurements?.height_from_ffl_inches        ?? undefined,
        offsetFromRightWall: t.measurements?.offset_from_right_wall_inches ?? undefined,
        label:               buildMeasurementLabel(t.measurements),
      },
      confidence:        t.confidence_score   ?? 80,
      transcriptSnippet: t.transcript_snippet ?? '',
      approved:  false,
      discarded: false,
    }));
}

function buildMeasurementLabel(m: any): string {
  if (!m) return 'No measurements spoken';
  const parts: string[] = [];
  if (m.height_from_ffl_inches)        parts.push(`${m.height_from_ffl_inches}" from FFL`);
  if (m.offset_from_right_wall_inches) parts.push(`${m.offset_from_right_wall_inches}" from right wall`);
  if (m.offset_from_left_wall_inches)  parts.push(`${m.offset_from_left_wall_inches}" from left wall`);
  if (m.centered_on)                   parts.push(`centered on ${m.centered_on}`);
  if (m.above_feature)                 parts.push(`above ${m.above_feature}`);
  if (m.notes)                         parts.push(m.notes);
  return parts.length > 0 ? parts.join('  ·  ') : 'No measurements spoken';
}
