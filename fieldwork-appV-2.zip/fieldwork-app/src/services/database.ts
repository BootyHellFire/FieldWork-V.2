/**
 * Database service — all Supabase reads and writes in one place.
 * Screens import from here, not directly from the supabase client.
 */

import { supabase } from '@/lib/supabase';
import { Job, Task, Room, TaskStatus } from '@/types';

// ─── Jobs ────────────────────────────────────────────

export async function fetchJobs(): Promise<Job[]> {
  const { data, error } = await supabase
    .from('jobs')
    .select(`
      id, name, address, status, notes,
      builders ( name ),
      rooms ( count ),
      tasks ( status )
    `)
    .order('created_at', { ascending: false });

  if (error) throw error;

  return (data ?? []).map((row: any) => ({
    id:          row.id,
    name:        row.name,
    address:     row.address ?? '',
    builder:     row.builders?.name ?? '',
    status:      row.status,
    roomCount:   row.rooms?.[0]?.count ?? 0,
    tasksDone:   (row.tasks ?? []).filter((t: any) => t.status === 'done').length,
    tasksTotal:  (row.tasks ?? []).length,
  }));
}

export async function fetchJob(id: number): Promise<Job | null> {
  const { data, error } = await supabase
    .from('jobs')
    .select(`id, name, address, status, builders ( name )`)
    .eq('id', id)
    .single();

  if (error || !data) return null;
  return {
    id:         data.id,
    name:       data.name,
    address:    data.address ?? '',
    builder:    (data as any).builders?.name ?? '',
    status:     data.status,
    roomCount:  0,
    tasksDone:  0,
    tasksTotal: 0,
  };
}

// ─── Rooms ───────────────────────────────────────────

export async function fetchRooms(jobId: number): Promise<Room[]> {
  const { data, error } = await supabase
    .from('rooms')
    .select('id, name, floor_name, tasks ( count )')
    .eq('job_id', jobId)
    .order('sort_order', { ascending: true });

  if (error) throw error;

  return (data ?? []).map((row: any) => ({
    id:        row.id,
    jobId,
    name:      row.name,
    floor:     row.floor_name ?? '',
    taskCount: row.tasks?.[0]?.count ?? 0,
  }));
}

export async function createRoom(
  jobId: number,
  name: string,
  floorName: string
): Promise<Room> {
  const { data, error } = await supabase
    .from('rooms')
    .insert({ job_id: jobId, name, floor_name: floorName })
    .select()
    .single();

  if (error || !data) throw error ?? new Error('Failed to create room');

  return { id: data.id, jobId, name: data.name, floor: data.floor_name ?? '', taskCount: 0 };
}

// ─── Tasks ───────────────────────────────────────────

export async function fetchTasks(jobId: number): Promise<Task[]> {
  const { data, error } = await supabase
    .from('tasks')
    .select(`
      id, job_id, title, description, status, priority, stage,
      wall_reference, measurements_json, transcript_snippet,
      assigned_to_user_id, source_photo_url,
      rooms ( name ),
      users:assigned_to_user_id ( full_name ),
      task_comments ( id, comment, created_at, users ( full_name ) )
    `)
    .eq('job_id', jobId)
    .eq('needs_review', false)
    .order('created_at', { ascending: false });

  if (error) throw error;

  return (data ?? []).map(mapTaskRow);
}

export async function fetchMyTasks(userId: string): Promise<Task[]> {
  const { data, error } = await supabase
    .from('tasks')
    .select(`
      id, job_id, title, description, status, priority, stage,
      measurements_json, transcript_snippet,
      rooms ( name ),
      task_comments ( id, comment, created_at, users ( full_name ) )
    `)
    .eq('assigned_to_user_id', userId)
    .eq('needs_review', false)
    .order('created_at', { ascending: false });

  if (error) throw error;

  return (data ?? []).map(mapTaskRow);
}

export async function updateTaskStatus(
  taskId: number,
  status: TaskStatus
): Promise<void> {
  const patch: Record<string, any> = { status };
  if (status === 'done') patch.completed_at = new Date().toISOString();

  const { error } = await supabase
    .from('tasks')
    .update(patch)
    .eq('id', taskId);

  if (error) throw error;
}

export async function approveTask(taskId: number): Promise<void> {
  const { error } = await supabase
    .from('tasks')
    .update({ needs_review: false, approved_at: new Date().toISOString() })
    .eq('id', taskId);

  if (error) throw error;
}

export async function addTaskComment(
  taskId: number,
  userId: string,
  comment: string
): Promise<void> {
  const { error } = await supabase
    .from('task_comments')
    .insert({ task_id: taskId, user_id: userId, comment });

  if (error) throw error;
}

export async function addTaskPhoto(
  taskId: number,
  userId: string,
  photoUrl: string,
  photoType: 'reference' | 'completion'
): Promise<void> {
  const { error } = await supabase
    .from('task_photos')
    .insert({ task_id: taskId, uploaded_by: userId, photo_url: photoUrl, photo_type: photoType });

  if (error) throw error;
}

// ─── Walkthrough sessions ─────────────────────────────

export async function createWalkthroughSession(
  jobId: number,
  userId: string
): Promise<string> {
  const { data, error } = await supabase
    .from('walkthrough_sessions')
    .insert({ job_id: jobId, started_by: userId, started_at: new Date().toISOString() })
    .select('id')
    .single();

  if (error || !data) throw error ?? new Error('Failed to create session');
  return data.id as string;
}

export async function endWalkthroughSession(sessionId: string): Promise<void> {
  const { error } = await supabase
    .from('walkthrough_sessions')
    .update({ ended_at: new Date().toISOString() })
    .eq('id', sessionId);

  if (error) throw error;
}

/** Insert a raw walkthrough segment (transcript chunk + optional snapshot url) */
export async function insertWalkthroughSegment(params: {
  sessionId: string;
  roomId?: number;
  assigneeUserId?: string;
  priority: string;
  stage: string;
  transcriptText: string;
  snapshotImageUrl?: string;
  rawAiJson?: object;
}): Promise<number> {
  const { data, error } = await supabase
    .from('walkthrough_segments')
    .insert({
      session_id:          params.sessionId,
      room_id:             params.roomId,
      assignee_user_id:    params.assigneeUserId,
      priority:            params.priority,
      stage:               params.stage,
      transcript_text:     params.transcriptText,
      snapshot_image_url:  params.snapshotImageUrl,
      raw_ai_json:         params.rawAiJson,
    })
    .select('id')
    .single();

  if (error || !data) throw error ?? new Error('Failed to insert segment');
  return data.id as number;
}

/** Insert an approved task extracted from a walkthrough segment */
export async function insertTask(params: {
  jobId: number;
  roomId?: number;
  sourceSegmentId?: number;
  assignedToUserId?: string;
  createdByUserId: string;
  title: string;
  description: string;
  stage: string;
  priority: string;
  measurementsJson?: object;
  transcriptSnippet?: string;
  sourcePhotoUrl?: string;
  needsReview: boolean;
}): Promise<number> {
  const { data, error } = await supabase
    .from('tasks')
    .insert({
      job_id:              params.jobId,
      room_id:             params.roomId,
      source_segment_id:   params.sourceSegmentId,
      assigned_to_user_id: params.assignedToUserId,
      created_by_user_id:  params.createdByUserId,
      status:              'pending',
      title:               params.title,
      description:         params.description,
      stage:               params.stage,
      priority:            params.priority,
      measurements_json:   params.measurementsJson,
      transcript_snippet:  params.transcriptSnippet,
      source_photo_url:    params.sourcePhotoUrl,
      needs_review:        params.needsReview,
    })
    .select('id')
    .single();

  if (error || !data) throw error ?? new Error('Failed to insert task');
  return data.id as number;
}

// ─── Internal mapper ─────────────────────────────────

function mapTaskRow(row: any): Task {
  const m = row.measurements_json ?? {};
  return {
    id:          row.id,
    jobId:       row.job_id,
    room:        row.rooms?.name ?? 'Unknown',
    title:       row.title,
    description: row.description ?? '',
    assignee:    (row as any).users?.full_name ?? 'Unassigned',
    stage:       row.stage ?? 'rough',
    priority:    row.priority ?? 'normal',
    status:      row.status ?? 'pending',
    measurements: {
      heightFromFFL:       m.height_from_ffl_inches,
      offsetFromRightWall: m.offset_from_right_wall_inches,
      label:               buildLabel(m),
    },
    transcriptSnippet: row.transcript_snippet ?? '',
    comments: (row.task_comments ?? []).map((c: any) => ({
      who:       c.users?.full_name ?? 'Unknown',
      text:      c.comment,
      timestamp: formatTs(c.created_at),
    })),
  };
}

function buildLabel(m: any): string {
  const parts: string[] = [];
  if (m.height_from_ffl_inches)        parts.push(`${m.height_from_ffl_inches}" from FFL`);
  if (m.offset_from_right_wall_inches) parts.push(`${m.offset_from_right_wall_inches}" from right wall`);
  if (m.offset_from_left_wall_inches)  parts.push(`${m.offset_from_left_wall_inches}" from left wall`);
  if (m.centered_on)                   parts.push(`centered on ${m.centered_on}`);
  return parts.length > 0 ? parts.join('  ·  ') : 'No measurements';
}

function formatTs(iso: string): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60)  return `${mins}m ago`;
  if (mins < 1440) return `${Math.floor(mins / 60)}h ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
