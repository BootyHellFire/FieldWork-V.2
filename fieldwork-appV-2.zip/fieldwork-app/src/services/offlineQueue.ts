/**
 * Offline queue — survives network drops during walkthroughs.
 *
 * When the network drops:
 *   - Transcript text and snapshot URIs are saved locally.
 *   - Session is marked "pending sync".
 *
 * When the network reconnects:
 *   - flushQueue() uploads everything in order.
 *   - Successful items are removed from the queue.
 *
 * Storage key: @fieldwork/offline_queue
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';

const QUEUE_KEY = '@fieldwork/offline_queue';

export type QueueItemType =
  | 'audio_upload'
  | 'snapshot_upload'
  | 'segment_insert'
  | 'task_status_update';

export interface QueueItem {
  id: string;
  type: QueueItemType;
  payload: Record<string, any>;
  createdAt: string;
  attempts: number;
}

// ── Read / write ──────────────────────────────────────

async function readQueue(): Promise<QueueItem[]> {
  try {
    const raw = await AsyncStorage.getItem(QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeQueue(items: QueueItem[]): Promise<void> {
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(items));
}

/** Add an item to the offline queue */
export async function enqueue(
  type: QueueItemType,
  payload: Record<string, any>
): Promise<void> {
  const queue = await readQueue();
  queue.push({
    id:        `${type}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    type,
    payload,
    createdAt: new Date().toISOString(),
    attempts:  0,
  });
  await writeQueue(queue);
}

/** Remove a successfully-processed item */
async function dequeue(id: string): Promise<void> {
  const queue = await readQueue();
  await writeQueue(queue.filter(i => i.id !== id));
}

/** How many items are waiting to sync */
export async function pendingCount(): Promise<number> {
  const queue = await readQueue();
  return queue.length;
}

// ── Flush ─────────────────────────────────────────────

type FlushHandler = (item: QueueItem) => Promise<void>;

let _handlers: Partial<Record<QueueItemType, FlushHandler>> = {};

/** Register a handler for each queue item type */
export function registerQueueHandlers(
  handlers: Partial<Record<QueueItemType, FlushHandler>>
): void {
  _handlers = { ..._handlers, ...handlers };
}

/**
 * Attempt to process all queued items.
 * Call this when the network reconnects.
 * Items that fail are left in the queue (with attempt count incremented).
 */
export async function flushQueue(): Promise<{ flushed: number; failed: number }> {
  const queue = await readQueue();
  if (queue.length === 0) return { flushed: 0, failed: 0 };

  let flushed = 0;
  let failed  = 0;

  for (const item of queue) {
    const handler = _handlers[item.type];
    if (!handler) {
      console.warn(`[Queue] No handler registered for type: ${item.type}`);
      continue;
    }
    try {
      await handler(item);
      await dequeue(item.id);
      flushed++;
    } catch (err) {
      console.error(`[Queue] Failed to process ${item.id}:`, err);
      // Increment attempt count
      const all = await readQueue();
      const idx = all.findIndex(i => i.id === item.id);
      if (idx !== -1) {
        all[idx].attempts += 1;
        // Give up after 5 attempts to prevent blocking the queue forever
        if (all[idx].attempts >= 5) {
          all.splice(idx, 1);
          console.warn(`[Queue] Dropped ${item.id} after 5 failed attempts`);
        }
        await writeQueue(all);
      }
      failed++;
    }
  }

  return { flushed, failed };
}

// ── NetInfo listener ──────────────────────────────────

let _unsubscribe: (() => void) | null = null;

/**
 * Start listening for network reconnections.
 * When the network comes back, automatically flush the queue.
 * Call once in your root layout or app entry.
 */
export function startNetworkListener(
  onFlush?: (result: { flushed: number; failed: number }) => void
): void {
  if (_unsubscribe) return; // already listening

  let wasOffline = false;

  _unsubscribe = NetInfo.addEventListener(async state => {
    const isOnline = state.isConnected && state.isInternetReachable;
    if (wasOffline && isOnline) {
      console.log('[Queue] Network reconnected — flushing offline queue...');
      const result = await flushQueue();
      if (result.flushed > 0 || result.failed > 0) {
        console.log(`[Queue] Flushed ${result.flushed}, failed ${result.failed}`);
        onFlush?.(result);
      }
    }
    wasOffline = !isOnline;
  });
}

export function stopNetworkListener(): void {
  _unsubscribe?.();
  _unsubscribe = null;
}
