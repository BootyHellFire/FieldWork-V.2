/**
 * Database service — additional helpers added in M4.
 * Append-only: existing functions in database.ts remain unchanged.
 *
 * Import from this file for M4+ additions, or merge into database.ts.
 */

import { supabase } from '@/lib/supabase';

// ── fetchJobBoss ──────────────────────────────────────────────
/**
 * Returns the user ID of the boss (or first admin) on a given job.
 * Used when a worker marks a task done and needs to notify the boss.
 */
export async function fetchJobBoss(jobId: number): Promise<string | null> {
  const { data, error } = await supabase
    .from('job_members')
    .select('user_id')
    .eq('job_id', jobId)
    .in('role', ['boss', 'admin'])
    .limit(1)
    .single();

  if (error || !data) return null;
  return data.user_id as string;
}

// ── fetchJobMembers ───────────────────────────────────────────
/**
 * Returns all member IDs for a job, optionally filtered by role.
 */
export async function fetchJobMembers(
  jobId: number,
  role?: 'boss' | 'worker' | 'admin'
): Promise<string[]> {
  let query = supabase
    .from('job_members')
    .select('user_id')
    .eq('job_id', jobId);

  if (role) query = query.eq('role', role);

  const { data, error } = await query;
  if (error || !data) return [];
  return data.map(r => r.user_id as string);
}

// ── fetchTaskFull ─────────────────────────────────────────────
/**
 * Fetches a single task by ID with all related data:
 * room, assignee name, comments with author names, and photos.
 * Used by the task detail screen to load fresh data.
 */
export async function fetchTaskFull(taskId: number) {
  const { data, error } = await supabase
    .from('tasks')
    .select(`
      id, job_id, title, description, status, priority, stage,
      wall_reference, measurements_json, transcript_snippet,
      source_photo_url, needs_review,
      rooms ( name ),
      users:assigned_to_user_id ( full_name ),
      task_comments (
        id, comment, created_at,
        users ( full_name )
      ),
      task_photos ( id, photo_url, photo_type, created_at )
    `)
    .eq('id', taskId)
    .single();

  if (error || !data) return null;
  return data;
}

// ── fetchPendingReviewTasks ───────────────────────────────────
/**
 * Returns tasks that still need boss review (needs_review = true).
 * Used on the boss jobs screen to show a "Needs Review" indicator.
 */
export async function fetchPendingReviewCount(jobId: number): Promise<number> {
  const { count, error } = await supabase
    .from('tasks')
    .select('id', { count: 'exact', head: true })
    .eq('job_id', jobId)
    .eq('needs_review', true);

  if (error) return 0;
  return count ?? 0;
}

// ── fetchJobStats ─────────────────────────────────────────────
/**
 * Returns aggregate task stats for a job in a single query.
 * Used by the job detail stats row.
 */
export async function fetchJobStats(jobId: number): Promise<{
  total: number; done: number; inProgress: number; pending: number; needsReview: number;
}> {
  const { data, error } = await supabase
    .from('tasks')
    .select('status, needs_review')
    .eq('job_id', jobId);

  if (error || !data) return { total: 0, done: 0, inProgress: 0, pending: 0, needsReview: 0 };

  return {
    total:       data.length,
    done:        data.filter(t => t.status === 'done').length,
    inProgress:  data.filter(t => t.status === 'in_progress').length,
    pending:     data.filter(t => t.status === 'pending' && !t.needs_review).length,
    needsReview: data.filter(t => t.needs_review).length,
  };
}

// ── deleteTask ────────────────────────────────────────────────
/**
 * Hard-deletes a task. Boss-only operation.
 * RLS policy prevents workers from calling this.
 */
export async function deleteTask(taskId: number): Promise<void> {
  const { error } = await supabase
    .from('tasks')
    .delete()
    .eq('id', taskId);

  if (error) throw error;
}

// ── updateTask ────────────────────────────────────────────────
/**
 * Partial update for a task — title, description, assignee, etc.
 * Used on the review screen and a future task-edit screen.
 */
export async function updateTask(
  taskId: number,
  patch: Partial<{
    title:               string;
    description:         string;
    stage:               string;
    priority:            string;
    assigned_to_user_id: string;
    measurements_json:   object;
    wall_reference:      string;
    needs_review:        boolean;
    approved_at:         string;
  }>
): Promise<void> {
  const { error } = await supabase
    .from('tasks')
    .update(patch)
    .eq('id', taskId);

  if (error) throw error;
}
