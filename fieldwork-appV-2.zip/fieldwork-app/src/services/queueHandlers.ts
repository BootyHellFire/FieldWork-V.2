/**
 * registerOfflineHandlers
 *
 * Registers a handler for each QueueItemType so the offline queue
 * knows what to do when the network reconnects and items are flushed.
 *
 * Call once in the root layout, after auth is initialised.
 */

import { registerQueueHandlers, QueueItem } from '@/services/offlineQueue';
import { uploadAudioClip, uploadSnapshot, uploadCompletionPhoto } from '@/services/storage';
import { updateTaskStatus } from '@/services/database';

export function registerOfflineHandlers(): void {
  registerQueueHandlers({

    // ── Audio clip uploaded after recording ───────────────
    audio_upload: async (item: QueueItem) => {
      const { audioUri, jobId, sessionId } = item.payload;
      await uploadAudioClip(audioUri, jobId, sessionId);
    },

    // ── Snapshot taken during walkthrough ─────────────────
    snapshot_upload: async (item: QueueItem) => {
      const { localUri, jobId, sessionId, index } = item.payload;
      await uploadSnapshot(localUri, jobId, sessionId, index);
    },

    // ── Task status change made while offline ─────────────
    task_status_update: async (item: QueueItem) => {
      const { taskId, status } = item.payload;
      await updateTaskStatus(taskId, status);
    },
  });
}
