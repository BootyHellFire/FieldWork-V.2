/**
 * Storage service — wraps Supabase Storage for all file uploads.
 *
 * Buckets (must be created in Supabase dashboard first):
 *   - audio-clips          (private) — walkthrough .m4a recordings
 *   - snapshots            (private) — walkthrough snapshot JPEGs
 *   - task-photos          (private) — worker completion photos
 *   - plans                (private) — floor plan images/PDFs
 */

import * as FileSystem from 'expo-file-system';
import { supabase } from '@/lib/supabase';

type Bucket = 'audio-clips' | 'snapshots' | 'task-photos' | 'plans';

/**
 * Uploads a local file URI to a Supabase Storage bucket.
 * Returns the public or signed URL of the uploaded file.
 *
 * @param localUri   Local file:// URI from expo-av / expo-camera / expo-image-picker
 * @param bucket     Target Supabase Storage bucket name
 * @param path       Storage path within the bucket, e.g. "job-1/session-42/recording.m4a"
 * @param mimeType   MIME type of the file
 */
export async function uploadFile(
  localUri: string,
  bucket: Bucket,
  path: string,
  mimeType: string
): Promise<string> {
  // Read file as base64 — works reliably on both iOS and Android
  const base64 = await FileSystem.readAsStringAsync(localUri, {
    encoding: FileSystem.EncodingType.Base64,
  });

  // Decode base64 to Uint8Array for the Supabase JS SDK
  const byteChars = atob(base64);
  const byteArray = new Uint8Array(byteChars.length);
  for (let i = 0; i < byteChars.length; i++) {
    byteArray[i] = byteChars.charCodeAt(i);
  }

  const { error } = await supabase.storage
    .from(bucket)
    .upload(path, byteArray, {
      contentType: mimeType,
      upsert: false,
    });

  if (error) throw new Error(`Upload to ${bucket}/${path} failed: ${error.message}`);

  // Return a signed URL valid for 1 year (for private buckets)
  const { data: signed, error: signErr } = await supabase.storage
    .from(bucket)
    .createSignedUrl(path, 60 * 60 * 24 * 365);

  if (signErr || !signed) {
    throw new Error(`Could not create signed URL for ${bucket}/${path}`);
  }

  return signed.signedUrl;
}

/** Upload a walkthrough audio clip (.m4a) */
export async function uploadAudioClip(
  localUri: string,
  jobId: number,
  sessionId: string
): Promise<string> {
  const filename = `job-${jobId}/session-${sessionId}/recording-${Date.now()}.m4a`;
  return uploadFile(localUri, 'audio-clips', filename, 'audio/m4a');
}

/** Upload a walkthrough snapshot JPEG */
export async function uploadSnapshot(
  localUri: string,
  jobId: number,
  sessionId: string,
  index: number
): Promise<string> {
  const filename = `job-${jobId}/session-${sessionId}/snap-${index}-${Date.now()}.jpg`;
  return uploadFile(localUri, 'snapshots', filename, 'image/jpeg');
}

/** Upload a worker completion photo */
export async function uploadCompletionPhoto(
  localUri: string,
  taskId: number
): Promise<string> {
  const filename = `task-${taskId}/completion-${Date.now()}.jpg`;
  return uploadFile(localUri, 'task-photos', filename, 'image/jpeg');
}

/** Upload a floor plan image */
export async function uploadPlan(
  localUri: string,
  jobId: number,
  mimeType: 'image/jpeg' | 'image/png' | 'application/pdf'
): Promise<string> {
  const ext = mimeType === 'application/pdf' ? 'pdf' : 'jpg';
  const filename = `job-${jobId}/plan-${Date.now()}.${ext}`;
  return uploadFile(localUri, 'plans', filename, mimeType);
}
