/**
 * Notification service — dispatches push notifications via
 * the Supabase Edge Function "send-notification".
 *
 * Called from the app whenever an action should notify other users:
 *   - Boss publishes tasks → notify assigned workers
 *   - Worker marks task done → notify boss
 *   - Worker posts a comment → notify boss + other commenters
 */

import { supabase } from '@/lib/supabase';

export interface NotificationPayload {
  userIds:  string[];
  title:    string;
  body:     string;
  data?:    Record<string, unknown>;
  /** Whether to also insert a row in the notifications table (default true) */
  persist?: boolean;
}

/**
 * Send a push notification to one or more users.
 * Silently swallows errors — notifications are best-effort.
 */
export async function sendNotification(payload: NotificationPayload): Promise<void> {
  if (!process.env.EXPO_PUBLIC_SUPABASE_URL) {
    // Demo mode — skip silently
    console.log('[Notify] Demo mode — skipping push:', payload.title);
    return;
  }

  try {
    const { error } = await supabase.functions.invoke('send-notification', {
      body: payload,
    });
    if (error) console.warn('[Notify] Edge Function error:', error.message);
  } catch (err) {
    console.warn('[Notify] Failed to send notification:', err);
  }
}

// ── Convenience wrappers ──────────────────────────────────────

/** Notify a worker that new tasks have been assigned to them. */
export async function notifyTasksAssigned(params: {
  workerId: string;
  workerName: string;
  jobName: string;
  taskCount: number;
}): Promise<void> {
  await sendNotification({
    userIds: [params.workerId],
    title:   `${params.taskCount} new task${params.taskCount > 1 ? 's' : ''} assigned`,
    body:    `${params.jobName} — open Fieldwork to view your work items.`,
    data:    { type: 'tasks_assigned', workerId: params.workerId },
  });
}

/** Notify the boss that a worker completed a task. */
export async function notifyTaskDone(params: {
  bossId:     string;
  workerName: string;
  taskTitle:  string;
  jobName:    string;
}): Promise<void> {
  await sendNotification({
    userIds: [params.bossId],
    title:   `${params.workerName} completed a task`,
    body:    `"${params.taskTitle}" — ${params.jobName}`,
    data:    { type: 'task_done' },
  });
}

/** Notify relevant users that a comment was posted. */
export async function notifyNewComment(params: {
  recipientIds: string[];
  authorName:   string;
  taskTitle:    string;
  commentText:  string;
}): Promise<void> {
  if (params.recipientIds.length === 0) return;
  await sendNotification({
    userIds: params.recipientIds,
    title:   `${params.authorName} commented on a task`,
    body:    `"${params.taskTitle}": ${params.commentText.slice(0, 80)}`,
    data:    { type: 'new_comment' },
  });
}
