import { Job } from '../types';

export const DEMO_JOBS: Job[] = [
  {
    id: 1,
    name: 'Meridian Ridge Estate',
    address: '4821 Meadow View Ln, Eagle, ID',
    builder: 'Summit Custom Homes',
    status: 'active',
    roomCount: 14,
    tasksDone: 23,
    tasksTotal: 31,
  },
  {
    id: 2,
    name: 'Foothills Modern',
    address: '912 Hillcrest Dr, Boise, ID',
    builder: 'TerraForm Builders',
    status: 'review',
    roomCount: 9,
    tasksDone: 12,
    tasksTotal: 15,
  },
  {
    id: 3,
    name: 'Hidden Valley Ranch',
    address: '2200 Canyon Rim Rd, Nampa, ID',
    builder: 'Ridgeline Construction',
    status: 'upcoming',
    roomCount: 11,
    tasksDone: 0,
    tasksTotal: 0,
  },
];
