import { Room } from '../types';

export const DEMO_ROOMS: Room[] = [
  { id: 1, jobId: 1, name: 'Kitchen',              floor: 'Main',  taskCount: 4 },
  { id: 2, jobId: 1, name: 'Master Bath',          floor: 'Upper', taskCount: 3 },
  { id: 3, jobId: 1, name: 'Great Room',           floor: 'Main',  taskCount: 2 },
  { id: 4, jobId: 1, name: 'Downstairs Bathroom',  floor: 'Main',  taskCount: 2 },
  { id: 5, jobId: 1, name: 'Master Closet',        floor: 'Upper', taskCount: 1 },
  { id: 6, jobId: 1, name: 'Garage',               floor: 'Main',  taskCount: 0 },
];

export const WALKTHROUGH_ROOMS = DEMO_ROOMS.map(r => r.name);
