import { ExtractedTask } from '../types';

// Simulated AI-extracted tasks from a walkthrough session.
// These appear on the boss review screen before publishing.
export const DEMO_EXTRACTED: ExtractedTask[] = [
  {
    id: 'e1',
    room: 'Master Bath',
    assignee: 'Carson',
    priority: 'high',
    stage: 'trim',
    title: 'Vanity light — height correction',
    description:
      'Move vanity light to 52.5″ from finished floor, centered on mirror above vanity.',
    measurements: {
      heightFromFFL: 52.5,
      label: '52.5″ from FFL  ·  centered on mirror',
    },
    confidence: 94,
    transcriptSnippet:
      'Move this vanity light up to 52 and a half from finished floor. Assign to Carson. High priority.',
    approved: false,
    discarded: false,
  },
  {
    id: 'e2',
    room: 'Master Bath',
    assignee: 'Jake',
    priority: 'normal',
    stage: 'rough',
    title: 'Shower recessed can — centered',
    description:
      'Recessed can centered in shower stall at 84″ from FFL, 27″ from right wall.',
    measurements: {
      heightFromFFL: 84,
      offsetFromRightWall: 27,
      label: '84″ from FFL  ·  27″ from right wall',
    },
    confidence: 97,
    transcriptSnippet:
      'Recessed can needs to be centered in the stall at 84 inches. Jake handles that one.',
    approved: false,
    discarded: false,
  },
  {
    id: 'e3',
    room: 'Master Bath',
    assignee: 'Carson',
    priority: 'normal',
    stage: 'rough',
    title: 'Switch bank — shift left 2″',
    description: 'Move switch bank 2 inches left from current rough-in mark.',
    measurements: {
      label: 'Shift 2″ left from current rough-in mark',
    },
    confidence: 88,
    transcriptSnippet:
      'Switch bank here needs to come over 2 inches to the left from the mark.',
    approved: false,
    discarded: false,
  },
];

// Simulated transcript chunks for walkthrough demo
export const DEMO_TRANSCRIPT_CHUNKS = [
  "OK, we're in the master bath now.",
  ' I want to move this vanity light up — 52 and a half from finished floor, centered on the mirror. Assign that to Carson, high priority, trim stage.',
  ' Moving to the shower. The recessed can needs to be centered in the stall, 84 inches to the box.',
  " That's Jake's, rough stage. 27 inches from the right wall.",
  ' This switch bank needs to come over 2 inches to the left from the mark.',
  " That's all for the bath. Ready to finish.",
];
