import { Task } from '../types';

export const DEMO_TASKS: Task[] = [
  {
    id: 1,
    jobId: 1,
    room: 'Master Bath',
    title: 'Vanity light — height correction',
    description:
      'Move vanity light to 52.5″ from finished floor, centered on mirror above vanity.',
    assignee: 'Carson',
    stage: 'trim',
    priority: 'high',
    status: 'pending',
    measurements: {
      heightFromFFL: 52.5,
      label: '52.5″ from FFL  ·  centered on mirror',
    },
    transcriptSnippet:
      'Move this vanity light up to 52 and a half from finished floor. Assign to Carson. High priority.',
    comments: [
      {
        who: 'Carson',
        text: 'Need to confirm mirror centerline with GC before roughing in.',
        timestamp: '2h ago',
      },
    ],
  },
  {
    id: 2,
    jobId: 1,
    room: 'Kitchen',
    title: 'Under-cabinet outlet strip',
    description:
      'Install outlet strip under upper cabinet run on south wall. Rough-in at 54″ from FFL.',
    assignee: 'Jake',
    stage: 'rough',
    priority: 'normal',
    status: 'in_progress',
    measurements: {
      heightFromFFL: 54,
      label: '54″ from FFL  ·  south wall under cabinets',
    },
    transcriptSnippet:
      'Jake, put the outlet strip under the upper cabinets on the south wall.',
    comments: [],
  },
  {
    id: 3,
    jobId: 1,
    room: 'Great Room',
    title: 'Switch bank — shift left 2″',
    description: 'Move switch bank 2 inches to the left from current rough-in mark.',
    assignee: 'Carson',
    stage: 'rough',
    priority: 'normal',
    status: 'pending',
    measurements: {
      label: 'Shift 2″ left from current rough-in mark',
    },
    transcriptSnippet:
      'Move this switch bank over 2 inches, shift it left from the mark.',
    comments: [],
  },
  {
    id: 4,
    jobId: 1,
    room: 'Kitchen',
    title: 'Island pendants — rough-in ×3',
    description:
      'Three pendant rough-ins above island. 36″ on center, 84″ to rough-in box.',
    assignee: 'Jake',
    stage: 'rough',
    priority: 'high',
    status: 'pending',
    measurements: {
      heightFromFFL: 84,
      label: '84″ to box  ·  36″ on center  ·  3 locations',
    },
    transcriptSnippet:
      'Three pendants over the island. 36 inches on center, 84 to the box.',
    comments: [
      {
        who: 'Jake',
        text: 'Box size confirmed: 4″ octagon. Steel mud ring OK with PM.',
        timestamp: '5h ago',
      },
    ],
  },
  {
    id: 5,
    jobId: 1,
    room: 'Master Bath',
    title: 'Shower can — centered',
    description:
      'Recessed can centered in shower stall. 84″ from FFL, 27″ from right wall.',
    assignee: 'Jake',
    stage: 'rough',
    priority: 'normal',
    status: 'done',
    measurements: {
      heightFromFFL: 84,
      offsetFromRightWall: 27,
      label: '84″ from FFL  ·  27″ from right wall',
    },
    transcriptSnippet:
      'Mount at 84 inches to center from finished floor and 27 from the right wall.',
    comments: [],
  },
];
