/**
 * Core TypeScript types — Milestone 4 final.
 * Mirrors the Supabase data model exactly.
 */

export type UserRole = 'boss' | 'worker' | 'admin';

export interface DemoUser {
  id:       string;
  name:     string;
  initials: string;
  role:     UserRole;
}

// ─── Jobs ────────────────────────────────────────────

export type JobStatus = 'active' | 'review' | 'upcoming' | 'complete';

export interface Job {
  id:          number;
  name:        string;
  address:     string;
  builder:     string;
  status:      JobStatus;
  roomCount:   number;
  tasksDone:   number;
  tasksTotal:  number;
}

// ─── Rooms ───────────────────────────────────────────

export interface Room {
  id:        number;
  jobId:     number;
  name:      string;
  floor:     string;
  taskCount: number;
}

// ─── Tasks ───────────────────────────────────────────

export type TaskStatus   = 'pending' | 'in_progress' | 'done' | 'blocked';
export type TaskStage    = 'rough' | 'trim' | 'finish' | 'punch';
export type TaskPriority = 'normal' | 'high';

export interface Measurements {
  /** Height from finished floor in inches */
  heightFromFFL?:       number;
  /** Horizontal offset from right wall in inches */
  offsetFromRightWall?: number;
  /** Horizontal offset from left wall in inches */
  offsetFromLeftWall?:  number;
  /** Feature the device is centered on (e.g. "window", "mirror") */
  centeredOn?:          string;
  /** Feature the device is above (e.g. "vanity") */
  aboveFeature?:        string;
  /** Human-readable label shown in mono block */
  label:                string;
}

export interface TaskComment {
  who:       string;
  text:      string;
  timestamp: string;
}

export interface TaskPhoto {
  id:        number;
  photoUrl:  string;
  photoType: 'reference' | 'completion';
  createdAt: string;
}

export interface Task {
  id:                number;
  jobId:             number;
  room:              string;
  title:             string;
  description:       string;
  assignee:          string;
  stage:             TaskStage;
  priority:          TaskPriority;
  status:            TaskStatus;
  measurements:      Measurements;
  transcriptSnippet: string;
  sourcePhotoUrl?:   string;
  comments:          TaskComment[];
  photos?:           TaskPhoto[];
}

// ─── Extracted tasks (AI review screen) ──────────────

export interface ExtractedTask {
  id:                string;
  room:              string;
  assignee:          string;
  priority:          TaskPriority;
  stage:             TaskStage;
  title:             string;
  description:       string;
  measurements:      Measurements;
  /** AI confidence 0–100 */
  confidence:        number;
  transcriptSnippet: string;
  approved:          boolean;
  discarded:         boolean;
}

// ─── Walkthrough session (local capture state) ───────

export interface WalkthroughState {
  recording:      boolean;
  currentRoom:    string;
  assignee:       string | null;
  priority:       TaskPriority;
  stage:          TaskStage;
  snapshotCount:  number;
  transcript:     string;
}

// ─── Notifications ────────────────────────────────────

export type NotificationType =
  | 'task_assigned'
  | 'task_done'
  | 'new_comment'
  | 'general';

export interface AppNotification {
  id:        number;
  userId:    string;
  type:      NotificationType;
  title:     string;
  body?:     string;
  readAt?:   string;
  createdAt: string;
}

// ─── Offline queue ────────────────────────────────────

export type QueueItemType =
  | 'audio_upload'
  | 'snapshot_upload'
  | 'segment_insert'
  | 'task_status_update';

// ─── Navigation param types ───────────────────────────
// Expo Router typed routes — used with router.push() calls

export type AppRoutes = {
  '/(auth)/sign-in':                    undefined;
  '/(auth)/callback':                   undefined;
  '/(boss)/jobs':                       undefined;
  '/(boss)/jobs/create':                undefined;
  '/(boss)/jobs/[id]':                  { id: string };
  '/(boss)/jobs/rooms':                 { jobId: string };
  '/(boss)/jobs/plans':                 { jobId: string };
  '/(boss)/walkthrough/[jobId]':        { jobId: string };
  '/(boss)/review/[jobId]':             { jobId: string };
  '/(boss)/tasks':                      undefined;
  '/(boss)/tasks/[id]':                 { id: string };
  '/(worker)/tasks':                    undefined;
  '/(worker)/tasks/[id]':               { id: string };
  '/settings':                          undefined;
};
