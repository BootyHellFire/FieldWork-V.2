/**
 * WalkthroughStore
 *
 * Simple in-memory store for walkthrough session data that needs to
 * survive navigation from the walkthrough screen to the review screen.
 *
 * We can't pass ExtractedTask[] through URL params (too large) and
 * we don't have global state management in V1, so this singleton
 * acts as a simple handoff mechanism.
 *
 * Cleared automatically when the review screen publishes tasks.
 */

import { ExtractedTask } from '@/types';

let _extracted: ExtractedTask[] = [];
let _transcript = '';
let _sessionId: string | null = null;

export const WalkthroughStore = {
  setExtracted(tasks: ExtractedTask[]) {
    _extracted = tasks.map(t => ({ ...t })); // defensive copy
  },
  getExtracted(): ExtractedTask[] {
    return _extracted;
  },
  setTranscript(text: string) {
    _transcript = text;
  },
  getTranscript(): string {
    return _transcript;
  },
  setSessionId(id: string) {
    _sessionId = id;
  },
  getSessionId(): string | null {
    return _sessionId;
  },
  clear() {
    _extracted = [];
    _transcript = '';
    _sessionId = null;
  },
};
