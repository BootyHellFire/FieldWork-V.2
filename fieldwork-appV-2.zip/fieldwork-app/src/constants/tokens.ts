// Design tokens — ported 1:1 from HTML mockup CSS variables.
// Every color, spacing, and radius used in the app lives here.

export const colors = {
  // Backgrounds (darkest to lightest)
  bg0: '#0D0F12',
  bg1: '#13161A',
  bg2: '#1A1E24',
  bg3: '#22272F',
  bg4: '#2A3140',

  // Borders
  border:  '#252C38',
  border2: '#2E3848',
  border3: '#3A4558',

  // Text
  text1: '#E8EDF4', // primary
  text2: '#8A98AB', // secondary
  text3: '#4D5C6E', // muted / labels

  // Amber accent (primary CTA, measurements, amber badges)
  amber:    '#F0B429',
  amberD:   '#C68F10',
  amberBg:  '#1E1607',
  amberT:   '#F0B429',
  amberBdr: '#2E1F08',

  // Green (done / success)
  green:    '#22C55E',
  greenBg:  '#091A0E',
  greenT:   '#4ADE80',
  greenBdr: '#0D2314',

  // Red (high priority / danger)
  red:    '#EF4444',
  redBg:  '#180A0A',
  redT:   '#F87171',
  redBdr: '#2E0F0F',

  // Blue (room / info)
  blue:    '#3B82F6',
  blueBg:  '#060F24',
  blueT:   '#60A5FA',
  blueBdr: '#0A1630',
} as const;

export const spacing = {
  xs:  4,
  sm:  8,
  md:  12,
  lg:  16,
  xl:  24,
  xxl: 32,
} as const;

export const radii = {
  sm:  6,
  md:  10,
  lg:  14,
  full: 999,
} as const;

export const fontSizes = {
  xs:   10,
  sm:   11,
  base: 13,
  md:   14,
  lg:   15,
  xl:   16,
  xxl:  21,
  hero: 26,
} as const;

export const fontWeights = {
  regular: '400' as const,
  medium:  '500' as const,
  semibold:'600' as const,
};

// Common shadow — used for cards on bg0 surfaces
export const shadow = {
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.25,
  shadowRadius: 4,
  elevation: 3,
};
