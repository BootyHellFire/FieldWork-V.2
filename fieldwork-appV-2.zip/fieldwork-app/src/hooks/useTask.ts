/**
 * useTask — loads a single task with full live data.
 * Falls back to DEMO_TASKS when Supabase is not configured.
 *
 * Uses fetchTaskFull from databaseExtras for the richest query
 * (room name, assignee name, comments with authors, photos).
 */

import { useState, useEffect, useCallback } from 'react';
import { Task } from '@/types';
import { fetchTaskFull } from '@/services/databaseExtras';
import { DEMO_TASKS } from '@/data/tasks';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

interface UseTaskResult {
  task: Task | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

export function useTask(taskId: number): UseTaskResult {
  const demoTask = DEMO_TASKS.find(t => t.id === taskId) ?? DEMO_TASKS[0];

  const [task,    setTask]    = useState<Task | null>(IS_DEMO ? demoTask : null);
  const [loading, setLoading] = useState(!IS_DEMO);
  const [error,   setError]   = useState<string | null>(null);

  const load = useCallback(async () => {
    if (IS_DEMO) return;
    setLoading(true);
    setError(null);
    try {
      const raw = await fetchTaskFull(taskId);
      if (!raw) {
        setTask(demoTask); // fallback
        return;
      }

      // Map the rich DB row to our Task type
      const m = (raw as any).measurements_json ?? {};
      const mapped: Task = {
        id:          raw.id,
        jobId:       (raw as any).job_id,
        room:        (raw as any).rooms?.name ?? 'Unknown',
        title:       raw.title,
        description: (raw as any).description ?? '',
        assignee:    (raw as any).users?.full_name ?? 'Unassigned',
        stage:       (raw as any).stage ?? 'rough',
        priority:    (raw as any).priority ?? 'normal',
        status:      (raw as any).status ?? 'pending',
        measurements: {
          heightFromFFL:       m.height_from_ffl_inches,
          offsetFromRightWall: m.offset_from_right_wall_inches,
          label:               buildLabel(m),
        },
        transcriptSnippet: (raw as any).transcript_snippet ?? '',
        comments: ((raw as any).task_comments ?? []).map((c: any) => ({
          who:       c.users?.full_name ?? 'Unknown',
          text:      c.comment,
          timestamp: formatTs(c.created_at),
        })),
      };
      setTask(mapped);
    } catch (err: any) {
      setError(err.message ?? 'Failed to load task');
      setTask(demoTask);
    } finally {
      setLoading(false);
    }
  }, [taskId]);

  useEffect(() => { load(); }, [load]);

  return { task, loading, error, refresh: load };
}

function buildLabel(m: any): string {
  const parts: string[] = [];
  if (m?.height_from_ffl_inches)        parts.push(`${m.height_from_ffl_inches}" from FFL`);
  if (m?.offset_from_right_wall_inches) parts.push(`${m.offset_from_right_wall_inches}" from right wall`);
  if (m?.offset_from_left_wall_inches)  parts.push(`${m.offset_from_left_wall_inches}" from left wall`);
  if (m?.centered_on)                   parts.push(`centered on ${m.centered_on}`);
  return parts.length > 0 ? parts.join('  ·  ') : 'No measurements';
}

function formatTs(iso: string): string {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1)    return 'Just now';
  if (mins < 60)   return `${mins}m ago`;
  if (mins < 1440) return `${Math.floor(mins / 60)}h ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
