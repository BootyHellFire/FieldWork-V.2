/**
 * useRealtimeTasks — M4 fixed
 *
 * Added demo fallback: when EXPO_PUBLIC_SUPABASE_URL is not set,
 * returns DEMO_TASKS immediately instead of attempting a Supabase call.
 */

import { useState, useEffect, useCallback } from 'react';
import { Task } from '@/types';
import { fetchTasks, fetchMyTasks } from '@/services/database';
import { supabase } from '@/lib/supabase';
import { DEMO_TASKS } from '@/data/tasks';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

interface UseRealtimeTasksResult {
  tasks: Task[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

// ── Boss: all tasks for a job ─────────────────────────────────

export function useRealtimeTasks(jobId: number): UseRealtimeTasksResult {
  const [tasks,   setTasks]   = useState<Task[]>(IS_DEMO ? DEMO_TASKS : []);
  const [loading, setLoading] = useState(!IS_DEMO);
  const [error,   setError]   = useState<string | null>(null);

  const load = useCallback(async () => {
    if (IS_DEMO) return;
    setLoading(true);
    setError(null);
    try {
      const data = await fetchTasks(jobId);
      setTasks(data);
    } catch (err: any) {
      setError(err.message ?? 'Failed to load tasks');
      setTasks(DEMO_TASKS); // graceful fallback
    } finally {
      setLoading(false);
    }
  }, [jobId]);

  useEffect(() => {
    load();
    if (IS_DEMO) return; // no realtime subscription in demo mode

    const channel = supabase
      .channel(`tasks-job-${jobId}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'tasks',
        filter: `job_id=eq.${jobId}`,
      }, () => load())
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [jobId, load]);

  return { tasks, loading, error, refresh: load };
}

// ── Worker: only tasks assigned to this user ──────────────────

export function useMyRealtimeTasks(userId: string): UseRealtimeTasksResult {
  // Demo mode: Jake sees Jake's tasks
  const demoTasks = DEMO_TASKS.filter(t => t.assignee === 'Jake');

  const [tasks,   setTasks]   = useState<Task[]>(IS_DEMO ? demoTasks : []);
  const [loading, setLoading] = useState(!IS_DEMO);
  const [error,   setError]   = useState<string | null>(null);

  const load = useCallback(async () => {
    if (IS_DEMO) return;
    setLoading(true);
    setError(null);
    try {
      const data = await fetchMyTasks(userId);
      setTasks(data);
    } catch (err: any) {
      setError(err.message ?? 'Failed to load tasks');
      setTasks(demoTasks);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    load();
    if (IS_DEMO) return;

    const channel = supabase
      .channel(`tasks-worker-${userId}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'tasks',
        filter: `assigned_to_user_id=eq.${userId}`,
      }, () => load())
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [userId, load]);

  return { tasks, loading, error, refresh: load };
}
