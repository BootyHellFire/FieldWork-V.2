/**
 * useCamera
 *
 * Manages camera permission, ref, and snapshot capture.
 * Snapshots are taken as JPEG, stored locally, and can be
 * uploaded to Supabase Storage via the storage service.
 *
 * Usage:
 *   const { cameraRef, hasPermission, requestPermission, takeSnapshot } = useCamera();
 *   // In JSX: <CameraView ref={cameraRef} ... />
 */

import { useState, useRef, useCallback } from 'react';
import { CameraView, useCameraPermissions, CameraType } from 'expo-camera';
import { uploadSnapshot } from '@/services/storage';
import { enqueue } from '@/services/offlineQueue';
import NetInfo from '@react-native-community/netinfo';

interface UseCameraResult {
  cameraRef: React.RefObject<CameraView>;
  hasPermission: boolean | null;
  requestPermission: () => Promise<void>;
  facing: CameraType;
  flipCamera: () => void;
  /**
   * Takes a snapshot, optionally uploads it.
   * Returns the local URI always, and the uploaded URL if online.
   */
  takeSnapshot: (jobId: number, sessionId: string, index: number) => Promise<{
    localUri: string;
    uploadedUrl?: string;
  }>;
}

export function useCamera(): UseCameraResult {
  const cameraRef = useRef<CameraView>(null);
  const [permission, requestPerm] = useCameraPermissions();
  const [facing, setFacing] = useState<CameraType>('back');

  const hasPermission = permission?.granted ?? null;

  const requestPermission = useCallback(async () => {
    await requestPerm();
  }, [requestPerm]);

  const flipCamera = useCallback(() => {
    setFacing(f => (f === 'back' ? 'front' : 'back'));
  }, []);

  const takeSnapshot = useCallback(async (
    jobId: number,
    sessionId: string,
    index: number
  ): Promise<{ localUri: string; uploadedUrl?: string }> => {
    if (!cameraRef.current) throw new Error('Camera not ready');

    const photo = await cameraRef.current.takePictureAsync({
      quality: 0.7,     // Good quality without giant files
      skipProcessing: false,
    });

    const localUri = photo.uri;
    let uploadedUrl: string | undefined;

    const net = await NetInfo.fetch();
    const isOnline = net.isConnected && net.isInternetReachable;

    if (isOnline) {
      try {
        uploadedUrl = await uploadSnapshot(localUri, jobId, sessionId, index);
      } catch (err: any) {
        console.warn('[Camera] Snapshot upload failed, queuing:', err.message);
        await enqueue('snapshot_upload', { localUri, jobId, sessionId, index });
      }
    } else {
      await enqueue('snapshot_upload', { localUri, jobId, sessionId, index });
    }

    return { localUri, uploadedUrl };
  }, []);

  return { cameraRef, hasPermission, requestPermission, facing, flipCamera, takeSnapshot };
}
