/**
 * useNotifications
 *
 * - Registers for Expo push notifications on mount
 * - Saves the push token to Supabase users table
 * - Returns unread notification count via Supabase Realtime
 * - Handles foreground notification display
 *
 * Call once in _layout.tsx or the home screen for each role.
 */

import { useState, useEffect, useRef } from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

// Show banners while the app is in foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge:  true,
  }),
});

interface UseNotificationsResult {
  unreadCount: number;
  /** Mark all as read */
  markAllRead: () => Promise<void>;
}

export function useNotifications(): UseNotificationsResult {
  const { user }    = useAuth();
  const [unread, setUnread] = useState(0);
  const listenerRef = useRef<Notifications.Subscription | null>(null);

  // ── Register push token ───────────────────────────
  useEffect(() => {
    if (!user || user.id.startsWith('demo-')) return;
    registerForPushNotifications(user.id);
  }, [user?.id]);

  // ── Realtime unread count ─────────────────────────
  useEffect(() => {
    if (!user || user.id.startsWith('demo-')) return;

    // Initial load
    loadUnreadCount(user.id).then(setUnread);

    // Subscribe to new notifications
    const channel = supabase
      .channel(`notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`,
        },
        () => loadUnreadCount(user.id).then(setUnread)
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user?.id]);

  // ── Foreground notification listener ─────────────
  useEffect(() => {
    listenerRef.current = Notifications.addNotificationReceivedListener(() => {
      if (user && !user.id.startsWith('demo-')) {
        loadUnreadCount(user.id).then(setUnread);
      }
    });
    return () => listenerRef.current?.remove();
  }, [user?.id]);

  const markAllRead = async () => {
    if (!user || user.id.startsWith('demo-')) return;
    await supabase
      .from('notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('user_id', user.id)
      .is('read_at', null);
    setUnread(0);
  };

  return { unreadCount: unread, markAllRead };
}

// ── Helpers ───────────────────────────────────────────

async function loadUnreadCount(userId: string): Promise<number> {
  const { count } = await supabase
    .from('notifications')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .is('read_at', null);
  return count ?? 0;
}

async function registerForPushNotifications(userId: string): Promise<void> {
  if (!Device.isDevice) return; // simulator — skip

  const { status: existing } = await Notifications.getPermissionsAsync();
  let finalStatus = existing;

  if (existing !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.log('[Push] Permission not granted');
    return;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Fieldwork',
      importance: Notifications.AndroidImportance.HIGH,
    });
  }

  const token = (await Notifications.getExpoPushTokenAsync()).data;

  // Store token in users table so the server can send targeted pushes
  await supabase
    .from('users')
    .update({ push_token: token } as any)
    .eq('id', userId);
}
