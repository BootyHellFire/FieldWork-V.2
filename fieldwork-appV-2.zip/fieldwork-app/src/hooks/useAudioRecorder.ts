/**
 * useAudioRecorder
 *
 * Manages the full audio lifecycle:
 *   1. Request microphone permission
 *   2. Start recording with expo-av (outputs .m4a)
 *   3. Stop recording → returns local URI
 *   4. Upload URI to Supabase Storage (or queue if offline)
 *   5. Send URI to whisper-1 for transcription
 *   6. Return transcript text to the caller
 *
 * Usage:
 *   const { isRecording, startRecording, stopAndTranscribe, error } = useAudioRecorder();
 */

import { useState, useRef, useCallback } from 'react';
import { Audio } from 'expo-av';
import { uploadAudioClip } from '@/services/storage';
import { transcribeAudio } from '@/services/openai';
import { enqueue } from '@/services/offlineQueue';
import NetInfo from '@react-native-community/netinfo';

interface UseAudioRecorderResult {
  isRecording: boolean;
  durationMs: number;
  /** Start recording. Requests permission if not yet granted. */
  startRecording: () => Promise<void>;
  /**
   * Stop recording, upload the clip, and run whisper-1 transcription.
   * Returns the transcript string and the local file URI.
   */
  stopAndTranscribe: (jobId: number, sessionId: string) => Promise<{
    transcript: string;
    audioUri: string;
    uploadedUrl?: string;
  }>;
  error: string | null;
}

export function useAudioRecorder(): UseAudioRecorderResult {
  const [isRecording, setIsRecording]  = useState(false);
  const [durationMs, setDurationMs]    = useState(0);
  const [error, setError]              = useState<string | null>(null);
  const recordingRef = useRef<Audio.Recording | null>(null);
  const timerRef     = useRef<ReturnType<typeof setInterval> | null>(null);

  const startRecording = useCallback(async () => {
    setError(null);
    try {
      // 1. Permission
      const { status } = await Audio.requestPermissionsAsync();
      if (status !== 'granted') {
        setError('Microphone permission denied.');
        return;
      }

      // 2. Configure audio session for recording
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      // 3. Create and start recording
      const { recording } = await Audio.Recording.createAsync(
        // HIGH_QUALITY preset gives us 44.1 kHz AAC — good for whisper-1
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );

      recordingRef.current = recording;
      setIsRecording(true);
      setDurationMs(0);

      // 4. Duration counter
      timerRef.current = setInterval(() => {
        setDurationMs(ms => ms + 1000);
      }, 1000);

    } catch (err: any) {
      setError(`Failed to start recording: ${err.message}`);
    }
  }, []);

  const stopAndTranscribe = useCallback(async (
    jobId: number,
    sessionId: string
  ): Promise<{ transcript: string; audioUri: string; uploadedUrl?: string }> => {
    if (!recordingRef.current) {
      throw new Error('No active recording to stop.');
    }

    clearInterval(timerRef.current!);
    setIsRecording(false);

    // 1. Stop recording
    await recordingRef.current.stopAndUnloadAsync();
    await Audio.setAudioModeAsync({ allowsRecordingIOS: false });

    const audioUri = recordingRef.current.getURI() ?? '';
    recordingRef.current = null;

    if (!audioUri) throw new Error('Recording URI is empty.');

    let uploadedUrl: string | undefined;

    // 2. Upload (or queue if offline)
    const net = await NetInfo.fetch();
    const isOnline = net.isConnected && net.isInternetReachable;

    if (isOnline) {
      try {
        uploadedUrl = await uploadAudioClip(audioUri, jobId, sessionId);
      } catch (uploadErr: any) {
        console.warn('[Audio] Upload failed, queuing:', uploadErr.message);
        await enqueue('audio_upload', { audioUri, jobId, sessionId });
      }
    } else {
      await enqueue('audio_upload', { audioUri, jobId, sessionId });
    }

    // 3. Transcribe — uses local URI so works even if upload failed/queued
    let transcript = '';
    if (isOnline) {
      try {
        transcript = await transcribeAudio(audioUri);
      } catch (tErr: any) {
        console.warn('[Audio] Transcription failed:', tErr.message);
        setError(`Transcription failed: ${tErr.message}`);
      }
    }

    return { transcript, audioUri, uploadedUrl };
  }, []);

  return { isRecording, durationMs, startRecording, stopAndTranscribe, error };
}
