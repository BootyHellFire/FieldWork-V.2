/**
 * useJobs — fetches the job list for the current user.
 * Falls back to DEMO_JOBS when Supabase is not configured.
 */

import { useState, useEffect, useCallback } from 'react';
import { Job } from '@/types';
import { fetchJobs } from '@/services/database';
import { DEMO_JOBS } from '@/data/jobs';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

interface UseJobsResult {
  jobs: Job[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

export function useJobs(): UseJobsResult {
  const [jobs,    setJobs]    = useState<Job[]>(IS_DEMO ? DEMO_JOBS : []);
  const [loading, setLoading] = useState(!IS_DEMO);
  const [error,   setError]   = useState<string | null>(null);

  const load = useCallback(async () => {
    if (IS_DEMO) return;
    setLoading(true);
    setError(null);
    try {
      const data = await fetchJobs();
      setJobs(data);
    } catch (err: any) {
      setError(err.message ?? 'Failed to load jobs');
      // Fall back to demo data so the screen isn't blank
      setJobs(DEMO_JOBS);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return { jobs, loading, error, refresh: load };
}
