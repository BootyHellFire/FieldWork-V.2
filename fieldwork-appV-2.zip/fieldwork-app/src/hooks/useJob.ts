/**
 * useJob — fetches a single job and its rooms.
 * Falls back to demo data when Supabase is not configured.
 */

import { useState, useEffect, useCallback } from 'react';
import { Job, Room } from '@/types';
import { fetchJob, fetchRooms } from '@/services/database';
import { DEMO_JOBS } from '@/data/jobs';
import { DEMO_ROOMS } from '@/data/rooms';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

interface UseJobResult {
  job: Job | null;
  rooms: Room[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

export function useJob(jobId: number): UseJobResult {
  const [job,     setJob]     = useState<Job | null>(IS_DEMO ? (DEMO_JOBS.find(j => j.id === jobId) ?? null) : null);
  const [rooms,   setRooms]   = useState<Room[]>(IS_DEMO ? DEMO_ROOMS.filter(r => r.jobId === jobId) : []);
  const [loading, setLoading] = useState(!IS_DEMO);
  const [error,   setError]   = useState<string | null>(null);

  const load = useCallback(async () => {
    if (IS_DEMO) return;
    setLoading(true);
    setError(null);
    try {
      const [jobData, roomData] = await Promise.all([
        fetchJob(jobId),
        fetchRooms(jobId),
      ]);
      setJob(jobData);
      setRooms(roomData);
    } catch (err: any) {
      setError(err.message ?? 'Failed to load job');
      setJob(DEMO_JOBS.find(j => j.id === jobId) ?? null);
      setRooms(DEMO_ROOMS.filter(r => r.jobId === jobId));
    } finally {
      setLoading(false);
    }
  }, [jobId]);

  useEffect(() => { load(); }, [load]);

  return { job, rooms, loading, error, refresh: load };
}
