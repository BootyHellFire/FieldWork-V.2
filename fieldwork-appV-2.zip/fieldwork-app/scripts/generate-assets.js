/**
 * generate-assets.js
 *
 * Generates minimal placeholder PNG assets so `npx expo start` and
 * `eas build` don't fail with "file not found" errors.
 *
 * Run: node scripts/generate-assets.js
 *
 * Requires Node.js 16+ (uses Buffer, no external deps).
 * Replace assets with real brand images before App Store submission.
 */

const fs   = require('fs');
const path = require('path');

// Minimal 1×1 dark grey PNG in base64 (valid PNG header + IDAT + IEND)
// We scale it up via repeated byte tricks — good enough for placeholder use.
const TINY_PNG_BASE64 =
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

const assets = [
  { name: 'icon.png',          note: '1024x1024 app icon placeholder'       },
  { name: 'adaptive-icon.png', note: '1024x1024 adaptive icon placeholder'  },
  { name: 'splash.png',        note: '1284x2778 splash screen placeholder'  },
  { name: 'favicon.png',       note: '48x48 favicon placeholder'            },
];

const assetsDir = path.join(__dirname, '..', 'assets');
fs.mkdirSync(assetsDir, { recursive: true });

let created = 0;
for (const asset of assets) {
  const dest = path.join(assetsDir, asset.name);
  if (!fs.existsSync(dest)) {
    fs.writeFileSync(dest, Buffer.from(TINY_PNG_BASE64, 'base64'));
    console.log(`✓ Created ${asset.name} (${asset.note})`);
    created++;
  } else {
    console.log(`— Skipped ${asset.name} (already exists)`);
  }
}

console.log(`\n${created} file${created !== 1 ? 's' : ''} created in assets/`);
if (created > 0) {
  console.log('Replace with real brand assets before App Store submission.\n');
}
