/**
 * Walkthrough Capture Screen — Milestone 2
 *
 * Real pipeline:
 *   1. expo-camera live preview
 *   2. expo-av records audio (.m4a) while boss speaks
 *   3. On "Finish Session":
 *      a. Stop recording → get local URI
 *      b. Upload audio to Supabase Storage (or queue if offline)
 *      c. Send to whisper-1 → full transcript text
 *      d. Send transcript + room/assignee context → gpt-4o → ExtractedTask[]
 *      e. Save extracted tasks to local state → navigate to review screen
 *   4. Snapshots captured with camera, saved locally + queued for upload
 *
 * Falls back to demo data if OpenAI keys are missing (for TestFlight demo builds).
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import { CameraView } from 'expo-camera';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useAudioRecorder } from '@/hooks/useAudioRecorder';
import { useCamera } from '@/hooks/useCamera';
import { extractTasks } from '@/services/openai';
import { createWalkthroughSession, endWalkthroughSession } from '@/services/database';
import { useAuth } from '@/context/AuthContext';

import { DEMO_JOBS } from '@/data/jobs';
import { WALKTHROUGH_ROOMS } from '@/data/rooms';
import { DEMO_EXTRACTED, DEMO_TRANSCRIPT_CHUNKS } from '@/data/extracted';

import { ControlBtn } from '@/components/walkthrough/ControlBtn';
import { SnapshotStrip } from '@/components/walkthrough/SnapshotStrip';
import { TranscriptBox } from '@/components/walkthrough/TranscriptBox';
import { Badge } from '@/components/ui/Badge';
import { Btn } from '@/components/ui/Btn';
import { ExtractedTask, TaskPriority, TaskStage, WalkthroughState } from '@/types';
import { WalkthroughStore } from '@/stores/WalkthroughStore';
import { colors, fontSizes, fontWeights, radii } from '@/constants/tokens';

const STAGES: TaskStage[] = ['rough', 'trim', 'finish', 'punch'];
const ASSIGNEES = [null, 'Jake', 'Carson'];
// IS_DEMO is true when neither Supabase nor OpenAI is configured
const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL && !process.env.EXPO_PUBLIC_OPENAI_API_KEY;

export default function WalkthroughScreen() {
  const { jobId } = useLocalSearchParams<{ jobId: string }>();
  const router    = useRouter();
  const insets    = useSafeAreaInsets();
  const { user }  = useAuth();

  const job = DEMO_JOBS.find(j => j.id === Number(jobId)) ?? DEMO_JOBS[0];

  // ── Walkthrough state ─────────────────────────────
  const [wk, setWk] = useState<WalkthroughState>({
    recording:     false,
    currentRoom:   'Master Bath',
    assignee:      null,
    priority:      'normal',
    stage:         'rough',
    snapshotCount: 0,
    transcript:    '',
  });

  const [processing,   setProcessing]   = useState(false);
  const [sessionId,    setSessionId]    = useState<string | null>(null);
  const [snapshotUris, setSnapshotUris] = useState<string[]>([]);

  // Demo transcript simulation (used when no real recording happens)
  const demoIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const demoChunkIdx    = useRef(0);

  // ── Hooks ────────────────────────────────────────
  const audio  = useAudioRecorder();
  const camera = useCamera();

  // Request camera permission on mount
  useEffect(() => {
    if (camera.hasPermission === false) camera.requestPermission();
  }, [camera.hasPermission]);

  // ── Start session ─────────────────────────────────
  async function handleStartRecording() {
    // Create a DB session record (skip in demo mode)
    let sid = `demo-${Date.now()}`;
    if (!IS_DEMO && user && user.id !== 'demo-boss') {
      try {
        sid = await createWalkthroughSession(Number(jobId), user.id);
      } catch (e) {
        console.warn('[Walk] Could not create DB session, using local id');
      }
    }
    setSessionId(sid);

    if (IS_DEMO) {
      // Simulate transcript streaming
      demoChunkIdx.current = 0;
      setWk(prev => ({ ...prev, recording: true, transcript: '' }));
      demoIntervalRef.current = setInterval(() => {
        if (demoChunkIdx.current < DEMO_TRANSCRIPT_CHUNKS.length) {
          setWk(prev => ({
            ...prev,
            transcript: prev.transcript + DEMO_TRANSCRIPT_CHUNKS[demoChunkIdx.current],
          }));
          demoChunkIdx.current += 1;
        } else {
          clearInterval(demoIntervalRef.current!);
        }
      }, 2000);
    } else {
      await audio.startRecording();
      setWk(prev => ({ ...prev, recording: true, transcript: '' }));
    }
  }

  // ── Snapshot ────────────────────────────────────
  const handleSnap = useCallback(async () => {
    if (IS_DEMO || !sessionId) {
      setWk(prev => ({ ...prev, snapshotCount: prev.snapshotCount + 1 }));
      return;
    }
    try {
      const { localUri } = await camera.takeSnapshot(
        Number(jobId), sessionId, wk.snapshotCount + 1
      );
      setSnapshotUris(prev => [...prev, localUri]);
      setWk(prev => ({ ...prev, snapshotCount: prev.snapshotCount + 1 }));
    } catch (err: any) {
      Alert.alert('Snapshot failed', err.message);
    }
  }, [sessionId, wk.snapshotCount, jobId, camera]);

  // ── Controls ────────────────────────────────────
  const cycleRoom = useCallback(() => {
    setWk(prev => {
      const i   = WALKTHROUGH_ROOMS.indexOf(prev.currentRoom);
      const next = WALKTHROUGH_ROOMS[(i + 1) % WALKTHROUGH_ROOMS.length];
      return {
        ...prev,
        currentRoom: next,
        transcript: prev.recording ? prev.transcript + ` [→ ${next}]` : prev.transcript,
      };
    });
  }, []);

  const cycleAssignee = useCallback(() => {
    setWk(prev => {
      const i = ASSIGNEES.indexOf(prev.assignee);
      return { ...prev, assignee: ASSIGNEES[(i + 1) % ASSIGNEES.length] };
    });
  }, []);

  const togglePriority = useCallback(() => {
    setWk(prev => ({ ...prev, priority: prev.priority === 'high' ? 'normal' : 'high' }));
  }, []);

  const cycleStage = useCallback(() => {
    setWk(prev => {
      const i = STAGES.indexOf(prev.stage);
      return { ...prev, stage: STAGES[(i + 1) % STAGES.length] };
    });
  }, []);

  // ── Finish session ───────────────────────────────
  async function handleFinish() {
    if (!wk.recording) {
      router.push(`/(boss)/review/${jobId}`);
      return;
    }

    Alert.alert(
      'Finish Session',
      'Stop recording and extract tasks from the transcript?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Finish', onPress: runExtraction },
      ]
    );
  }

  async function runExtraction() {
    clearInterval(demoIntervalRef.current!);
    setProcessing(true);
    setWk(prev => ({ ...prev, recording: false }));

    try {
      if (IS_DEMO) {
        // Demo: use pre-baked extracted tasks, simulate a delay
        await new Promise(r => setTimeout(r, 2400));
        WalkthroughStore.setExtracted(
          DEMO_EXTRACTED.map(t => ({ ...t, approved: false, discarded: false }))
        );
      } else {
        // Real: stop audio → transcribe → extract
        const { transcript } = await audio.stopAndTranscribe(Number(jobId), sessionId!);

        // Update transcript in state so review screen can show it
        setWk(prev => ({ ...prev, transcript }));
        WalkthroughStore.setTranscript(transcript);

        const tasks = await extractTasks({
          transcript,
          roomName:  wk.currentRoom,
          assignee:  wk.assignee,
          stage:     wk.stage,
        });

        WalkthroughStore.setExtracted(tasks);

        // Close DB session
        if (sessionId) {
          WalkthroughStore.setSessionId(sessionId);
          await endWalkthroughSession(sessionId).catch(() => {});
        }
      }
      }

      router.push(`/(boss)/review/${jobId}`);
    } catch (err: any) {
      Alert.alert('Extraction failed', err.message ?? 'Could not process transcript.');
    } finally {
      setProcessing(false);
    }
  }

  // ── Processing overlay ────────────────────────────
  if (processing) {
    return (
      <View style={[styles.processingRoot, { paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color={colors.amber} />
        <Text style={styles.procTitle}>Extracting tasks with AI</Text>
        <Text style={styles.procSub}>
          {IS_DEMO
            ? 'Simulating AI extraction...'
            : 'whisper-1 → gpt-4o · parsing transcript...'}
        </Text>
        <View style={styles.procBadges}>
          <Badge label="gpt-4o"    variant="amber" />
          <Badge label="whisper-1" variant="gray"  />
        </View>
      </View>
    );
  }

  const wordCount = wk.transcript.trim().split(/\s+/).filter(Boolean).length;

  // ── Main UI ──────────────────────────────────────
  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.hdr}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <Text style={styles.jobName} numberOfLines={1}>{job.name}</Text>
        <Badge label={wk.currentRoom} variant="amber" />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.inner}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* ── Camera preview ── */}
        <View style={styles.camWrap}>
          {camera.hasPermission && !IS_DEMO ? (
            <CameraView
              ref={camera.cameraRef}
              style={styles.camera}
              facing={camera.facing}
            />
          ) : (
            <View style={styles.camPlaceholder}>
              {wk.recording ? (
                <View style={styles.camActive}>
                  <Text style={styles.recDotLg}>●</Text>
                  <Text style={styles.camActiveText}>Recording in progress</Text>
                  <Text style={styles.camDuration}>
                    {formatDuration(IS_DEMO ? 0 : audio.durationMs)}
                  </Text>
                </View>
              ) : (
                <View style={styles.camIdle}>
                  <Text style={styles.camIcon}>📷</Text>
                  <Text style={styles.camIdleText}>Camera preview</Text>
                  <Text style={styles.camIdleSub}>Tap Start Recording to begin</Text>
                </View>
              )}
            </View>
          )}

          {/* REC pill overlay */}
          {wk.recording && (
            <View style={styles.recPill}>
              <Text style={styles.recDotSm}>●</Text>
              <Text style={styles.recLabel}>REC</Text>
              {!IS_DEMO && (
                <Text style={styles.recDuration}>{formatDuration(audio.durationMs)}</Text>
              )}
            </View>
          )}

          {/* Flip button (real camera only) */}
          {camera.hasPermission && !IS_DEMO && (
            <TouchableOpacity style={styles.flipBtn} onPress={camera.flipCamera} activeOpacity={0.7}>
              <Text style={styles.flipIcon}>⇄</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* ── Snapshot strip ── */}
        <SnapshotStrip count={wk.snapshotCount} uris={snapshotUris} />

        {/* ── Live transcript ── */}
        <TranscriptBox text={wk.transcript} wordCount={wordCount} />

        {/* ── Controls grid ── */}
        <Text style={styles.ctrlLabel}>Controls</Text>
        <View style={styles.ctrlGrid}>
          <ControlBtn icon="📷" label="Snap"                             onPress={handleSnap}      />
          <ControlBtn icon="🏷"  label={wk.currentRoom.split(' ')[0]}    onPress={cycleRoom}       />
          <ControlBtn icon="👤" label={wk.assignee ?? 'Assign'}          active={!!wk.assignee}    onPress={cycleAssignee} />
          <ControlBtn icon="🚩" label={wk.priority === 'high' ? 'High' : 'Pri'} active={wk.priority === 'high'} onPress={togglePriority} />
          <ControlBtn icon="⚙"  label={wk.stage}                         onPress={cycleStage}      />
        </View>

        {/* ── Action buttons ── */}
        <View style={styles.actions}>
          {!wk.recording ? (
            <Btn
              label="🎙  Start Recording"
              variant="primary"
              fullWidth
              onPress={handleStartRecording}
              style={styles.startBtn}
            />
          ) : (
            <View style={styles.recActiveRow}>
              <Text style={styles.recDotLg}>●</Text>
              <Text style={styles.recActiveText}>Recording...</Text>
              <Text style={styles.recActiveWords}>{wordCount} words</Text>
            </View>
          )}

          <Btn
            label="Finish Session"
            variant="default"
            fullWidth
            disabled={!wk.recording}
            onPress={handleFinish}
          />
        </View>

        {/* Audio error */}
        {audio.error && (
          <Text style={styles.errorText}>{audio.error}</Text>
        )}
      </ScrollView>
    </View>
  );
}

function formatDuration(ms: number): string {
  const total = Math.floor(ms / 1000);
  const m     = Math.floor(total / 60).toString().padStart(2, '0');
  const s     = (total % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

const styles = StyleSheet.create({
  root:          { flex: 1, backgroundColor: colors.bg1 },
  processingRoot: { flex: 1, backgroundColor: colors.bg0, alignItems: 'center', justifyContent: 'center', gap: 12 },
  procTitle:     { fontSize: fontSizes.lg, fontWeight: fontWeights.medium, color: colors.text1, marginTop: 8 },
  procSub:       { fontSize: fontSizes.sm, color: colors.text3, textAlign: 'center', lineHeight: 20 },
  procBadges:    { flexDirection: 'row', gap: 8, marginTop: 6 },
  hdr: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: 14, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.bg1,
  },
  backBtn:    { width: 30, height: 30, borderRadius: radii.sm, borderWidth: 1, borderColor: colors.border2, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  backArrow:  { color: colors.text2, fontSize: 17, lineHeight: 20 },
  jobName:    { flex: 1, fontSize: fontSizes.base, fontWeight: fontWeights.medium, color: colors.text1 },
  scroll:     { flex: 1 },
  inner:      { padding: 14, paddingBottom: 32, gap: 10 },
  camWrap: {
    backgroundColor: colors.bg0,
    borderWidth: 1, borderColor: colors.border,
    borderRadius: radii.lg,
    aspectRatio: 4 / 3,
    overflow: 'hidden',
    position: 'relative',
    flexShrink: 0,
  },
  camera:         { flex: 1 },
  camPlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  camIdle:        { alignItems: 'center', gap: 6 },
  camIcon:        { fontSize: 32 },
  camIdleText:    { fontSize: fontSizes.sm, color: colors.text3 },
  camIdleSub:     { fontSize: fontSizes.xs, color: colors.text3 },
  camActive:      { alignItems: 'center', gap: 6 },
  camActiveText:  { fontSize: fontSizes.sm, color: colors.text2 },
  camDuration:    { fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.amber, fontFamily: 'Courier New' },
  recPill: {
    position: 'absolute', top: 10, right: 10,
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(0,0,0,0.65)',
    paddingHorizontal: 10, paddingVertical: 4,
    borderRadius: radii.full,
    borderWidth: 1, borderColor: 'rgba(239,68,68,0.35)',
  },
  recDotSm:    { fontSize: 9,  color: colors.red },
  recDotLg:    { fontSize: 18, color: colors.red },
  recLabel:    { fontSize: fontSizes.xs, color: '#fff', fontWeight: fontWeights.medium },
  recDuration: { fontSize: fontSizes.xs, color: colors.text2, fontFamily: 'Courier New' },
  flipBtn: {
    position: 'absolute', bottom: 10, right: 10,
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: 'rgba(0,0,0,0.5)',
    alignItems: 'center', justifyContent: 'center',
  },
  flipIcon: { fontSize: 18, color: '#fff' },
  ctrlLabel: { fontSize: fontSizes.sm, color: colors.text3 },
  ctrlGrid:  { flexDirection: 'row', gap: 6 },
  actions:   { gap: 8, paddingTop: 4 },
  startBtn:  { paddingVertical: 14 },
  recActiveRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingVertical: 14, backgroundColor: colors.bg3,
    borderRadius: radii.md, borderWidth: 1, borderColor: colors.border2,
    paddingHorizontal: 16,
  },
  recActiveText:  { flex: 1, fontSize: fontSizes.base, color: colors.text2, fontWeight: fontWeights.medium },
  recActiveWords: { fontSize: fontSizes.sm, color: colors.text3 },
  errorText: { fontSize: fontSizes.sm, color: colors.redT, textAlign: 'center', paddingTop: 4 },
});
