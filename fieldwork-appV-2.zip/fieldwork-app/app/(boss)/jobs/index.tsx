/**
 * Boss Jobs Screen — M3
 * Wired to live Supabase data via useJobs() with demo fallback.
 * Adds OfflineBanner and error handling.
 */
import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useJobs } from '@/hooks/useJobs';
import { useNotifications } from '@/hooks/useNotifications';
import { Job, JobStatus } from '@/types';
import { Avatar } from '@/components/ui/Avatar';
import { Badge, BadgeVariant } from '@/components/ui/Badge';
import { ProgressBar } from '@/components/ui/shared';
import { BottomNav, BOSS_NAV } from '@/components/ui/BottomNav';
import { LoadingState, ErrorBanner, OfflineBanner } from '@/components/ui/feedback';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const STATUS_MAP: Record<JobStatus, { label: string; variant: BadgeVariant }> = {
  active:   { label: 'Active',       variant: 'green' },
  review:   { label: 'Needs Review', variant: 'amber' },
  upcoming: { label: 'Upcoming',     variant: 'gray'  },
};

export default function JobsScreen() {
  const { user } = useAuth();
  const router   = useRouter();
  const insets   = useSafeAreaInsets();
  const [nav, setNav] = useState('jobs');
  const [bannerErr, setBannerErr] = useState<string | null>(null);

  const { jobs, loading, error, refresh } = useJobs();
  const { unreadCount } = useNotifications();

  function handleNav(key: string) {
    setNav(key);
    if (key === 'tasks')    router.push('/(boss)/tasks');
    if (key === 'settings') router.push('/settings');
  }

  if (loading) return <LoadingState message="Loading jobs..." />;

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.hdr}>
        <View style={styles.logoRow}>
          <Text style={styles.bolt}>⚡</Text>
          <Text style={styles.wordmark}>Fieldwork</Text>
        </View>
        <View style={styles.hdrRight}>
          {unreadCount > 0 && (
            <View style={styles.notifBadge}>
              <Text style={styles.notifCount}>{unreadCount}</Text>
            </View>
          )}
          {user && <Avatar initials={user.initials} role={user.role} size={30} />}
        </View>
      </View>

      {/* Offline banner */}
      <OfflineBanner />

      {/* Error banner (non-fatal — data may still show from fallback) */}
      {(error || bannerErr) && (
        <ErrorBanner
          message={error ?? bannerErr ?? ''}
          onDismiss={() => setBannerErr(null)}
        />
      )}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={loading}
            onRefresh={refresh}
            tintColor={colors.amber}
          />
        }
      >
        <View style={styles.listHeader}>
          <Text style={styles.listTitle}>Jobs</Text>
          <TouchableOpacity
            style={styles.newBtn}
            onPress={() => router.push('/(boss)/jobs/create')}
            activeOpacity={0.7}
          >
            <Text style={styles.newBtnText}>+ New Job</Text>
          </TouchableOpacity>
        </View>

        {jobs.length === 0 ? (
          <View style={styles.emptyWrap}>
            <Text style={styles.emptyIcon}>🏗</Text>
            <Text style={styles.emptyTitle}>No jobs yet</Text>
            <Text style={styles.emptySub}>Tap "New Job" to create your first one.</Text>
          </View>
        ) : (
          jobs.map(job => (
            <JobCard
              key={job.id}
              job={job}
              onPress={() => router.push(`/(boss)/jobs/${job.id}`)}
            />
          ))
        )}
      </ScrollView>

      <BottomNav items={BOSS_NAV} activeKey={nav} onPress={handleNav} />
    </View>
  );
}

function JobCard({ job, onPress }: { job: Job; onPress: () => void }) {
  const pct = job.tasksTotal > 0 ? job.tasksDone / job.tasksTotal : 0;
  const { label, variant } = STATUS_MAP[job.status];
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.75}>
      <View style={styles.cardTop}>
        <Text style={styles.jobName} numberOfLines={2}>{job.name}</Text>
        <Badge label={label} variant={variant} />
      </View>
      <Text style={styles.addr} numberOfLines={1}>{job.address}</Text>
      <Text style={styles.builder}>{job.builder}</Text>
      <ProgressBar progress={pct} />
      <View style={styles.cardFoot}>
        <Text style={styles.meta}>{job.roomCount} rooms</Text>
        <Text style={styles.meta}>{job.tasksDone} / {job.tasksTotal} done</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root:       { flex: 1, backgroundColor: colors.bg0 },
  hdr:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.lg, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.bg1 },
  logoRow:    { flexDirection: 'row', alignItems: 'center', gap: 8 },
  bolt:       { fontSize: 18 },
  wordmark:   { fontSize: fontSizes.lg, fontWeight: fontWeights.semibold, color: colors.text1, letterSpacing: -0.3 },
  hdrRight:   { flexDirection: 'row', alignItems: 'center', gap: 10 },
  notifBadge: { backgroundColor: colors.red, borderRadius: radii.full, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  notifCount: { fontSize: 10, color: '#fff', fontWeight: fontWeights.semibold },
  scroll:     { flex: 1 },
  list:       { padding: spacing.lg, paddingBottom: 24 },
  listHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 13 },
  listTitle:  { fontSize: fontSizes.xl, fontWeight: fontWeights.medium, color: colors.text1 },
  newBtn:     { paddingHorizontal: 12, paddingVertical: 6, borderRadius: radii.md, borderWidth: 1, borderColor: colors.border2 },
  newBtnText: { fontSize: fontSizes.sm, color: colors.text2 },
  emptyWrap:  { alignItems: 'center', paddingVertical: 48 },
  emptyIcon:  { fontSize: 36, marginBottom: 14 },
  emptyTitle: { fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.text1, marginBottom: 6 },
  emptySub:   { fontSize: fontSizes.sm, color: colors.text3, textAlign: 'center' },
  card:       { backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 14, marginBottom: 9 },
  cardTop:    { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, marginBottom: 5 },
  jobName:    { flex: 1, fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.text1, lineHeight: 20 },
  addr:       { fontSize: fontSizes.xs, color: colors.text3, marginBottom: 2 },
  builder:    { fontSize: fontSizes.xs, color: colors.text3, marginBottom: 4 },
  cardFoot:   { flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 },
  meta:       { fontSize: fontSizes.xs, color: colors.text3 },
});
