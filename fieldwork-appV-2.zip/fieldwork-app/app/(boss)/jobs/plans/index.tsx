/**
 * Plan Upload Screen
 *
 * Boss picks an image (photo of a printed plan, screenshot, etc.)
 * or PDF from their device. File is uploaded to Supabase Storage
 * and a record is inserted into the plans table.
 *
 * V1: single-image plans only (PDFs display-only, no parsing).
 */

import React, { useState } from 'react';
import {
  View, Text, Image, TouchableOpacity,
  ScrollView, StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { supabase } from '@/lib/supabase';
import { uploadPlan } from '@/services/storage';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/ui/Header';
import { Btn } from '@/components/ui/Btn';
import { Separator } from '@/components/ui/shared';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

export default function PlanUploadScreen() {
  const { jobId }  = useLocalSearchParams<{ jobId: string }>();
  const router     = useRouter();
  const insets     = useSafeAreaInsets();
  const { user }   = useAuth();

  const [fileUri,   setFileUri]   = useState<string | null>(null);
  const [fileName,  setFileName]  = useState<string | null>(null);
  const [mimeType,  setMimeType]  = useState<'image/jpeg' | 'image/png' | 'application/pdf'>('image/jpeg');
  const [planTitle, setPlanTitle] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploaded,  setUploaded]  = useState(false);

  async function pickImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow photo library access in Settings.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.85,
      allowsEditing: false,
    });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    setFileUri(asset.uri);
    setFileName(asset.fileName ?? 'floor-plan.jpg');
    setMimeType((asset.mimeType as any) ?? 'image/jpeg');
    setUploaded(false);
  }

  async function pickCamera() {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow camera access in Settings.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      quality: 0.85,
      allowsEditing: false,
    });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    setFileUri(asset.uri);
    setFileName('plan-photo.jpg');
    setMimeType('image/jpeg');
    setUploaded(false);
  }

  async function handleUpload() {
    if (!fileUri) return;

    setUploading(true);
    try {
      if (IS_DEMO || !user || user.id.startsWith('demo-')) {
        await new Promise(r => setTimeout(r, 800));
        setUploaded(true);
        Alert.alert('Demo mode', 'Plan upload is wired to Supabase Storage in production.');
        return;
      }

      // Upload file to Supabase Storage
      const url = await uploadPlan(fileUri, Number(jobId), mimeType);

      // Insert record into plans table
      const { error } = await supabase.from('plans').insert({
        job_id:      Number(jobId),
        file_type:   mimeType === 'application/pdf' ? 'pdf' : 'image',
        file_url:    url,
        title:       planTitle || fileName || 'Floor Plan',
        uploaded_by: user.id,
      });

      if (error) throw error;

      setUploaded(true);
      Alert.alert('Uploaded', 'Floor plan saved successfully.', [
        { text: 'Go back', onPress: () => router.back() },
      ]);
    } catch (err: any) {
      Alert.alert('Upload failed', err.message ?? 'Could not upload plan.');
    } finally {
      setUploading(false);
    }
  }

  return (
    <View style={[styles.root, { paddingBottom: insets.bottom }]}>
      <Header title="Upload Floor Plan" onBack={() => router.back()} />

      <ScrollView style={styles.scroll} contentContainerStyle={styles.inner} showsVerticalScrollIndicator={false}>
        <Text style={styles.note}>
          V1: Single-image plans only. Take a photo of the printed plan, or pick a screenshot.
          The plan is stored for reference — rooms are labelled manually.
        </Text>

        {/* Pick source */}
        <View style={styles.pickRow}>
          <TouchableOpacity style={styles.pickBtn} onPress={pickCamera} activeOpacity={0.75}>
            <Text style={styles.pickIcon}>📷</Text>
            <Text style={styles.pickLabel}>Take photo</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.pickBtn} onPress={pickImage} activeOpacity={0.75}>
            <Text style={styles.pickIcon}>🖼</Text>
            <Text style={styles.pickLabel}>Choose image</Text>
          </TouchableOpacity>
        </View>

        {/* Preview */}
        {fileUri && (
          <>
            <Separator />
            <Text style={styles.sectionLabel}>PREVIEW</Text>
            <Image
              source={{ uri: fileUri }}
              style={styles.preview}
              resizeMode="contain"
            />
            <Text style={styles.fileName}>{fileName}</Text>

            <Text style={styles.sectionLabel}>PLAN TITLE (OPTIONAL)</Text>
            <View style={styles.inputWrap}>
              <Text style={styles.inputPlaceholder}>
                {planTitle || 'e.g. Main Level — Sheet A1'}
              </Text>
            </View>

            <Separator />

            {uploaded ? (
              <View style={styles.successRow}>
                <Text style={styles.successIcon}>✓</Text>
                <Text style={styles.successText}>Plan uploaded successfully</Text>
              </View>
            ) : (
              <Btn
                label={uploading ? 'Uploading...' : 'Upload Plan'}
                variant="primary"
                fullWidth
                onPress={handleUpload}
                loading={uploading}
                disabled={uploading}
                style={styles.uploadBtn}
              />
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:         { flex: 1, backgroundColor: colors.bg1 },
  scroll:       { flex: 1 },
  inner:        { padding: spacing.lg, paddingBottom: 40 },
  note:         { fontSize: fontSizes.sm, color: colors.text3, lineHeight: 20, marginBottom: 20 },
  pickRow:      { flexDirection: 'row', gap: 12 },
  pickBtn:      { flex: 1, backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, paddingVertical: 24, alignItems: 'center', gap: 8 },
  pickIcon:     { fontSize: 28 },
  pickLabel:    { fontSize: fontSizes.sm, color: colors.text2, fontWeight: fontWeights.medium },
  sectionLabel: { fontSize: fontSizes.xs, color: colors.text3, fontWeight: fontWeights.medium, letterSpacing: 0.6, marginBottom: 8, marginTop: 4 },
  preview:      { width: '100%', height: 240, backgroundColor: colors.bg0, borderRadius: radii.md, marginBottom: 8 },
  fileName:     { fontSize: fontSizes.xs, color: colors.text3, marginBottom: 16 },
  inputWrap:    { backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border2, borderRadius: radii.md, padding: 11, marginBottom: spacing.sm },
  inputPlaceholder: { fontSize: fontSizes.base, color: colors.text3 },
  uploadBtn:    { paddingVertical: 13 },
  successRow:   { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: colors.greenBg, borderWidth: 1, borderColor: colors.greenBdr, borderRadius: radii.md, padding: 14 },
  successIcon:  { fontSize: 18, color: colors.greenT },
  successText:  { fontSize: fontSizes.base, color: colors.greenT, fontWeight: fontWeights.medium },
});
