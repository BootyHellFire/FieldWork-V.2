/**
 * Create Job screen
 * Simple form: job name, address, builder name → inserts into Supabase.
 * In demo mode, just shows the form and navigates back.
 */

import React, { useState } from 'react';
import {
  View, Text, TextInput, ScrollView,
  StyleSheet, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/ui/Header';
import { Btn } from '@/components/ui/Btn';
import { Separator } from '@/components/ui/shared';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

export default function CreateJobScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const [name,    setName]    = useState('');
  const [address, setAddress] = useState('');
  const [builder, setBuilder] = useState('');
  const [saving,  setSaving]  = useState(false);

  async function handleCreate() {
    if (!name.trim()) {
      Alert.alert('Required', 'Please enter a job name.');
      return;
    }

    setSaving(true);
    try {
      if (IS_DEMO || !user || user.id.startsWith('demo-')) {
        // Demo mode — just navigate back
        await new Promise(r => setTimeout(r, 400));
        Alert.alert('Demo mode', 'Job creation is wired to Supabase in production. Navigate back to see the jobs list.');
        router.back();
        return;
      }

      // 1. Upsert builder by name (simple approach for V1)
      let builderId: number | null = null;
      if (builder.trim()) {
        const { data: bData } = await supabase
          .from('builders')
          .upsert({ name: builder.trim() }, { onConflict: 'name' })
          .select('id')
          .single();
        builderId = bData?.id ?? null;
      }

      // 2. Create job
      const { data: job, error: jobErr } = await supabase
        .from('jobs')
        .insert({
          name:       name.trim(),
          address:    address.trim() || null,
          builder_id: builderId,
          status:     'upcoming',
        })
        .select('id')
        .single();

      if (jobErr) throw jobErr;

      // 3. Add current user as boss member
      await supabase.from('job_members').insert({
        job_id:  job.id,
        user_id: user.id,
        role:    'boss',
      });

      router.replace(`/(boss)/jobs/${job.id}`);
    } catch (err: any) {
      Alert.alert('Failed to create job', err.message ?? 'Unknown error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.root, { paddingBottom: insets.bottom }]}>
        <Header title="New Job" onBack={() => router.back()} />

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.inner}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {IS_DEMO && (
            <View style={styles.demoNote}>
              <Text style={styles.demoNoteText}>
                Demo mode — form is functional but saves to Supabase only in production.
              </Text>
            </View>
          )}

          <Field label="Job name *" value={name} onChangeText={setName} placeholder="Meridian Ridge Estate" autoFocus />
          <Field label="Address"    value={address} onChangeText={setAddress} placeholder="4821 Meadow View Ln, Eagle, ID" />
          <Field label="Builder / GC" value={builder} onChangeText={setBuilder} placeholder="Summit Custom Homes" />

          <Separator />

          <Btn
            label={saving ? 'Creating...' : 'Create Job'}
            variant="primary"
            fullWidth
            onPress={handleCreate}
            loading={saving}
            disabled={!name.trim() || saving}
            style={styles.createBtn}
          />
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

function Field({
  label, value, onChangeText, placeholder, autoFocus,
}: {
  label: string; value: string; onChangeText: (v: string) => void;
  placeholder?: string; autoFocus?: boolean;
}) {
  return (
    <View style={fStyles.wrap}>
      <Text style={fStyles.label}>{label.toUpperCase()}</Text>
      <TextInput
        style={fStyles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.text3}
        autoFocus={autoFocus}
        autoCapitalize="words"
        returnKeyType="next"
      />
    </View>
  );
}

const fStyles = StyleSheet.create({
  wrap:  { marginBottom: spacing.md },
  label: { fontSize: fontSizes.xs, color: colors.text3, fontWeight: fontWeights.medium, letterSpacing: 0.6, marginBottom: 6 },
  input: { backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border2, borderRadius: radii.md, padding: 11, fontSize: fontSizes.base, color: colors.text1 },
});

const styles = StyleSheet.create({
  root:      { flex: 1, backgroundColor: colors.bg1 },
  scroll:    { flex: 1 },
  inner:     { padding: spacing.lg, paddingBottom: 40 },
  demoNote:  { backgroundColor: colors.amberBg, borderWidth: 1, borderColor: colors.amberBdr, borderRadius: radii.md, padding: 10, marginBottom: 20 },
  demoNoteText: { fontSize: fontSizes.xs, color: colors.amberT, lineHeight: 17 },
  createBtn: { marginTop: spacing.sm, paddingVertical: 14 },
});
