/**
 * Room List Screen
 *
 * Shows all rooms for a job. Boss can:
 *   - See task count per room
 *   - Tap "Add Room" to create a new one
 *   - Long-press to delete (V2 stub)
 *
 * Reached from Job Detail → a future "Manage Rooms" button.
 * Route: /(boss)/jobs/rooms?jobId=1
 */

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, StyleSheet, Alert, RefreshControl, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useJob } from '@/hooks/useJob';
import { createRoom } from '@/services/database';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/ui/Header';
import { Btn } from '@/components/ui/Btn';
import { Badge } from '@/components/ui/Badge';
import { LoadingState, EmptyState, ErrorBanner } from '@/components/ui/feedback';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

const FLOOR_OPTIONS = ['Main', 'Upper', 'Lower', 'Basement', 'Attic', 'Garage'];

export default function RoomListScreen() {
  const { jobId }  = useLocalSearchParams<{ jobId: string }>();
  const router     = useRouter();
  const insets     = useSafeAreaInsets();
  const { user }   = useAuth();

  const { job, rooms, loading, error, refresh } = useJob(Number(jobId));

  const [showForm,   setShowForm]   = useState(false);
  const [roomName,   setRoomName]   = useState('');
  const [floorName,  setFloorName]  = useState('Main');
  const [saving,     setSaving]     = useState(false);

  // Local demo rooms state so additions appear immediately in demo mode
  const [demoRooms, setDemoRooms] = useState(rooms);
  // Keep demo rooms in sync when rooms prop changes
  React.useEffect(() => { setDemoRooms(rooms); }, [rooms.length]);

  const displayRooms = IS_DEMO ? demoRooms : rooms;

  async function handleAdd() {
    if (!roomName.trim()) return;
    setSaving(true);
    try {
      if (IS_DEMO || !user || user.id.startsWith('demo-')) {
        // Demo: optimistic add
        const newRoom = {
          id:        Date.now(),
          jobId:     Number(jobId),
          name:      roomName.trim(),
          floor:     floorName,
          taskCount: 0,
        };
        setDemoRooms(prev => [...prev, newRoom]);
      } else {
        await createRoom(Number(jobId), roomName.trim(), floorName);
        await refresh();
      }
      setRoomName('');
      setShowForm(false);
    } catch (err: any) {
      Alert.alert('Failed to create room', err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <LoadingState message="Loading rooms..." />;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.root, { paddingBottom: insets.bottom }]}>
        <Header
          title={job ? `Rooms — ${job.name}` : 'Rooms'}
          onBack={() => router.back()}
          right={
            <TouchableOpacity
              style={styles.addBtn}
              onPress={() => setShowForm(v => !v)}
              activeOpacity={0.7}
            >
              <Text style={styles.addBtnText}>{showForm ? 'Cancel' : '+ Add'}</Text>
            </TouchableOpacity>
          }
        />

        {error && <ErrorBanner message={error} onDismiss={() => {}} />}

        {/* Add room form */}
        {showForm && (
          <View style={styles.form}>
            <TextInput
              style={styles.nameInput}
              placeholder="Room name (e.g. Master Bath)"
              placeholderTextColor={colors.text3}
              value={roomName}
              onChangeText={setRoomName}
              autoFocus
              returnKeyType="done"
              onSubmitEditing={handleAdd}
            />
            {/* Floor picker */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.floorRow}
            >
              {FLOOR_OPTIONS.map(floor => (
                <TouchableOpacity
                  key={floor}
                  style={[styles.floorChip, floorName === floor && styles.floorChipActive]}
                  onPress={() => setFloorName(floor)}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.floorChipText, floorName === floor && styles.floorChipTextActive]}>
                    {floor}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <Btn
              label={saving ? 'Adding...' : 'Add Room'}
              variant="primary"
              fullWidth
              onPress={handleAdd}
              loading={saving}
              disabled={!roomName.trim() || saving}
            />
          </View>
        )}

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.inner}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.amber} />
          }
        >
          {displayRooms.length === 0 ? (
            <EmptyState
              icon="🏠"
              title="No rooms yet"
              subtitle="Tap '+ Add' to create your first room, or they'll be generated automatically during a walkthrough."
            />
          ) : (
            displayRooms.map(room => (
              <View key={room.id} style={styles.roomRow}>
                <View style={styles.roomLeft}>
                  <Text style={styles.roomName}>{room.name}</Text>
                  <Text style={styles.roomFloor}>{room.floor} floor</Text>
                </View>
                {room.taskCount > 0 ? (
                  <Badge label={`${room.taskCount} tasks`} variant="amber" />
                ) : (
                  <Text style={styles.noTasks}>No tasks</Text>
                )}
              </View>
            ))
          )}
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root:         { flex: 1, backgroundColor: colors.bg1 },
  addBtn:       { paddingHorizontal: 12, paddingVertical: 6, borderRadius: radii.md, borderWidth: 1, borderColor: colors.border2 },
  addBtnText:   { fontSize: fontSizes.sm, color: colors.text2 },
  form:         { padding: spacing.lg, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.bg2, gap: 10 },
  nameInput:    { backgroundColor: colors.bg1, borderWidth: 1, borderColor: colors.border2, borderRadius: radii.md, padding: 11, fontSize: fontSizes.base, color: colors.text1 },
  floorRow:     { gap: 8, paddingBottom: 2 },
  floorChip:    { paddingHorizontal: 13, paddingVertical: 6, borderRadius: radii.full, borderWidth: 1, borderColor: colors.border, backgroundColor: 'transparent' },
  floorChipActive: { backgroundColor: colors.amberBg, borderColor: colors.amberBdr },
  floorChipText:   { fontSize: fontSizes.sm, color: colors.text3 },
  floorChipTextActive: { color: colors.amberT },
  scroll:       { flex: 1 },
  inner:        { padding: spacing.lg, paddingBottom: 32 },
  roomRow:      { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  roomLeft:     { flex: 1 },
  roomName:     { fontSize: fontSizes.base, fontWeight: fontWeights.medium, color: colors.text1 },
  roomFloor:    { fontSize: fontSizes.xs, color: colors.text3, marginTop: 2 },
  noTasks:      { fontSize: fontSizes.sm, color: colors.text3 },
});
