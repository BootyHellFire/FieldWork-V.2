/**
 * Boss Job Detail — M4
 * - Live data via useJob()
 * - Job status management (upcoming → active → review → complete)
 * - Pull-to-refresh
 * - All action buttons wired
 */
import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, RefreshControl, Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useJob } from '@/hooks/useJob';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/ui/Header';
import { ProgressBar, StatRow, Separator, SectionLabel } from '@/components/ui/shared';
import { Btn } from '@/components/ui/Btn';
import { Badge, BadgeVariant } from '@/components/ui/Badge';
import { LoadingState, ErrorBanner, OfflineBanner } from '@/components/ui/feedback';
import { JobStatus } from '@/types';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

const STATUS_NEXT: Record<JobStatus, { label: string; next: JobStatus } | null> = {
  upcoming: { label: 'Mark Active',   next: 'active'   },
  active:   { label: 'Mark Complete', next: 'review'   },
  review:   { label: 'Mark Complete', next: 'review'   },
};

const STATUS_BADGE: Record<JobStatus, { label: string; variant: BadgeVariant }> = {
  upcoming: { label: 'Upcoming',     variant: 'gray'  },
  active:   { label: 'Active',       variant: 'green' },
  review:   { label: 'Needs Review', variant: 'amber' },
};

export default function JobDetailScreen() {
  const { id }   = useLocalSearchParams<{ id: string }>();
  const router   = useRouter();
  const insets   = useSafeAreaInsets();
  const { user } = useAuth();
  const { job, rooms, loading, error, refresh } = useJob(Number(id));
  const [updatingStatus, setUpdatingStatus] = useState(false);

  if (loading) return <LoadingState message="Loading job..." />;
  if (!job)    return <LoadingState message="Job not found" />;

  const pct = job.tasksTotal > 0 ? job.tasksDone / job.tasksTotal : 0;
  const statusInfo = STATUS_BADGE[job.status] ?? { label: job.status, variant: 'gray' as BadgeVariant };
  const nextAction = STATUS_NEXT[job.status];

  async function handleStatusChange() {
    if (!nextAction) return;
    Alert.alert(
      nextAction.label,
      `Move this job to "${nextAction.next}" status?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: nextAction.label,
          onPress: async () => {
            setUpdatingStatus(true);
            try {
              if (!IS_DEMO && user && !user.id.startsWith('demo-')) {
                const { error: err } = await supabase
                  .from('jobs')
                  .update({ status: nextAction.next })
                  .eq('id', Number(id));
                if (err) throw err;
              }
              await refresh();
            } catch (err: any) {
              Alert.alert('Update failed', err.message);
            } finally {
              setUpdatingStatus(false);
            }
          },
        },
      ]
    );
  }

  return (
    <View style={[styles.root, { paddingBottom: insets.bottom }]}>
      <Header
        title={job.name}
        onBack={() => router.back()}
        right={<Badge label={statusInfo.label} variant={statusInfo.variant} />}
      />
      <OfflineBanner />
      {error && <ErrorBanner message={error} onDismiss={() => {}} />}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.inner}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.amber} />
        }
      >
        <Text style={styles.sub}>{job.builder}</Text>
        <Text style={styles.sub}>{job.address}</Text>
        <Separator />

        <StatRow stats={[
          { value: job.roomCount,                   label: 'Rooms'   },
          { value: job.tasksTotal - job.tasksDone,  label: 'Pending' },
          { value: `${Math.round(pct * 100)}%`,     label: 'Done'    },
        ]} />

        <ProgressBar progress={pct} />
        <Text style={styles.progressNote}>
          {job.tasksDone} of {job.tasksTotal} tasks complete
        </Text>

        {/* Primary CTA */}
        <Btn
          label="⚡  Start Walkthrough"
          variant="primary" fullWidth
          onPress={() => router.push(`/(boss)/walkthrough/${job.id}`)}
          style={styles.ctaBtn}
        />
        <Btn
          label="≡  View All Tasks"
          variant="default" fullWidth
          onPress={() => router.push('/(boss)/tasks')}
          style={styles.actionBtn}
        />
        <Btn
          label="🏠  Manage Rooms"
          variant="default" fullWidth
          onPress={() => router.push(`/(boss)/jobs/rooms?jobId=${job.id}`)}
          style={styles.actionBtn}
        />
        <Btn
          label="📐  Upload Floor Plan"
          variant="default" fullWidth
          onPress={() => router.push(`/(boss)/jobs/plans?jobId=${job.id}`)}
          style={styles.actionBtn}
        />

        {/* Job status transition */}
        {nextAction && (
          <Btn
            label={updatingStatus ? 'Updating...' : nextAction.label}
            variant="default"
            fullWidth
            loading={updatingStatus}
            onPress={handleStatusChange}
            style={[styles.actionBtn, styles.statusBtn]}
          />
        )}

        {/* Room list */}
        <SectionLabel text={`Rooms (${rooms.length})`} />
        {rooms.length === 0 ? (
          <Text style={styles.noRooms}>
            No rooms yet. Add rooms manually or they'll be created during a walkthrough.
          </Text>
        ) : (
          rooms.map(room => (
            <View key={room.id} style={styles.roomRow}>
              <View style={styles.roomInfo}>
                <Text style={styles.roomName}>{room.name}</Text>
                <Text style={styles.roomFloor}>{room.floor} floor</Text>
              </View>
              {room.taskCount > 0
                ? <Badge label={`${room.taskCount} tasks`} variant="amber" />
                : <Text style={styles.noTasks}>No tasks</Text>}
              <Text style={styles.chevron}>›</Text>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:         { flex: 1, backgroundColor: colors.bg1 },
  scroll:       { flex: 1 },
  inner:        { padding: spacing.lg, paddingBottom: 32 },
  sub:          { fontSize: fontSizes.sm, color: colors.text3, marginBottom: 2 },
  progressNote: { fontSize: fontSizes.xs, color: colors.text3, textAlign: 'right', marginBottom: spacing.xl },
  ctaBtn:       { paddingVertical: 14, marginBottom: 9 },
  actionBtn:    { marginBottom: 9 },
  statusBtn:    { borderColor: colors.border3 },
  roomRow:      { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  roomInfo:     { flex: 1 },
  roomName:     { fontSize: fontSizes.base, fontWeight: fontWeights.medium, color: colors.text1 },
  roomFloor:    { fontSize: fontSizes.xs, color: colors.text3, marginTop: 1 },
  noTasks:      { fontSize: fontSizes.sm, color: colors.text3 },
  chevron:      { fontSize: 18, color: colors.text3 },
  noRooms:      { fontSize: fontSizes.sm, color: colors.text3, textAlign: 'center', paddingVertical: 24, lineHeight: 20 },
});
