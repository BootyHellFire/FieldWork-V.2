/**
 * Review Extracted Tasks — M4
 *
 * Adds:
 *   - Push notifications to assigned workers when tasks are published
 *   - Proper error handling with ErrorBanner
 *   - Demo mode note
 */

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { WalkthroughStore }   from '@/stores/WalkthroughStore';
import { DEMO_EXTRACTED }    from '@/data/extracted';
import { insertTask }         from '@/services/database';
import { notifyTasksAssigned } from '@/services/notifications';
import { useAuth }            from '@/context/AuthContext';
import { supabase }           from '@/lib/supabase';

import { Header }             from '@/components/ui/Header';
import { Badge }              from '@/components/ui/Badge';
import { Btn }                from '@/components/ui/Btn';
import { ErrorBanner }        from '@/components/ui/feedback';
import { MeasurementDiagram } from '@/components/task/MeasurementDiagram';
import { ExtractedTask }      from '@/types';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

export default function ReviewScreen() {
  const { jobId } = useLocalSearchParams<{ jobId: string }>();
  const router    = useRouter();
  const insets    = useSafeAreaInsets();
  const { user }  = useAuth();

  const source = WalkthroughStore.getExtracted().length > 0
    ? WalkthroughStore.getExtracted()
    : DEMO_EXTRACTED;
  const [tasks,      setTasks]      = useState<ExtractedTask[]>(source.map(t => ({ ...t })));
  const [publishing, setPublishing] = useState(false);
  const [error,      setError]      = useState<string | null>(null);

  const approve   = (id: string) => setTasks(p => p.map(t => t.id === id ? { ...t, approved: true,  discarded: false } : t));
  const unapprove = (id: string) => setTasks(p => p.map(t => t.id === id ? { ...t, approved: false              } : t));
  const discard   = (id: string) => setTasks(p => p.map(t => t.id === id ? { ...t, discarded: true, approved: false } : t));

  const alive     = tasks.filter(t => !t.discarded);
  const nApproved = alive.filter(t => t.approved).length;

  async function handlePublish() {
    const toPublish = tasks.filter(t => t.approved && !t.discarded);
    if (!toPublish.length) return;

    setPublishing(true);
    setError(null);

    try {
      if (!IS_DEMO && user && !user.id.startsWith('demo-')) {
        // Insert tasks
        const inserted = await Promise.all(
          toPublish.map(t =>
            insertTask({
              jobId:            Number(jobId),
              createdByUserId:  user.id,
              title:            t.title,
              description:      t.description,
              stage:            t.stage,
              priority:         t.priority,
              measurementsJson: {
                height_from_ffl_inches:        t.measurements.heightFromFFL,
                offset_from_right_wall_inches:  t.measurements.offsetFromRightWall,
              },
              transcriptSnippet: t.transcriptSnippet,
              needsReview:       false,
            })
          )
        );

        // Notify each unique assigned worker
        const assigneeGroups = new Map<string, { count: number; name: string }>();
        for (const t of toPublish) {
          if (!t.assignee || t.assignee === 'Unassigned') continue;
          const existing = assigneeGroups.get(t.assignee);
          if (existing) existing.count += 1;
          else assigneeGroups.set(t.assignee, { count: 1, name: t.assignee });
        }

        for (const [assigneeName, { count }] of assigneeGroups) {
          // Look up user ID by name
          const { data: workerRow } = await supabase
            .from('users')
            .select('id')
            .ilike('full_name', `%${assigneeName}%`)
            .maybeSingle();

          if (workerRow?.id) {
            await notifyTasksAssigned({
              workerId:   workerRow.id,
              workerName: assigneeName,
              jobName:    'Meridian Ridge Estate',
              taskCount:  count,
            });
          }
        }
      } else {
        await new Promise(r => setTimeout(r, 700));
      }

      router.replace('/(boss)/tasks');
      WalkthroughStore.clear(); // free memory, ready for next session
    } catch (err: any) {
      setError(err.message ?? 'Could not publish tasks.');
    } finally {
      setPublishing(false);
    }
  }

  const dateStr = new Date().toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });

  return (
    <View style={[styles.root, { paddingBottom: insets.bottom }]}>
      <Header
        title="Review Tasks"
        onBack={() => router.back()}
        right={<Badge label={`${alive.length} extracted`} variant="amber" />}
      />

      {error && <ErrorBanner message={error} onDismiss={() => setError(null)} />}

      <ScrollView style={styles.scroll} contentContainerStyle={styles.inner} showsVerticalScrollIndicator={false}>
        <Text style={styles.meta}>
          Master Bath walkthrough · {dateStr}{IS_DEMO ? '  ·  demo data' : ''}
        </Text>

        {tasks.map(task =>
          task.discarded
            ? <DiscardedRow key={task.id} title={task.title} />
            : <TaskCard key={task.id} task={task} onApprove={() => approve(task.id)} onUnapprove={() => unapprove(task.id)} onDiscard={() => discard(task.id)} />
        )}

        {nApproved > 0 && (
          <View style={styles.publishWrap}>
            {publishing ? (
              <View style={styles.publishingRow}>
                <ActivityIndicator color={colors.amber} size="small" />
                <Text style={styles.publishingText}>Publishing and notifying workers...</Text>
              </View>
            ) : (
              <Btn
                label={`Publish ${nApproved} Task${nApproved > 1 ? 's' : ''} to Workers`}
                variant="primary" fullWidth
                onPress={handlePublish}
                style={styles.publishBtn}
              />
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function DiscardedRow({ title }: { title: string }) {
  return (
    <View style={styles.discarded}>
      <Text style={styles.discardedText}>{title}</Text>
    </View>
  );
}

function TaskCard({ task, onApprove, onUnapprove, onDiscard }: {
  task: ExtractedTask;
  onApprove: () => void; onUnapprove: () => void; onDiscard: () => void;
}) {
  const hasDiag = !!task.measurements.heightFromFFL;
  return (
    <View style={styles.card}>
      <View style={styles.cardHead}>
        <Badge label={task.room}  variant="blue" />
        <Badge label={task.stage} variant="gray" />
        {task.priority === 'high' && <Badge label="High" variant="red" />}
        <Text style={styles.assigneeText}>→ {task.assignee}</Text>
        <Text style={styles.confText}>✓ {task.confidence}%</Text>
      </View>
      <View style={styles.cardBody}>
        <Text style={styles.cardTitle}>{task.title}</Text>
        <Text style={styles.cardDesc}>{task.description}</Text>
        <View style={styles.mono}><Text style={styles.monoText}>{task.measurements.label}</Text></View>
        {hasDiag && <View style={styles.diagWrap}><MeasurementDiagram measurements={task.measurements} /></View>}
        <View style={styles.snippet}><Text style={styles.snippetText}>"{task.transcriptSnippet}"</Text></View>
      </View>
      <View style={styles.cardFoot}>
        {task.approved
          ? <TouchableOpacity style={[styles.footBtn, styles.footApproved]} onPress={onUnapprove} activeOpacity={0.7}><Text style={styles.footApprovedText}>✓ Approved</Text></TouchableOpacity>
          : <TouchableOpacity style={[styles.footBtn, styles.footPrimary]}  onPress={onApprove}   activeOpacity={0.7}><Text style={styles.footPrimaryText}>Approve</Text></TouchableOpacity>
        }
        <TouchableOpacity style={[styles.footBtn, styles.footDanger]} onPress={onDiscard} activeOpacity={0.7}>
          <Text style={styles.footDangerText}>Discard</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root:            { flex: 1, backgroundColor: colors.bg1 },
  scroll:          { flex: 1 },
  inner:           { padding: spacing.lg, paddingBottom: 40 },
  meta:            { fontSize: fontSizes.sm, color: colors.text3, marginBottom: 14 },
  discarded:       { opacity: 0.3, padding: 10, borderWidth: 1, borderColor: colors.border, borderRadius: radii.md, marginBottom: 8 },
  discardedText:   { fontSize: fontSizes.sm, color: colors.text2, textDecorationLine: 'line-through' },
  card:            { backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, overflow: 'hidden', marginBottom: 12 },
  cardHead:        { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 7, padding: 10, paddingHorizontal: 13, backgroundColor: colors.bg3, borderBottomWidth: 1, borderBottomColor: colors.border },
  assigneeText:    { fontSize: fontSizes.sm,  color: colors.text3 },
  confText:        { fontSize: fontSizes.xs, color: colors.text3, marginLeft: 'auto' },
  cardBody:        { padding: 13, gap: 9 },
  cardTitle:       { fontSize: fontSizes.base, fontWeight: fontWeights.medium, color: colors.text1 },
  cardDesc:        { fontSize: fontSizes.sm, color: colors.text2, lineHeight: 18 },
  mono:            { backgroundColor: colors.bg0, borderWidth: 1, borderColor: colors.border, borderRadius: radii.sm, padding: 9 },
  monoText:        { fontFamily: 'Courier New', fontSize: fontSizes.sm, color: colors.amberT, lineHeight: 18 },
  diagWrap:        { marginTop: 2 },
  snippet:         { borderLeftWidth: 2.5, borderLeftColor: colors.amber, paddingHorizontal: 10, paddingVertical: 8, backgroundColor: colors.bg3 },
  snippetText:     { fontSize: fontSizes.xs, color: colors.text2, fontStyle: 'italic', lineHeight: 17 },
  cardFoot:        { flexDirection: 'row', gap: 7, padding: 9, paddingHorizontal: 13, borderTopWidth: 1, borderTopColor: colors.border },
  footBtn:         { flex: 1, paddingVertical: 9, borderRadius: radii.md, borderWidth: 1, alignItems: 'center' },
  footPrimary:     { backgroundColor: colors.amber, borderColor: colors.amberD },
  footPrimaryText: { fontSize: fontSizes.sm, fontWeight: fontWeights.medium, color: '#0D0800' },
  footApproved:    { backgroundColor: colors.greenBg, borderColor: colors.greenBdr },
  footApprovedText:{ fontSize: fontSizes.sm, fontWeight: fontWeights.medium, color: colors.greenT },
  footDanger:      { backgroundColor: colors.redBg, borderColor: colors.redBdr },
  footDangerText:  { fontSize: fontSizes.sm, fontWeight: fontWeights.medium, color: colors.redT },
  publishWrap:     { marginTop: 6 },
  publishBtn:      { paddingVertical: 13 },
  publishingRow:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 14, backgroundColor: colors.bg3, borderRadius: radii.md, borderWidth: 1, borderColor: colors.border2 },
  publishingText:  { fontSize: fontSizes.base, color: colors.text2 },
});
