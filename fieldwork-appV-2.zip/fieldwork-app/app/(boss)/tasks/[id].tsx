import { TaskDetailScreen } from '@/components/task/TaskDetailScreen';

// Boss version — back button returns to boss task list
export default function BossTaskDetail() {
  return <TaskDetailScreen role="boss" />;
}
