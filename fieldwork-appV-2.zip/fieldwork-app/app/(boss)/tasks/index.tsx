/**
 * Boss Tasks Screen — M3
 * Wired to useRealtimeTasks(). Pull-to-refresh. Live status badges.
 */
import React, { useState } from 'react';
import {
  View, ScrollView, StyleSheet, RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRealtimeTasks } from '@/hooks/useRealtimeTasks';
import { Header } from '@/components/ui/Header';
import { StatRow, TabFilter } from '@/components/ui/shared';
import { TaskItem } from '@/components/task/TaskItem';
import { BottomNav, BOSS_NAV } from '@/components/ui/BottomNav';
import { LoadingState, EmptyState, ErrorBanner, OfflineBanner } from '@/components/ui/feedback';
import { colors, spacing } from '@/constants/tokens';

const TABS = [
  { key: 'all',     label: 'All'         },
  { key: 'pending', label: 'Pending'     },
  { key: 'inprog',  label: 'In Progress' },
  { key: 'done',    label: 'Done'        },
];

// Job ID 1 hardcoded for now — in production this comes from a job context/param
const CURRENT_JOB_ID = 1;

export default function BossTasksScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState('all');
  const [nav, setNav] = useState('tasks');

  const { tasks, loading, error, refresh } = useRealtimeTasks(CURRENT_JOB_ID);

  const shown = tasks.filter(t => {
    if (tab === 'pending') return t.status === 'pending';
    if (tab === 'inprog')  return t.status === 'in_progress';
    if (tab === 'done')    return t.status === 'done';
    return true;
  });

  function handleNav(key: string) {
    setNav(key);
    if (key === 'jobs')     router.push('/(boss)/jobs');
    if (key === 'settings') router.push('/settings');
  }

  if (loading) return <LoadingState message="Loading tasks..." />;

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <Header title="All Tasks · Meridian Ridge" onBack={() => router.push('/(boss)/jobs/1')} />
      <OfflineBanner />
      {error && <ErrorBanner message={error} onDismiss={() => {}} />}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.inner}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.amber} />
        }
      >
        <StatRow stats={[
          { value: tasks.filter(t => t.status === 'in_progress').length, label: 'In Progress' },
          { value: tasks.filter(t => t.status === 'pending').length,     label: 'Pending'     },
          { value: tasks.filter(t => t.status === 'done').length,        label: 'Done'        },
        ]} />

        <TabFilter tabs={TABS} activeKey={tab} onPress={setTab} />

        {shown.length === 0 ? (
          <EmptyState
            icon="✓"
            title="No tasks here"
            subtitle="Complete a walkthrough to generate tasks."
          />
        ) : (
          shown.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              showAssignee
              onPress={() => router.push(`/(boss)/tasks/${task.id}`)}
            />
          ))
        )}
      </ScrollView>

      <BottomNav items={BOSS_NAV} activeKey={nav} onPress={handleNav} />
    </View>
  );
}

const styles = StyleSheet.create({
  root:  { flex: 1, backgroundColor: colors.bg0 },
  scroll: { flex: 1 },
  inner:  { padding: spacing.lg, paddingBottom: 24 },
});
