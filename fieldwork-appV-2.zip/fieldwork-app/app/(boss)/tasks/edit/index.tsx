/**
 * Task Edit Screen
 *
 * Boss can correct AI extraction mistakes before or after publishing:
 *   - Title
 *   - Description
 *   - Assignee (pick from job members)
 *   - Stage (rough / trim / finish / punch)
 *   - Priority (normal / high)
 *   - Measurements label (free-text override; diagram updates live)
 *   - Height from FFL
 *   - Offset from right wall
 *
 * Route: /(boss)/tasks/edit?id=<taskId>
 * On save → navigates back to task detail.
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity,
  StyleSheet, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTask } from '@/hooks/useTask';
import { updateTask } from '@/services/databaseExtras';
import { useAuth } from '@/context/AuthContext';
import { MeasurementDiagram } from '@/components/task/MeasurementDiagram';
import { Header } from '@/components/ui/Header';
import { Btn } from '@/components/ui/Btn';
import { LoadingState } from '@/components/ui/feedback';
import { Separator } from '@/components/ui/shared';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';
import { TaskStage, TaskPriority } from '@/types';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;

const STAGES: TaskStage[]      = ['rough', 'trim', 'finish', 'punch'];
const PRIORITIES: TaskPriority[] = ['normal', 'high'];
const ASSIGNEES                = ['Jake', 'Carson', 'Unassigned'];

export default function TaskEditScreen() {
  const { id }    = useLocalSearchParams<{ id: string }>();
  const router    = useRouter();
  const insets    = useSafeAreaInsets();
  const { user }  = useAuth();

  const { task, loading } = useTask(Number(id));

  // Form state — initialised from live task data
  const [title,       setTitle]       = useState('');
  const [description, setDescription] = useState('');
  const [assignee,    setAssignee]    = useState('');
  const [stage,       setStage]       = useState<TaskStage>('rough');
  const [priority,    setPriority]    = useState<TaskPriority>('normal');
  const [heightFFL,   setHeightFFL]   = useState('');
  const [offsetRight, setOffsetRight] = useState('');
  const [saving,      setSaving]      = useState(false);

  // Populate form fields once task data arrives
  useEffect(() => {
    if (!task) return;
    setTitle(task.title);
    setDescription(task.description);
    setAssignee(task.assignee);
    setStage(task.stage);
    setPriority(task.priority);
    setHeightFFL(task.measurements.heightFromFFL?.toString() ?? '');
    setOffsetRight(task.measurements.offsetFromRightWall?.toString() ?? '');
  }, [task]);

  if (loading || !task) return <LoadingState message="Loading task..." />;

  // Live preview measurements for the diagram
  const previewMeasurements = {
    heightFromFFL:       heightFFL ? parseFloat(heightFFL) : undefined,
    offsetFromRightWall: offsetRight ? parseFloat(offsetRight) : undefined,
    label: [
      heightFFL       ? `${heightFFL}" from FFL` : null,
      offsetRight     ? `${offsetRight}" from right wall` : null,
    ].filter(Boolean).join('  ·  ') || 'No measurements',
  };

  async function handleSave() {
    if (!title.trim()) {
      Alert.alert('Required', 'Task title cannot be empty.');
      return;
    }

    setSaving(true);
    try {
      const patch = {
        title:       title.trim(),
        description: description.trim(),
        stage,
        priority,
        assigned_to_user_id: assignee === 'Unassigned' ? undefined : undefined, // ID lookup needed in production
        measurements_json: {
          height_from_ffl_inches:        heightFFL       ? parseFloat(heightFFL)   : null,
          offset_from_right_wall_inches:  offsetRight    ? parseFloat(offsetRight) : null,
        },
      };

      if (!IS_DEMO && user && !user.id.startsWith('demo-')) {
        await updateTask(Number(id), patch);
      } else {
        // Demo: just simulate a save
        await new Promise(r => setTimeout(r, 400));
      }

      router.back();
    } catch (err: any) {
      Alert.alert('Save failed', err.message ?? 'Could not update task.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.root, { paddingBottom: insets.bottom }]}>
        <Header title="Edit Task" onBack={() => router.back()} />

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.inner}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {IS_DEMO && (
            <View style={styles.demoNote}>
              <Text style={styles.demoNoteText}>
                Demo mode — changes are not persisted.
              </Text>
            </View>
          )}

          {/* Title */}
          <FieldLabel text="Title" />
          <TextInput
            style={styles.input}
            value={title}
            onChangeText={setTitle}
            placeholder="Task title"
            placeholderTextColor={colors.text3}
            returnKeyType="next"
          />

          {/* Description */}
          <FieldLabel text="Description" />
          <TextInput
            style={[styles.input, styles.multiline]}
            value={description}
            onChangeText={setDescription}
            placeholder="Full task description"
            placeholderTextColor={colors.text3}
            multiline
            textAlignVertical="top"
          />

          <Separator />

          {/* Stage picker */}
          <FieldLabel text="Stage" />
          <View style={styles.chipRow}>
            {STAGES.map(s => (
              <TouchableOpacity
                key={s}
                style={[styles.chip, stage === s && styles.chipActive]}
                onPress={() => setStage(s)}
                activeOpacity={0.7}
              >
                <Text style={[styles.chipText, stage === s && styles.chipTextActive]}>
                  {s}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Priority picker */}
          <FieldLabel text="Priority" />
          <View style={styles.chipRow}>
            {PRIORITIES.map(p => (
              <TouchableOpacity
                key={p}
                style={[
                  styles.chip,
                  priority === p && styles.chipActive,
                  priority === p && p === 'high' && styles.chipHigh,
                ]}
                onPress={() => setPriority(p)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.chipText,
                  priority === p && styles.chipTextActive,
                  priority === p && p === 'high' && styles.chipTextHigh,
                ]}>
                  {p === 'high' ? '🚩 High' : 'Normal'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Assignee picker */}
          <FieldLabel text="Assignee" />
          <View style={styles.chipRow}>
            {ASSIGNEES.map(a => (
              <TouchableOpacity
                key={a}
                style={[styles.chip, assignee === a && styles.chipActive]}
                onPress={() => setAssignee(a)}
                activeOpacity={0.7}
              >
                <Text style={[styles.chipText, assignee === a && styles.chipTextActive]}>
                  {a}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Separator />

          {/* Measurements */}
          <FieldLabel text="Height from FFL (inches)" />
          <TextInput
            style={[styles.input, styles.monoInput]}
            value={heightFFL}
            onChangeText={v => setHeightFFL(v.replace(/[^0-9.]/g, ''))}
            placeholder="e.g. 52.5"
            placeholderTextColor={colors.text3}
            keyboardType="decimal-pad"
            returnKeyType="next"
          />

          <FieldLabel text="Offset from right wall (inches)" />
          <TextInput
            style={[styles.input, styles.monoInput]}
            value={offsetRight}
            onChangeText={v => setOffsetRight(v.replace(/[^0-9.]/g, ''))}
            placeholder="e.g. 27"
            placeholderTextColor={colors.text3}
            keyboardType="decimal-pad"
            returnKeyType="done"
          />

          {/* Live diagram preview */}
          {previewMeasurements.heightFromFFL && (
            <>
              <FieldLabel text="Diagram preview" />
              <MeasurementDiagram measurements={previewMeasurements} />
            </>
          )}

          <Separator />

          <Btn
            label={saving ? 'Saving...' : 'Save Changes'}
            variant="primary"
            fullWidth
            onPress={handleSave}
            loading={saving}
            disabled={!title.trim() || saving}
            style={styles.saveBtn}
          />
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

function FieldLabel({ text }: { text: string }) {
  return (
    <Text style={styles.fieldLabel}>{text.toUpperCase()}</Text>
  );
}

const styles = StyleSheet.create({
  root:           { flex: 1, backgroundColor: colors.bg1 },
  scroll:         { flex: 1 },
  inner:          { padding: spacing.lg, paddingBottom: 48 },
  demoNote:       {
    backgroundColor: colors.amberBg, borderWidth: 1,
    borderColor: colors.amberBdr, borderRadius: radii.md,
    padding: 10, marginBottom: 16,
  },
  demoNoteText:   { fontSize: fontSizes.xs, color: colors.amberT },
  fieldLabel:     {
    fontSize: fontSizes.xs, color: colors.text3,
    fontWeight: fontWeights.medium, letterSpacing: 0.6,
    marginBottom: 6, marginTop: 14,
  },
  input:          {
    backgroundColor: colors.bg2, borderWidth: 1,
    borderColor: colors.border2, borderRadius: radii.md,
    padding: 11, fontSize: fontSizes.base, color: colors.text1,
  },
  multiline:      { minHeight: 88, textAlignVertical: 'top' },
  monoInput:      { fontFamily: 'Courier New', color: colors.amberT },
  chipRow:        { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 4 },
  chip:           {
    paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: radii.full, borderWidth: 1,
    borderColor: colors.border, backgroundColor: 'transparent',
  },
  chipActive:     { backgroundColor: colors.amberBg, borderColor: colors.amberBdr },
  chipHigh:       { backgroundColor: colors.redBg, borderColor: colors.redBdr },
  chipText:       { fontSize: fontSizes.sm, color: colors.text3 },
  chipTextActive: { color: colors.amberT, fontWeight: fontWeights.medium },
  chipTextHigh:   { color: colors.redT },
  saveBtn:        { marginTop: spacing.sm, paddingVertical: 13 },
});
