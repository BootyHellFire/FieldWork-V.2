/**
 * Settings Screen — M4
 *
 * - Real Supabase sign-out
 * - Shows app version from Constants
 * - Offline queue status
 * - Demo mode indicator
 */

import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Constants from 'expo-constants';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/ui/Header';
import { Avatar } from '@/components/ui/Avatar';
import { Badge } from '@/components/ui/Badge';
import { Btn } from '@/components/ui/Btn';
import { Separator, SectionLabel } from '@/components/ui/shared';
import { pendingCount } from '@/services/offlineQueue';
import { colors, fontSizes, fontWeights, spacing } from '@/constants/tokens';

const IS_DEMO = !process.env.EXPO_PUBLIC_SUPABASE_URL;
const APP_VERSION = Constants.expoConfig?.version ?? '1.0.0';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [queueCount, setQueueCount] = useState(0);
  const [signingOut, setSigningOut] = useState(false);

  const backRoute = user?.role === 'boss' ? '/(boss)/jobs' : '/(worker)/tasks';

  useEffect(() => {
    pendingCount().then(setQueueCount);
  }, []);

  async function handleSignOut() {
    if (queueCount > 0) {
      Alert.alert(
        'Pending uploads',
        `You have ${queueCount} item${queueCount > 1 ? 's' : ''} queued for upload. Sign out anyway?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Sign Out', style: 'destructive', onPress: doSignOut },
        ]
      );
    } else {
      doSignOut();
    }
  }

  async function doSignOut() {
    setSigningOut(true);
    try {
      await signOut();
      router.replace('/(auth)/sign-in');
    } catch (err: any) {
      Alert.alert('Sign out failed', err.message);
    } finally {
      setSigningOut(false);
    }
  }

  if (!user) return null;

  const isBoss = user.role === 'boss';

  return (
    <View style={[styles.root, { paddingBottom: insets.bottom }]}>
      <Header title="Settings" onBack={() => router.push(backRoute as any)} />

      <ScrollView style={styles.scroll} contentContainerStyle={styles.inner} showsVerticalScrollIndicator={false}>
        {/* Profile */}
        <View style={styles.profile}>
          <Avatar initials={user.initials} role={user.role} size={64} />
          <Text style={styles.name}>{user.name}</Text>
          <Text style={styles.sub}>
            {isBoss ? "Foreman · Master's License" : 'Journeyman Electrician · Licensed'}
          </Text>
          <Badge
            label={isBoss ? 'Foreman' : 'Worker'}
            variant={isBoss ? 'amber' : 'blue'}
            style={styles.roleBadge}
          />
          {IS_DEMO && (
            <Badge label="Demo mode" variant="gray" style={{ marginTop: 6 }} />
          )}
        </View>

        <Separator />

        <SectionLabel text="Current job" topSpacing={false} />
        <Text style={styles.value}>Meridian Ridge Estate · Eagle, ID</Text>

        <Separator />

        <SectionLabel text="Offline queue" topSpacing={false} />
        <Text style={styles.value}>
          {queueCount > 0
            ? `${queueCount} item${queueCount > 1 ? 's' : ''} pending upload`
            : 'All synced ✓'}
        </Text>

        <Separator />

        <SectionLabel text="App" topSpacing={false} />
        <Text style={styles.value}>
          Fieldwork v{APP_VERSION} · Milestone 4{IS_DEMO ? ' · Demo build' : ''}
        </Text>

        <Separator />

        <SectionLabel text="Backend" topSpacing={false} />
        <Text style={styles.value}>
          {IS_DEMO
            ? 'Demo mode — Supabase not configured'
            : `Supabase · ${process.env.EXPO_PUBLIC_SUPABASE_URL?.replace('https://', '').split('.')[0]}.supabase.co`}
        </Text>

        <View style={styles.bottomActions}>
          <Btn
            label={signingOut ? 'Signing out...' : 'Sign Out'}
            variant="danger"
            fullWidth
            onPress={handleSignOut}
            loading={signingOut}
            style={styles.signOutBtn}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:          { flex: 1, backgroundColor: colors.bg1 },
  scroll:        { flex: 1 },
  inner:         { padding: spacing.lg, paddingBottom: 48 },
  profile:       { alignItems: 'center', paddingVertical: spacing.xl, gap: 6 },
  name:          { fontSize: fontSizes.xl, fontWeight: fontWeights.medium, color: colors.text1, marginTop: 8 },
  sub:           { fontSize: fontSizes.sm, color: colors.text3 },
  roleBadge:     { marginTop: 6 },
  value:         { fontSize: fontSizes.base, color: colors.text2, lineHeight: 20 },
  bottomActions: { marginTop: spacing.xxl },
  signOutBtn:    { paddingVertical: 13 },
});
