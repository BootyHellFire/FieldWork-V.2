/**
 * Auth Callback Screen
 *
 * Handles the deep link that fires when a user taps the magic link
 * in their email. The URL looks like:
 *   fieldwork://auth/callback#access_token=...&refresh_token=...
 *
 * Expo Router maps this to app/(auth)/callback.tsx.
 * Supabase auto-detects the hash params from the URL and sets the session.
 * We just wait for the auth state change and redirect.
 */

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { colors, fontSizes } from '@/constants/tokens';

export default function AuthCallbackScreen() {
  const { user, loading } = useAuth();
  const router            = useRouter();
  const [message, setMessage] = useState('Signing you in...');

  useEffect(() => {
    if (loading) return;

    if (user) {
      setMessage(`Welcome, ${user.name.split(' ')[0]}!`);
      // Small delay so the welcome message is readable
      const t = setTimeout(() => {
        if (user.role === 'boss') {
          router.replace('/(boss)/jobs');
        } else {
          router.replace('/(worker)/tasks');
        }
      }, 800);
      return () => clearTimeout(t);
    } else {
      // Session didn't resolve — send back to sign-in
      setMessage('Session not found. Redirecting...');
      const t = setTimeout(() => router.replace('/(auth)/sign-in'), 1500);
      return () => clearTimeout(t);
    }
  }, [user, loading]);

  return (
    <View style={styles.root}>
      <Text style={styles.bolt}>⚡</Text>
      <Text style={styles.message}>{message}</Text>
      {loading && (
        <Text style={styles.sub}>Setting up your session...</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root:    { flex: 1, backgroundColor: colors.bg0, alignItems: 'center', justifyContent: 'center', gap: 14 },
  bolt:    { fontSize: 44 },
  message: { fontSize: fontSizes.lg, color: colors.text1 },
  sub:     { fontSize: fontSizes.sm, color: colors.text3 },
});
