import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { UserRole } from '@/types';
import { Btn } from '@/components/ui/Btn';
import { colors, fontSizes, fontWeights, radii, spacing } from '@/constants/tokens';

export default function SignInScreen() {
  const { sendMagicLink, signInDemo } = useAuth();
  const insets = useSafeAreaInsets();

  const [email,    setEmail]    = useState('');
  const [loading,  setLoading]  = useState(false);
  const [sent,     setSent]     = useState(false);
  const [showDemo, setShowDemo] = useState(false);

  async function handleMagicLink() {
    if (!email.trim()) return;
    setLoading(true);
    try {
      await sendMagicLink(email.trim().toLowerCase());
      setSent(true);
    } catch (err: any) {
      Alert.alert('Sign-in failed', err.message ?? 'Could not send magic link.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={[styles.root, { paddingTop: insets.top + 32, paddingBottom: insets.bottom + 24 }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Logo */}
        <View style={styles.logoRow}>
          <Text style={styles.bolt}>⚡</Text>
          <Text style={styles.wordmark}>Fieldwork</Text>
        </View>
        <Text style={styles.tagline}>Electrical walkthroughs → clean work orders</Text>

        {/* Magic link form */}
        {!sent ? (
          <View style={styles.form}>
            <Text style={styles.formLabel}>SIGN IN WITH EMAIL</Text>
            <TextInput
              style={styles.input}
              placeholder="your@email.com"
              placeholderTextColor={colors.text3}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              value={email}
              onChangeText={setEmail}
              onSubmitEditing={handleMagicLink}
              returnKeyType="send"
            />
            <Btn
              label={loading ? 'Sending...' : 'Send magic link'}
              variant="primary"
              fullWidth
              onPress={handleMagicLink}
              disabled={!email.trim() || loading}
              loading={loading}
              style={styles.submitBtn}
            />
          </View>
        ) : (
          <View style={styles.sentBox}>
            <Text style={styles.sentIcon}>✉️</Text>
            <Text style={styles.sentTitle}>Check your email</Text>
            <Text style={styles.sentBody}>
              We sent a sign-in link to{'\n'}
              <Text style={{ color: colors.amber }}>{email}</Text>
            </Text>
            <TouchableOpacity onPress={() => setSent(false)}>
              <Text style={styles.retryLink}>Use a different email</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Demo toggle */}
        <TouchableOpacity style={styles.demoToggle} onPress={() => setShowDemo(v => !v)} activeOpacity={0.7}>
          <Text style={styles.demoToggleText}>{showDemo ? 'Hide demo options ↑' : 'Demo / TestFlight build ↓'}</Text>
        </TouchableOpacity>

        {showDemo && (
          <View style={styles.demoSection}>
            <Text style={styles.demoLabel}>SIGN IN AS DEMO USER</Text>
            {(['boss', 'worker'] as UserRole[]).map(role => (
              <TouchableOpacity key={role} style={styles.demoCard} onPress={() => signInDemo(role)} activeOpacity={0.75}>
                <View style={[styles.av, { backgroundColor: role === 'boss' ? colors.amberBg : colors.blueBg, borderColor: role === 'boss' ? colors.amberBdr : colors.blueBdr }]}>
                  <Text style={[styles.avText, { color: role === 'boss' ? colors.amberT : colors.blueT }]}>{role === 'boss' ? 'MT' : 'JR'}</Text>
                </View>
                <View style={styles.cardBody}>
                  <Text style={styles.cardName}>{role === 'boss' ? 'Mike Torres' : 'Jake Ruiz'}</Text>
                  <Text style={styles.cardSub}>{role === 'boss' ? 'Foreman · Boss view' : 'Journeyman · Worker view'}</Text>
                </View>
                <View style={[styles.badge, { backgroundColor: role === 'boss' ? colors.amberBg : colors.blueBg, borderColor: role === 'boss' ? colors.amberBdr : colors.blueBdr }]}>
                  <Text style={[styles.badgeText, { color: role === 'boss' ? colors.amberT : colors.blueT }]}>{role === 'boss' ? 'Foreman' : 'Worker'}</Text>
                </View>
              </TouchableOpacity>
            ))}
            <Text style={styles.demoNote}>Demo mode — no Supabase required</Text>
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flexGrow: 1, backgroundColor: colors.bg0, alignItems: 'center', paddingHorizontal: spacing.xl },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  bolt: { fontSize: 30 },
  wordmark: { fontSize: 28, fontWeight: fontWeights.semibold, color: colors.text1, letterSpacing: -0.5 },
  tagline: { fontSize: fontSizes.sm, color: colors.text3, marginBottom: 40, letterSpacing: 0.2 },
  form: { width: '100%', marginBottom: 24 },
  formLabel: { fontSize: fontSizes.xs, color: colors.text3, letterSpacing: 0.7, marginBottom: 8 },
  input: { width: '100%', backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border2, borderRadius: radii.md, padding: 12, fontSize: fontSizes.md, color: colors.text1, marginBottom: 10 },
  submitBtn: { paddingVertical: 13 },
  sentBox: { width: '100%', alignItems: 'center', backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 28, marginBottom: 24, gap: 8 },
  sentIcon: { fontSize: 36, marginBottom: 4 },
  sentTitle: { fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.text1 },
  sentBody: { fontSize: fontSizes.sm, color: colors.text2, textAlign: 'center', lineHeight: 20 },
  retryLink: { fontSize: fontSizes.sm, color: colors.amberT, marginTop: 8 },
  demoToggle: { marginBottom: 16 },
  demoToggleText: { fontSize: fontSizes.sm, color: colors.text3 },
  demoSection: { width: '100%' },
  demoLabel: { fontSize: fontSizes.xs, color: colors.text3, letterSpacing: 0.7, marginBottom: 10 },
  demoCard: { width: '100%', flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bg2, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 14, marginBottom: 9 },
  av: { width: 42, height: 42, borderRadius: 21, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  avText: { fontSize: 15, fontWeight: fontWeights.semibold },
  cardBody: { flex: 1 },
  cardName: { fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.text1 },
  cardSub: { fontSize: fontSizes.sm, color: colors.text3, marginTop: 1 },
  badge: { borderRadius: radii.full, borderWidth: 1, paddingHorizontal: 9, paddingVertical: 3 },
  badgeText: { fontSize: fontSizes.xs, fontWeight: fontWeights.medium },
  demoNote: { fontSize: fontSizes.xs, color: colors.text3, textAlign: 'center', marginTop: 4 },
});
