import { TaskDetailScreen } from '@/components/task/TaskDetailScreen';

// Worker version — back button returns to worker task list
export default function WorkerTaskDetail() {
  return <TaskDetailScreen role="worker" />;
}
