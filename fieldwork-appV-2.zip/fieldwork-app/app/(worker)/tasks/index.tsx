/**
 * Worker Tasks Dashboard — M3
 * Wired to useMyRealtimeTasks() — only shows tasks assigned to the current user.
 */
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useMyRealtimeTasks } from '@/hooks/useRealtimeTasks';
import { useNotifications } from '@/hooks/useNotifications';
import { Avatar } from '@/components/ui/Avatar';
import { StatRow, TabFilter } from '@/components/ui/shared';
import { TaskItem } from '@/components/task/TaskItem';
import { BottomNav, WORKER_NAV } from '@/components/ui/BottomNav';
import { LoadingState, EmptyState, ErrorBanner, OfflineBanner } from '@/components/ui/feedback';
import { colors, fontSizes, fontWeights, spacing } from '@/constants/tokens';

const TABS = [
  { key: 'all',     label: 'All'     },
  { key: 'inprog',  label: 'Active'  },
  { key: 'pending', label: 'Pending' },
  { key: 'done',    label: 'Done'    },
];

export default function WorkerTasksScreen() {
  const { user }  = useAuth();
  const router    = useRouter();
  const insets    = useSafeAreaInsets();
  const [tab, setTab] = useState('all');
  const [nav, setNav] = useState('tasks');

  // Real-time tasks for this worker. Falls back to demo data when userId is demo.
  const { tasks, loading, error, refresh } = useMyRealtimeTasks(user?.id ?? 'demo-worker');
  const { unreadCount } = useNotifications();

  const shown = tasks.filter(t => {
    if (tab === 'inprog')  return t.status === 'in_progress';
    if (tab === 'pending') return t.status === 'pending';
    if (tab === 'done')    return t.status === 'done';
    return true;
  });

  function handleNav(key: string) {
    setNav(key);
    if (key === 'settings') router.push('/settings');
  }

  if (loading) return <LoadingState message="Loading your tasks..." />;

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.hdr}>
        <View style={styles.hdrLeft}>
          <Text style={styles.greeting}>Hi, {user?.name.split(' ')[0]}</Text>
          <Text style={styles.jobName}>Meridian Ridge Estate</Text>
        </View>
        <View style={styles.hdrRight}>
          {unreadCount > 0 && (
            <View style={styles.notifBadge}>
              <Text style={styles.notifCount}>{unreadCount}</Text>
            </View>
          )}
          {user && <Avatar initials={user.initials} role={user.role} size={30} />}
        </View>
      </View>

      <OfflineBanner />
      {error && <ErrorBanner message={error} onDismiss={() => {}} />}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.inner}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.amber} />
        }
      >
        <StatRow stats={[
          { value: tasks.filter(t => t.status === 'in_progress').length, label: 'Active'  },
          { value: tasks.filter(t => t.status === 'pending').length,     label: 'Pending' },
          { value: tasks.filter(t => t.status === 'done').length,        label: 'Done'    },
        ]} />

        <TabFilter tabs={TABS} activeKey={tab} onPress={setTab} />

        {shown.length === 0 ? (
          <EmptyState
            icon={tab === 'done' ? '✓' : '📋'}
            title={tab === 'all' ? 'No tasks assigned yet' : `No ${tab === 'inprog' ? 'active' : tab} tasks`}
            subtitle={tab === 'all' ? 'Your foreman will assign tasks after a walkthrough.' : undefined}
          />
        ) : (
          shown.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              showAssignee={false}
              onPress={() => router.push(`/(worker)/tasks/${task.id}`)}
            />
          ))
        )}
      </ScrollView>

      <BottomNav items={WORKER_NAV} activeKey={nav} onPress={handleNav} />
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1, backgroundColor: colors.bg0 },
  hdr:         { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.lg, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.bg1 },
  hdrLeft:     { gap: 1 },
  greeting:    { fontSize: fontSizes.md, fontWeight: fontWeights.medium, color: colors.text1 },
  jobName:     { fontSize: fontSizes.sm, color: colors.text3 },
  hdrRight:    { flexDirection: 'row', alignItems: 'center', gap: 10 },
  notifBadge:  { backgroundColor: colors.red, borderRadius: 9, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  notifCount:  { fontSize: 10, color: '#fff', fontWeight: fontWeights.semibold },
  scroll:      { flex: 1 },
  inner:       { padding: spacing.lg, paddingBottom: 24 },
});
