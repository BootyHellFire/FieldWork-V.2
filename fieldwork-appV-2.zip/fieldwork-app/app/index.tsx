import { Redirect } from 'expo-router';

// App entry — always start at sign-in in Milestone 1.
// Later this will read auth state and redirect to the correct home screen.
export default function Index() {
  return <Redirect href="/(auth)/sign-in" />;
}
