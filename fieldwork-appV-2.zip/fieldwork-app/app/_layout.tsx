/**
 * Root Layout — M4
 *
 * Adds:
 *   - ErrorBoundary wrapping the entire navigator
 *   - Deep link handler for magic link auth callback
 *   - Cleaner loading state during auth resolution
 */

import { useEffect } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { startNetworkListener } from '@/services/offlineQueue';
import { registerOfflineHandlers } from '@/services/queueHandlers';
import { colors } from '@/constants/tokens';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <StatusBar style="light" backgroundColor={colors.bg0} />
        <ErrorBoundary>
          <RootNavigator />
        </ErrorBoundary>
      </AuthProvider>
    </SafeAreaProvider>
  );
}

function RootNavigator() {
  const { user, loading } = useAuth();
  const router   = useRouter();
  const segments = useSegments();

  // Start offline queue network listener once on app launch
  useEffect(() => {
    registerOfflineHandlers();
    startNetworkListener(({ flushed, failed }) => {
      if (flushed > 0) console.log(`[Offline] Flushed ${flushed} items, ${failed} failed.`);
    });
  }, []);

  // Auth route guard
  useEffect(() => {
    if (loading) return;

    SplashScreen.hideAsync();

    const inAuthGroup   = segments[0] === '(auth)';
    const inBossGroup   = segments[0] === '(boss)';
    const inWorkerGroup = segments[0] === '(worker)';

    if (!user) {
      if (!inAuthGroup) router.replace('/(auth)/sign-in');
      return;
    }

    if (inAuthGroup) {
      router.replace(user.role === 'boss' ? '/(boss)/jobs' : '/(worker)/tasks');
      return;
    }

    // Role isolation
    if (user.role === 'worker' && inBossGroup)   router.replace('/(worker)/tasks');
    if (user.role === 'boss'   && inWorkerGroup) router.replace('/(boss)/jobs');
  }, [user, loading, segments]);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: colors.bg1 },
        animation: 'slide_from_right',
      }}
    />
  );
}
