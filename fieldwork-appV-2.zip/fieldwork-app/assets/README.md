# Fieldwork — Assets

## Required files (not in git)

Expo needs these files before building:

```
assets/
  icon.png          1024×1024 px  — App icon (iOS + Android)
  adaptive-icon.png 1024×1024 px  — Android adaptive icon foreground
  splash.png        1284×2778 px  — Splash screen (iPhone 14 Pro Max size)
  favicon.png       48×48 px      — Web favicon (optional)
```

## Quick placeholder generation

Run this from the project root to generate minimal black placeholder images
(good enough for local dev and TestFlight internal testing):

```bash
node scripts/generate-assets.js
```

## For production

Replace with real brand assets before submitting to the App Store.
The bolt icon on a dark background (`#0D0F12`) works well as the Fieldwork icon.

Recommended tools:
- Figma or Sketch for design
- https://appicon.co for generating all iOS/Android sizes from a single 1024px source
- Expo's `expo-splash-screen` CLI: `npx expo-splash-screen --background-color "#0D0F12"`
