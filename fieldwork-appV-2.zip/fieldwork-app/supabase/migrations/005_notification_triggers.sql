-- ============================================================
-- Fieldwork V1 — Migration 005
-- DB-level notification trigger
--
-- Fires the "send-notification" Edge Function automatically when:
--   1. A task status changes to 'done'   → notify job bosses
--   2. A task is inserted (new task)     → notify assigned worker
--
-- This runs server-side so notifications fire even if the app
-- crashes or goes offline immediately after a status change.
--
-- Requires: pg_net extension (enabled by default on Supabase)
-- ============================================================

-- Enable pg_net for HTTP calls from triggers
create extension if not exists pg_net;

-- ── Helper: get the Supabase project URL from vault ──────────
-- Store your project URL and service role key in Supabase Vault
-- (Settings → Vault) under these names before running this migration.
-- Alternatively, replace vault.decrypted_secret calls with hardcoded
-- values during initial setup and rotate to vault later.

-- ── Trigger function: notify on task done ────────────────────
create or replace function public.notify_task_done()
returns trigger language plpgsql security definer as $$
declare
  v_supabase_url  text;
  v_service_key   text;
  v_boss_ids      uuid[];
  v_task_title    text;
  v_worker_name   text;
  v_job_name      text;
begin
  -- Only fire when status transitions to 'done'
  if NEW.status = 'done' and OLD.status <> 'done' then

    -- Fetch config from vault (set these in Supabase Dashboard → Vault)
    begin
      v_supabase_url := vault.decrypted_secret('supabase_url');
      v_service_key  := vault.decrypted_secret('service_role_key');
    exception when others then
      -- Vault not configured — skip silently
      return NEW;
    end;

    -- Gather context
    select t.title, u.full_name, j.name
      into v_task_title, v_worker_name, v_job_name
    from public.tasks t
    join public.jobs  j on j.id = t.job_id
    left join public.users u on u.id = NEW.assigned_to_user_id
    where t.id = NEW.id;

    -- Get all boss/admin IDs on this job
    select array_agg(jm.user_id)
      into v_boss_ids
    from public.job_members jm
    where jm.job_id = NEW.job_id
      and jm.role in ('boss', 'admin');

    -- Fire notification Edge Function (non-blocking)
    if v_boss_ids is not null and array_length(v_boss_ids, 1) > 0 then
      perform net.http_post(
        url     := v_supabase_url || '/functions/v1/send-notification',
        headers := jsonb_build_object(
          'Content-Type',  'application/json',
          'Authorization', 'Bearer ' || v_service_key
        ),
        body    := jsonb_build_object(
          'userIds', v_boss_ids,
          'title',   coalesce(v_worker_name, 'A worker') || ' completed a task',
          'body',    '"' || coalesce(v_task_title, 'Task') || '" — ' || coalesce(v_job_name, 'Fieldwork'),
          'data',    jsonb_build_object('type', 'task_done', 'taskId', NEW.id),
          'persist', true
        )
      );
    end if;
  end if;

  return NEW;
end;
$$;

create trigger task_done_notification
  after update of status on public.tasks
  for each row execute procedure public.notify_task_done();

-- ── Trigger function: notify worker on new task assignment ────
create or replace function public.notify_task_assigned()
returns trigger language plpgsql security definer as $$
declare
  v_supabase_url text;
  v_service_key  text;
  v_job_name     text;
begin
  -- Only fire when a task is assigned to someone and not needing review
  if NEW.assigned_to_user_id is not null and NEW.needs_review = false then

    begin
      v_supabase_url := vault.decrypted_secret('supabase_url');
      v_service_key  := vault.decrypted_secret('service_role_key');
    exception when others then
      return NEW;
    end;

    select name into v_job_name
    from public.jobs where id = NEW.job_id;

    perform net.http_post(
      url     := v_supabase_url || '/functions/v1/send-notification',
      headers := jsonb_build_object(
        'Content-Type',  'application/json',
        'Authorization', 'Bearer ' || v_service_key
      ),
      body    := jsonb_build_object(
        'userIds', jsonb_build_array(NEW.assigned_to_user_id::text),
        'title',   'New task assigned',
        'body',    '"' || coalesce(NEW.title, 'Task') || '" — ' || coalesce(v_job_name, 'Fieldwork'),
        'data',    jsonb_build_object('type', 'task_assigned', 'taskId', NEW.id),
        'persist', true
      )
    );
  end if;

  return NEW;
end;
$$;

create trigger task_assigned_notification
  after insert on public.tasks
  for each row execute procedure public.notify_task_assigned();

-- ── Vault setup reminder ──────────────────────────────────────
-- Run these in the Supabase dashboard → SQL Editor after deployment:
--
-- select vault.create_secret('supabase_url',      'https://YOUR_PROJECT.supabase.co');
-- select vault.create_secret('service_role_key',  'YOUR_SERVICE_ROLE_KEY');
