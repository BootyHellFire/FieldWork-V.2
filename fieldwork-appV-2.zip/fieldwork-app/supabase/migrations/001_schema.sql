-- ============================================================
-- Fieldwork V1 — Full Database Schema
-- Run this in: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- Enable UUID generation
create extension if not exists "pgcrypto";

-- ─── users ──────────────────────────────────────────────────
-- Mirrors auth.users. Created automatically via trigger below.
create table public.users (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text        not null,
  role        text        not null check (role in ('boss','worker','admin')),
  email       text        not null,
  phone       text,
  active      boolean     not null default true,
  created_at  timestamptz not null default now()
);

-- Auto-create a users row when someone signs up via Supabase Auth
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.users (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.email,
    coalesce(new.raw_user_meta_data->>'role', 'worker')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ─── builders ───────────────────────────────────────────────
create table public.builders (
  id           bigserial   primary key,
  name         text        not null,
  contact_name text,
  notes        text,
  created_at   timestamptz not null default now()
);

-- ─── jobs ───────────────────────────────────────────────────
create table public.jobs (
  id          bigserial   primary key,
  builder_id  bigint      references public.builders (id) on delete set null,
  name        text        not null,
  address     text,
  status      text        not null default 'upcoming'
                          check (status in ('upcoming','active','review','complete')),
  start_date  date,
  end_date    date,
  notes       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ─── job_members ────────────────────────────────────────────
create table public.job_members (
  id      bigserial primary key,
  job_id  bigint    not null references public.jobs (id)  on delete cascade,
  user_id uuid      not null references public.users (id) on delete cascade,
  role    text      not null check (role in ('boss','worker','admin')),
  unique  (job_id, user_id)
);

-- ─── plans ──────────────────────────────────────────────────
create table public.plans (
  id           bigserial   primary key,
  job_id       bigint      not null references public.jobs (id) on delete cascade,
  file_type    text        not null check (file_type in ('pdf','image')),
  file_url     text        not null,
  title        text,
  uploaded_by  uuid        references public.users (id) on delete set null,
  created_at   timestamptz not null default now()
);

-- ─── rooms ──────────────────────────────────────────────────
create table public.rooms (
  id          bigserial   primary key,
  job_id      bigint      not null references public.jobs  (id) on delete cascade,
  plan_id     bigint               references public.plans (id) on delete set null,
  name        text        not null,
  floor_name  text,
  notes       text,
  sort_order  int         not null default 0,
  created_at  timestamptz not null default now()
);

-- ─── walkthrough_sessions ───────────────────────────────────
create table public.walkthrough_sessions (
  id          uuid        primary key default gen_random_uuid(),
  job_id      bigint      not null references public.jobs  (id) on delete cascade,
  started_by  uuid        references public.users (id) on delete set null,
  started_at  timestamptz not null default now(),
  ended_at    timestamptz,
  notes       text
);

-- ─── walkthrough_segments ───────────────────────────────────
create table public.walkthrough_segments (
  id                  bigserial   primary key,
  session_id          uuid        not null references public.walkthrough_sessions (id) on delete cascade,
  room_id             bigint               references public.rooms (id) on delete set null,
  assignee_user_id    uuid                 references public.users (id) on delete set null,
  priority            text        not null default 'normal' check (priority in ('normal','high')),
  stage               text        not null default 'rough'  check (stage in ('rough','trim','finish','punch')),
  transcript_text     text,
  transcript_start_ms int,
  transcript_end_ms   int,
  audio_clip_url      text,
  snapshot_image_url  text,
  raw_ai_json         jsonb,
  reviewed            boolean     not null default false,
  created_at          timestamptz not null default now()
);

-- ─── tasks ──────────────────────────────────────────────────
create table public.tasks (
  id                  bigserial   primary key,
  job_id              bigint      not null references public.jobs (id) on delete cascade,
  room_id             bigint               references public.rooms (id) on delete set null,
  source_segment_id   bigint               references public.walkthrough_segments (id) on delete set null,
  assigned_to_user_id uuid                 references public.users (id) on delete set null,
  created_by_user_id  uuid        not null references public.users (id) on delete restrict,
  status              text        not null default 'pending'
                                  check (status in ('pending','in_progress','done','blocked')),
  priority            text        not null default 'normal' check (priority in ('normal','high')),
  stage               text        not null default 'rough'  check (stage in ('rough','trim','finish','punch')),
  title               text        not null,
  description         text,
  wall_reference      text,
  measurements_json   jsonb,
  diagram_json        jsonb,
  transcript_snippet  text,
  source_photo_url    text,
  needs_review        boolean     not null default true,
  approved_at         timestamptz,
  completed_at        timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- Keep updated_at current automatically
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create trigger tasks_updated_at
  before update on public.tasks
  for each row execute procedure public.set_updated_at();

-- ─── task_comments ──────────────────────────────────────────
create table public.task_comments (
  id         bigserial   primary key,
  task_id    bigint      not null references public.tasks (id) on delete cascade,
  user_id    uuid        not null references public.users (id) on delete cascade,
  comment    text        not null,
  created_at timestamptz not null default now()
);

-- ─── task_photos ────────────────────────────────────────────
create table public.task_photos (
  id          bigserial   primary key,
  task_id     bigint      not null references public.tasks (id) on delete cascade,
  photo_url   text        not null,
  photo_type  text        not null check (photo_type in ('reference','completion')),
  uploaded_by uuid        references public.users (id) on delete set null,
  created_at  timestamptz not null default now()
);

-- ─── notifications ──────────────────────────────────────────
create table public.notifications (
  id         bigserial   primary key,
  user_id    uuid        not null references public.users (id) on delete cascade,
  type       text        not null,
  title      text        not null,
  body       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);

-- ─── Realtime ───────────────────────────────────────────────
-- Enable realtime for tables workers care about
alter publication supabase_realtime add table public.tasks;
alter publication supabase_realtime add table public.task_comments;
alter publication supabase_realtime add table public.notifications;
