-- ============================================================
-- Fieldwork V1 — Row Level Security Policies
-- Run AFTER 001_schema.sql
-- ============================================================

-- Enable RLS on all tables
alter table public.users                 enable row level security;
alter table public.builders              enable row level security;
alter table public.jobs                  enable row level security;
alter table public.job_members           enable row level security;
alter table public.plans                 enable row level security;
alter table public.rooms                 enable row level security;
alter table public.walkthrough_sessions  enable row level security;
alter table public.walkthrough_segments  enable row level security;
alter table public.tasks                 enable row level security;
alter table public.task_comments         enable row level security;
alter table public.task_photos           enable row level security;
alter table public.notifications         enable row level security;

-- ─── Helper: is the current user a boss/admin on this job? ──
create or replace function public.is_boss_on_job(p_job_id bigint)
returns boolean language sql security definer as $$
  select exists (
    select 1 from public.job_members
    where job_id  = p_job_id
      and user_id = auth.uid()
      and role in ('boss','admin')
  );
$$;

-- ─── Helper: is the current user a member of this job? ──────
create or replace function public.is_member_of_job(p_job_id bigint)
returns boolean language sql security definer as $$
  select exists (
    select 1 from public.job_members
    where job_id  = p_job_id
      and user_id = auth.uid()
  );
$$;

-- ─── users ───────────────────────────────────────────────────
-- Anyone can read their own row; bosses can read all users on shared jobs
create policy "Users can read own profile"
  on public.users for select
  using (id = auth.uid());

create policy "Users can update own profile"
  on public.users for update
  using (id = auth.uid());

-- ─── jobs ────────────────────────────────────────────────────
create policy "Members can view their jobs"
  on public.jobs for select
  using (public.is_member_of_job(id));

create policy "Bosses can insert jobs"
  on public.jobs for insert
  with check (
    exists (
      select 1 from public.users
      where id = auth.uid() and role in ('boss','admin')
    )
  );

create policy "Bosses can update their jobs"
  on public.jobs for update
  using (public.is_boss_on_job(id));

-- ─── job_members ─────────────────────────────────────────────
create policy "Members can view job membership"
  on public.job_members for select
  using (public.is_member_of_job(job_id));

create policy "Bosses can manage job members"
  on public.job_members for all
  using (public.is_boss_on_job(job_id));

-- ─── rooms ───────────────────────────────────────────────────
create policy "Members can view rooms"
  on public.rooms for select
  using (public.is_member_of_job(job_id));

create policy "Bosses can manage rooms"
  on public.rooms for all
  using (public.is_boss_on_job(job_id));

-- ─── plans ───────────────────────────────────────────────────
create policy "Members can view plans"
  on public.plans for select
  using (public.is_member_of_job(job_id));

create policy "Bosses can insert plans"
  on public.plans for insert
  with check (public.is_boss_on_job(job_id));

create policy "Bosses can delete plans"
  on public.plans for delete
  using (public.is_boss_on_job(job_id));

-- ─── walkthrough_sessions ────────────────────────────────────
create policy "Members can view sessions"
  on public.walkthrough_sessions for select
  using (public.is_member_of_job(job_id));

create policy "Bosses can manage sessions"
  on public.walkthrough_sessions for all
  using (public.is_boss_on_job(job_id));

-- ─── walkthrough_segments ────────────────────────────────────
create policy "Members can view segments"
  on public.walkthrough_segments for select
  using (
    exists (
      select 1 from public.walkthrough_sessions s
      where s.id = session_id
        and public.is_member_of_job(s.job_id)
    )
  );

create policy "Bosses can manage segments"
  on public.walkthrough_segments for all
  using (
    exists (
      select 1 from public.walkthrough_sessions s
      where s.id = session_id
        and public.is_boss_on_job(s.job_id)
    )
  );

-- ─── tasks ───────────────────────────────────────────────────
-- Workers see only their assigned tasks (after boss approval)
create policy "Workers can view assigned tasks"
  on public.tasks for select
  using (
    assigned_to_user_id = auth.uid()
    and needs_review = false
  );

-- Bosses see all tasks on their jobs
create policy "Bosses can view all tasks on their jobs"
  on public.tasks for select
  using (public.is_boss_on_job(job_id));

create policy "Bosses can insert tasks"
  on public.tasks for insert
  with check (public.is_boss_on_job(job_id));

create policy "Bosses can update tasks"
  on public.tasks for update
  using (public.is_boss_on_job(job_id));

-- Workers can update status and completed_at on their own tasks
create policy "Workers can update status on assigned tasks"
  on public.tasks for update
  using (
    assigned_to_user_id = auth.uid()
    and needs_review = false
  )
  with check (
    -- Workers can only change status/completed_at — not title/description/etc.
    assigned_to_user_id = auth.uid()
  );

-- ─── task_comments ───────────────────────────────────────────
create policy "Members can view comments on accessible tasks"
  on public.task_comments for select
  using (
    exists (
      select 1 from public.tasks t
      where t.id = task_id
        and (
          t.assigned_to_user_id = auth.uid()
          or public.is_boss_on_job(t.job_id)
        )
    )
  );

create policy "Members can insert comments"
  on public.task_comments for insert
  with check (
    user_id = auth.uid()
    and exists (
      select 1 from public.tasks t
      where t.id = task_id
        and (
          t.assigned_to_user_id = auth.uid()
          or public.is_boss_on_job(t.job_id)
        )
    )
  );

-- ─── task_photos ─────────────────────────────────────────────
create policy "Members can view photos on accessible tasks"
  on public.task_photos for select
  using (
    exists (
      select 1 from public.tasks t
      where t.id = task_id
        and (
          t.assigned_to_user_id = auth.uid()
          or public.is_boss_on_job(t.job_id)
        )
    )
  );

create policy "Members can upload photos"
  on public.task_photos for insert
  with check (
    uploaded_by = auth.uid()
    and exists (
      select 1 from public.tasks t
      where t.id = task_id
        and (
          t.assigned_to_user_id = auth.uid()
          or public.is_boss_on_job(t.job_id)
        )
    )
  );

-- ─── notifications ───────────────────────────────────────────
create policy "Users can view own notifications"
  on public.notifications for select
  using (user_id = auth.uid());

create policy "Users can mark own notifications read"
  on public.notifications for update
  using (user_id = auth.uid());
