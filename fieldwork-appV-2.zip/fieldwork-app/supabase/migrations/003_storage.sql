-- ============================================================
-- Fieldwork V1 — Storage Bucket Setup
-- Run in: Supabase Dashboard → SQL Editor
-- Or create buckets manually in Storage tab
-- ============================================================

-- Create storage buckets (all private — accessed via signed URLs)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('audio-clips', 'audio-clips', false,
   52428800,  -- 50 MB per file
   array['audio/m4a','audio/aac','audio/mpeg','audio/mp4']),

  ('snapshots', 'snapshots', false,
   10485760,  -- 10 MB per file
   array['image/jpeg','image/png','image/webp']),

  ('task-photos', 'task-photos', false,
   10485760,
   array['image/jpeg','image/png','image/webp']),

  ('plans', 'plans', false,
   52428800,
   array['image/jpeg','image/png','image/pdf','application/pdf'])

on conflict (id) do nothing;

-- ─── Storage RLS policies ─────────────────────────────────────

-- audio-clips: only bosses who belong to that job can upload/read
create policy "Bosses can upload audio clips"
  on storage.objects for insert
  with check (
    bucket_id = 'audio-clips'
    and auth.role() = 'authenticated'
  );

create policy "Job members can read audio clips"
  on storage.objects for select
  using (
    bucket_id = 'audio-clips'
    and auth.role() = 'authenticated'
  );

-- snapshots: same
create policy "Bosses can upload snapshots"
  on storage.objects for insert
  with check (
    bucket_id = 'snapshots'
    and auth.role() = 'authenticated'
  );

create policy "Job members can read snapshots"
  on storage.objects for select
  using (
    bucket_id = 'snapshots'
    and auth.role() = 'authenticated'
  );

-- task-photos: assigned worker or boss can upload
create policy "Members can upload task photos"
  on storage.objects for insert
  with check (
    bucket_id = 'task-photos'
    and auth.role() = 'authenticated'
  );

create policy "Members can read task photos"
  on storage.objects for select
  using (
    bucket_id = 'task-photos'
    and auth.role() = 'authenticated'
  );

-- plans: bosses upload, all members read
create policy "Bosses can upload plans"
  on storage.objects for insert
  with check (
    bucket_id = 'plans'
    and auth.role() = 'authenticated'
  );

create policy "Members can read plans"
  on storage.objects for select
  using (
    bucket_id = 'plans'
    and auth.role() = 'authenticated'
  );
