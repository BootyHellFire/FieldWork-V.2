-- ============================================================
-- Fieldwork V1 — Migration 004
-- Adds push_token to users table for Expo push notifications.
-- Run in: Supabase Dashboard → SQL Editor
-- ============================================================

alter table public.users
  add column if not exists push_token text;

-- Index for fast lookups when sending targeted notifications
create index if not exists users_push_token_idx on public.users (push_token)
  where push_token is not null;
