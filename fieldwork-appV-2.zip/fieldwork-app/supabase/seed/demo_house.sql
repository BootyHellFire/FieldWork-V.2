-- ============================================================
-- Fieldwork V1 — Demo Seed Data (Meridian Ridge Estate)
-- Run AFTER migrations 001–003
-- ============================================================
-- NOTE: Replace the UUID values below with real auth.users IDs
-- after creating your demo accounts in Supabase Auth.
-- ============================================================

-- ─── Demo users ──────────────────────────────────────────────
-- These match the in-app demo user cards.
-- You must first create these accounts via Supabase Auth (magic link or dashboard).
-- Then update the IDs here to match.

insert into public.users (id, full_name, email, role) values
  ('00000000-0000-0000-0000-000000000001', 'Mike Torres',   'mike@fieldwork.demo',   'boss'),
  ('00000000-0000-0000-0000-000000000002', 'Jake Ruiz',     'jake@fieldwork.demo',   'worker'),
  ('00000000-0000-0000-0000-000000000003', 'Carson Webb',   'carson@fieldwork.demo', 'worker')
on conflict (id) do update set full_name = excluded.full_name;

-- ─── Builder ─────────────────────────────────────────────────
insert into public.builders (id, name, contact_name) values
  (1, 'Summit Custom Homes', 'Dave Perkins')
on conflict do nothing;

-- ─── Jobs ────────────────────────────────────────────────────
insert into public.jobs (id, builder_id, name, address, status) values
  (1, 1, 'Meridian Ridge Estate', '4821 Meadow View Ln, Eagle, ID',    'active'),
  (2, 1, 'Foothills Modern',      '912 Hillcrest Dr, Boise, ID',       'review'),
  (3, 1, 'Hidden Valley Ranch',   '2200 Canyon Rim Rd, Nampa, ID',     'upcoming')
on conflict do nothing;

-- ─── Job members ─────────────────────────────────────────────
insert into public.job_members (job_id, user_id, role) values
  (1, '00000000-0000-0000-0000-000000000001', 'boss'),
  (1, '00000000-0000-0000-0000-000000000002', 'worker'),
  (1, '00000000-0000-0000-0000-000000000003', 'worker'),
  (2, '00000000-0000-0000-0000-000000000001', 'boss'),
  (2, '00000000-0000-0000-0000-000000000002', 'worker'),
  (3, '00000000-0000-0000-0000-000000000001', 'boss')
on conflict do nothing;

-- ─── Rooms (Meridian Ridge job_id = 1) ───────────────────────
insert into public.rooms (id, job_id, name, floor_name, sort_order) values
  (1,  1, 'Kitchen',             'Main',  1),
  (2,  1, 'Master Bath',         'Upper', 2),
  (3,  1, 'Great Room',          'Main',  3),
  (4,  1, 'Downstairs Bathroom', 'Main',  4),
  (5,  1, 'Master Closet',       'Upper', 5),
  (6,  1, 'Garage',              'Main',  6),
  (7,  1, 'Master Bedroom',      'Upper', 7),
  (8,  1, 'Office',              'Main',  8),
  (9,  1, 'Laundry',             'Main',  9),
  (10, 1, 'Mudroom',             'Main',  10)
on conflict do nothing;

-- ─── Tasks (Meridian Ridge) ───────────────────────────────────
insert into public.tasks (
  id, job_id, room_id, assigned_to_user_id, created_by_user_id,
  status, priority, stage, title, description,
  measurements_json, transcript_snippet, needs_review
) values
  (
    1, 1, 2,
    '00000000-0000-0000-0000-000000000003', -- Carson
    '00000000-0000-0000-0000-000000000001', -- Mike
    'pending', 'high', 'trim',
    'Vanity light — height correction',
    'Move vanity light to 52.5" from finished floor, centered on mirror above vanity.',
    '{"height_from_ffl_inches": 52.5, "notes": "centered on mirror"}',
    'Move this vanity light up to 52 and a half from finished floor. Assign to Carson. High priority.',
    false
  ),
  (
    2, 1, 1,
    '00000000-0000-0000-0000-000000000002', -- Jake
    '00000000-0000-0000-0000-000000000001',
    'in_progress', 'normal', 'rough',
    'Under-cabinet outlet strip',
    'Install outlet strip under upper cabinet run on south wall. Rough-in at 54" from FFL.',
    '{"height_from_ffl_inches": 54, "notes": "south wall under cabinets"}',
    'Jake, put the outlet strip under the upper cabinets on the south wall.',
    false
  ),
  (
    3, 1, 3,
    '00000000-0000-0000-0000-000000000003',
    '00000000-0000-0000-0000-000000000001',
    'pending', 'normal', 'rough',
    'Switch bank — shift left 2"',
    'Move switch bank 2 inches to the left from current rough-in mark.',
    '{"notes": "shift 2 inches left from current mark"}',
    'Move this switch bank over 2 inches to the left.',
    false
  ),
  (
    4, 1, 1,
    '00000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000001',
    'pending', 'high', 'rough',
    'Island pendants — rough-in ×3',
    'Three pendant rough-ins above island. 36" on center, 84" to rough-in box.',
    '{"height_from_ffl_inches": 84, "notes": "36 inches on center, 3 locations"}',
    'Three pendants over the island. 36 inches on center, 84 to the box.',
    false
  ),
  (
    5, 1, 2,
    '00000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000001',
    'done', 'normal', 'rough',
    'Shower can — centered',
    'Recessed can centered in shower stall. 84" from FFL, 27" from right wall.',
    '{"height_from_ffl_inches": 84, "offset_from_right_wall_inches": 27}',
    'Mount at 84 inches to center from finished floor and 27 from the right wall.',
    false
  )
on conflict do nothing;

-- ─── Task comments ────────────────────────────────────────────
insert into public.task_comments (task_id, user_id, comment) values
  (1, '00000000-0000-0000-0000-000000000003',
   'Need to confirm mirror centerline with GC before roughing in.'),
  (4, '00000000-0000-0000-0000-000000000002',
   'Box size confirmed: 4" octagon. Steel mud ring OK with PM.')
on conflict do nothing;

-- Reset sequences so new inserts don't collide with seeded IDs
select setval('public.jobs_id_seq',     (select max(id) from public.jobs));
select setval('public.rooms_id_seq',    (select max(id) from public.rooms));
select setval('public.tasks_id_seq',    (select max(id) from public.tasks));
select setval('public.builders_id_seq', (select max(id) from public.builders));
