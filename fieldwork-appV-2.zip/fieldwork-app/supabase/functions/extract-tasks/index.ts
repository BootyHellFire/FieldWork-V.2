/**
 * Supabase Edge Function: extract-tasks
 *
 * Proxies calls to OpenAI so the API key never lives in the app binary.
 * The app sends the transcript + context; this function calls whisper-1
 * and gpt-4o and returns the structured task JSON.
 *
 * Deploy:
 *   supabase functions deploy extract-tasks
 *
 * Set secret:
 *   supabase secrets set OPENAI_API_KEY=sk-...
 *
 * Invoke from the app:
 *   supabase.functions.invoke('extract-tasks', { body: { ... } })
 */

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

const OPENAI_BASE = 'https://api.openai.com/v1';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ── System prompt (matches src/services/openai.ts) ────────────
const SYSTEM_PROMPT = `
You are an AI assistant helping an electrical foreman convert spoken walkthrough notes
into structured work tasks for electricians.

Extract work tasks from the transcript. For each task return:
- title: short, action-oriented (max 8 words)
- description: 1–2 sentences with full context
- room_name: from transcript if mentioned, else use provided room context
- assignee_name: if a worker's name is spoken near this task
- device_type: outlet / switch / light / can / panel / other
- action: mount / move / install / relocate / verify / other
- wall_reference: "right wall", "left wall", "centered", etc. if spoken
- measurements: object with height_from_ffl_inches, offset_from_right_wall_inches,
  offset_from_left_wall_inches, centered_on, above_feature, notes
- stage: rough / trim / finish / punch (from transcript or provided default)
- priority: high / normal (flag "high priority" or "urgent" keywords)
- confidence_score: 0–100
- should_create_task: true/false (false for pure notes or "just a note" phrases)
- ambiguity_flags: array of strings describing anything unclear

Return ONLY a JSON object: { "tasks": [ ...task objects... ] }
`.trim();

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS_HEADERS });
  }

  try {
    const apiKey = Deno.env.get('OPENAI_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'OPENAI_API_KEY not configured on server' }),
        { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    const body = await req.json() as {
      transcript:      string;
      roomName:        string;
      assignee:        string | null;
      stage:           string;
      snapshotBase64?: string;
    };

    const { transcript, roomName, assignee, stage, snapshotBase64 } = body;

    if (!transcript?.trim()) {
      return new Response(
        JSON.stringify({ tasks: [] }),
        { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    // ── Build user message ─────────────────────────────────
    const userContent: object[] = [
      {
        type: 'text',
        text: [
          `Current room: ${roomName}`,
          `Default assignee (if not spoken): ${assignee ?? 'unassigned'}`,
          `Default stage (if not spoken): ${stage}`,
          '',
          'Transcript:',
          `"""`,
          transcript,
          `"""`,
        ].join('\n'),
      },
    ];

    if (snapshotBase64) {
      userContent.push({
        type: 'image_url',
        image_url: {
          url: `data:image/jpeg;base64,${snapshotBase64}`,
          detail: 'low',
        },
      });
    }

    // ── Call gpt-4o ───────────────────────────────────────
    const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization:  `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model:           'gpt-4o',
        max_tokens:      2000,
        temperature:     0.1,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user',   content: userContent   },
        ],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('OpenAI error:', res.status, errText);
      return new Response(
        JSON.stringify({ error: `OpenAI error: ${res.status}`, tasks: [] }),
        { status: 502, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    const data = await res.json();
    const raw  = data.choices?.[0]?.message?.content ?? '{}';

    let parsed: { tasks: object[] };
    try {
      parsed = JSON.parse(raw);
    } catch {
      console.error('JSON parse failed:', raw);
      parsed = { tasks: [] };
    }

    return new Response(
      JSON.stringify(parsed),
      { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    console.error('extract-tasks error:', err);
    return new Response(
      JSON.stringify({ error: String(err), tasks: [] }),
      { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  }
});
