/**
 * Supabase Edge Function: send-notification
 *
 * Sends Expo push notifications to one or more users.
 * Called server-side (from another Edge Function or a DB trigger)
 * so push credentials never touch the client.
 *
 * Deploy:
 *   supabase functions deploy send-notification
 *
 * Invoke internally:
 *   supabase.functions.invoke('send-notification', {
 *     body: { userIds: ['uuid-1', 'uuid-2'], title: '...', body: '...' }
 *   })
 */

import { serve }       from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS_HEADERS });
  }

  try {
    const supabaseUrl  = Deno.env.get('SUPABASE_URL')!;
    const serviceKey   = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    // Use service role so we can read push tokens regardless of RLS
    const admin = createClient(supabaseUrl, serviceKey);

    const body = await req.json() as {
      userIds:   string[];
      title:     string;
      body:      string;
      data?:     Record<string, unknown>;
      /** If set, also inserts a row in the notifications table */
      persist?:  boolean;
    };

    const { userIds, title, body: msgBody, data = {}, persist = true } = body;

    if (!userIds?.length) {
      return new Response(
        JSON.stringify({ sent: 0, skipped: 0 }),
        { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    // ── Fetch push tokens ──────────────────────────────
    const { data: users, error: fetchErr } = await admin
      .from('users')
      .select('id, push_token')
      .in('id', userIds)
      .not('push_token', 'is', null);

    if (fetchErr) throw fetchErr;

    const tokensWithIds = (users ?? []).filter(u => u.push_token?.startsWith('ExponentPushToken'));

    // ── Persist notification rows ──────────────────────
    if (persist && tokensWithIds.length > 0) {
      await admin.from('notifications').insert(
        userIds.map(uid => ({
          user_id:    uid,
          type:       data.type ?? 'general',
          title,
          body:       msgBody,
        }))
      );
    }

    if (tokensWithIds.length === 0) {
      return new Response(
        JSON.stringify({ sent: 0, skipped: userIds.length, reason: 'No valid push tokens' }),
        { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    // ── Send via Expo Push API (batch up to 100) ───────
    const messages = tokensWithIds.map(u => ({
      to:    u.push_token,
      title,
      body:  msgBody,
      data,
      sound: 'default',
      priority: 'high',
    }));

    // Expo recommends batches of ≤ 100
    const batches: object[][] = [];
    for (let i = 0; i < messages.length; i += 100) {
      batches.push(messages.slice(i, i + 100));
    }

    let totalSent = 0;
    for (const batch of batches) {
      const pushRes = await fetch(EXPO_PUSH_URL, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body:    JSON.stringify(batch),
      });
      if (pushRes.ok) totalSent += batch.length;
      else {
        const err = await pushRes.text();
        console.error('Expo push error:', err);
      }
    }

    return new Response(
      JSON.stringify({ sent: totalSent, skipped: userIds.length - tokensWithIds.length }),
      { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    console.error('send-notification error:', err);
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  }
});
